import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:network_copilot/account_api.dart';
import 'package:network_copilot/operations_screen.dart';
import 'account_test.dart' show MemoryStore, profile;

Future<void> operationsHarness(
  WidgetTester tester,
  double width,
  Future<void> Function() exercise, {
  String role = 'viewer',
  double textScale = 1,
  Map<String, dynamic> Function(http.Request)? response,
}) async {
  final account = AccountController(
    store: MemoryStore(),
    clientFactory: () => MockClient((request) async {
      final data = request.url.path == '/v1/me'
          ? profile(role: role)
          : response?.call(request) ?? {'items': [], 'total': 0};
      return http.Response.bytes(utf8.encode(jsonEncode(data)), 200);
    }),
  );
  tester.view.physicalSize = Size(width, 1200);
  tester.view.devicePixelRatio = 1;
  addTearDown(tester.view.resetPhysicalSize);
  addTearDown(tester.view.resetDevicePixelRatio);
  try {
    await account.accept({'token': 'fixture-session'});
    await tester.pumpWidget(
      MaterialApp(
        home: Builder(
          builder: (context) => MediaQuery(
            data: MediaQuery.of(context).copyWith(
              textScaler: TextScaler.linear(textScale),
            ),
            child: Directionality(
              textDirection: TextDirection.rtl,
              child: Scaffold(
                body: OperationsScreen(
                  account: account,
                  sites: const [{'id': 'site-a', 'name': 'موقع أ'}],
                  devices: const [],
                ),
              ),
            ),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();
    await exercise();
    expect(tester.takeException(), isNull);
  } finally {
    // Widget-test invariants run before package:test tearDown callbacks.
    // Dispose the owned controller here so its real ten-minute refresh timer
    // is cancelled even when an assertion or the widget setup fails.
    try {
      await tester.pumpWidget(const SizedBox.shrink());
    } finally {
      account.dispose();
    }
  }
}

void main() {
  test('operation request IDs are distinct UUIDs', () {
    final ids = List.generate(200, (_) => operationRequestId());
    expect(ids.toSet().length, 200);
    expect(
      ids.every(
        (v) => RegExp(
          r'^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$',
        ).hasMatch(v),
      ),
      true,
    );
  });
  test('site and search parameters are encoded separately from the route', () async {
    Uri? seen;
    final account = AccountController(
      store: MemoryStore(),
      clientFactory: () => MockClient((request) async {
        if (request.url.path == '/v1/me') {
          return http.Response.bytes(utf8.encode(jsonEncode(profile())), 200);
        }
        seen = request.url;
        expect(request.headers['authorization'], 'Bearer fixture-session');
        return http.Response('{"items":[],"total":0}', 200);
      }),
    );
    try {
      await account.accept({'token': 'fixture-session'});
      await account.request(
        'GET',
        '/v1/operations/plans',
        query: {'siteId': 'site-a', 'q': 'اسم & 100%'},
      );
      expect(seen!.path, '/v1/operations/plans');
      expect(seen!.queryParameters['q'], 'اسم & 100%');
      expect(seen!.queryParameters['siteId'], 'site-a');
    } finally {
      account.dispose();
    }
  });
  for (final width in [320.0, 390.0, 1366.0]) {
    testWidgets(
      'empty operations are explicit and read-only roles cannot create at ${width}px',
      (tester) async {
        await operationsHarness(tester, width, () async {
          expect(find.text('لا توجد سجلات مطابقة.'), findsOneWidget);
          expect(find.text('إضافة'), findsNothing);
          expect(find.text('الكروت والطباعة'), findsNothing);
          expect(find.text('0 — 0 من 0'), findsOneWidget);
        });
      },
    );
  }
  testWidgets('portal heading wraps at 320px', (tester) async {
    await operationsHarness(
      tester,
      320,
      () async {
        await tester.ensureVisible(find.text('صفحة الهوتسبوت'));
        await tester.tap(find.text('صفحة الهوتسبوت'));
        await tester.pumpAndSettle();
        await tester.ensureVisible(find.text('تصميم صفحة الهوتسبوت'));
        await tester.pumpAndSettle();
        expect(find.text('تصميم صفحة الهوتسبوت'), findsOneWidget);
        expect(find.text('دخول الشبكة — معاينة'), findsOneWidget);
      },
      role: 'owner',
      response: (request) => request.url.path.startsWith('/v1/operations/portals/')
          ? {
              'portal': {
                'id': 'portal-a',
                'version': 1,
                'approvedVersion': null,
                'design': {
                  'title': 'شبكة المختبر',
                  'welcome': 'أهلًا بك',
                  'phone': '',
                  'showPlans': true,
                  'showResellers': true,
                },
              },
            }
          : {'items': [], 'total': 0},
    );
  });
  testWidgets('pagination stays visible at 390px with larger text', (tester) async {
    await operationsHarness(
      tester,
      390,
      () async {
        await tester.scrollUntilVisible(
          find.byKey(const Key('operations-pagination')),
          300,
          scrollable: find.byType(Scrollable).first,
        );
        await tester.pumpAndSettle();
        expect(find.text('1 — 1 من 10000'), findsOneWidget);
        expect(find.byTooltip('السابق'), findsOneWidget);
        expect(find.byTooltip('التالي'), findsOneWidget);
      },
      textScale: 1.5,
      response: (request) => request.url.path == '/v1/operations/subscribers'
          ? {
              'items': [
                {
                  'id': 'subscriber-a',
                  'siteId': 'site-a',
                  'name': 'مشترك تجريبي',
                  'phone': '',
                  'endsOn': null,
                  'status': 'active',
                },
              ],
              'total': 10000,
            }
          : {'items': [], 'total': 0},
    );
  });
}
