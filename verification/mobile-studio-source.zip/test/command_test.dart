import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:network_copilot/account_api.dart';
import 'package:network_copilot/command_center.dart';
import 'package:network_copilot/emergency_ai.dart';
import 'package:network_copilot/emergency_home.dart';
import 'package:network_copilot/ui.dart';
import 'account_test.dart' show MemoryStore, profile;

Future<void> harness(WidgetTester tester, Widget Function(AccountController) page, Future<void> Function() exercise, {String role = 'owner', double width = 390, double height = 1600, double textScale = 1.3, Map<String, dynamic> Function(http.Request)? response}) async {
  final account = AccountController(store: MemoryStore(), clientFactory: () => MockClient((request) async {
    final data = request.url.path == '/v1/me' ? profile(role: role) : response?.call(request) ?? <String, dynamic>{};
    return http.Response.bytes(utf8.encode(jsonEncode(data)), 200);
  }));
  tester.view.physicalSize = Size(width, height); tester.view.devicePixelRatio = 1;
  addTearDown(tester.view.resetPhysicalSize); addTearDown(tester.view.resetDevicePixelRatio);
  try {
    await account.accept({'token': 'synthetic-session'});
    await tester.pumpWidget(MaterialApp(theme: CopilotTheme.dark(), builder: (context, child) => MediaQuery(data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(textScale)), child: Directionality(textDirection: TextDirection.rtl, child: child!)), home: Scaffold(body: page(account))));
    await tester.pumpAndSettle(); await exercise(); expect(tester.takeException(), isNull);
  } finally { await tester.pumpWidget(const SizedBox.shrink()); account.dispose(); }
}

Map<String, dynamic> device() => {'id': 'synthetic-device', 'siteId': 'site-a', 'siteName': 'الموقع أ', 'name': 'راوتر اختبار', 'enabled': true, 'monitoring': false, 'policy': {'intervalSeconds': 120}, 'lastRunAt': DateTime.now().toUtc().toIso8601String(), 'coverage': {'unknown': 1, 'measured': 1, 'total': 2}};

// The summary is a section of EmergencyHome's scrollable, not a standalone
// bounded-height screen. Keep the real constraint contract in isolated tests.
Widget activationHost(AccountController account) => SingleChildScrollView(padding: const EdgeInsets.all(18), child: CommandActivationSummary(account: account));

Future<void> expectReachable(WidgetTester tester, Finder finder) async {
  await tester.ensureVisible(finder); await tester.pumpAndSettle();
  final center = tester.getCenter(finder), viewport = tester.view.physicalSize / tester.view.devicePixelRatio;
  expect(center.dy, inInclusiveRange(0, viewport.height));
}

void main() {
  test('byte labels preserve zero and unavailable as distinct values', () { expect(commandBytes(null), 'غير متاح'); expect(commandBytes(0), '0 B'); expect(commandBytes(1048576), '1.0 MiB'); });
  for (final width in [320.0, 390.0, 1366.0]) {
    testWidgets('main statistics wrap at $width and viewer sees no financial or configuration controls', (tester) async {
      await harness(tester, (a) => EmergencyHome(account: a, onDevice: (_, _) {}, onDevices: () {}), () async {
        expect(find.text('إعدادات الرادار'), findsNothing); expect(find.text('الدخول وقيمة التفعيل'), findsNothing);
        await tester.tap(find.text('إحصائيات الشبكة')); await tester.pumpAndSettle();
        expect(find.text('نبض الشبكة والإحصائيات'), findsOneWidget); expect(find.text('غير متاح'), findsWidgets);
      }, role: 'viewer', width: width, response: (r) => r.url.path.endsWith('/devices') ? {'items': [device()]} : {'items': [], 'total': 0, 'summary': {'active': 0, 'critical': 0}});
    });
  }
  testWidgets('activation value is YER with a separate unknown-price count and no claimed collection', (tester) async {
    await harness(tester, activationHost, () async {
      expect(find.text('قيمة التفعيل المعروفة · ريال يمني'), findsOneWidget); expect(find.text('500'), findsOneWidget);
      expect(find.textContaining('ولا تثبت تحصيل المال'), findsOneWidget); expect(find.text('تفعيلات بسعر غير معروف'), findsOneWidget);
      await expectReachable(tester, find.textContaining('بدأ التتبع في هذا النطاق'));
    }, height: 640, response: (_) => {'coverage': {'devices': 1, 'startedAt': DateTime.now().toUtc().toIso8601String()}, 'firstActivations': 3, 'activationValueYER': 500, 'loginAccountsObserved': 1, 'activeAccountsObserved': 1, 'freeActivations': 1, 'unknownPrice': 1, 'unknownFirstUse': 2, 'breakdown': [], 'series': []});
  });
  testWidgets('untracked scope does not fabricate a zero sale amount', (tester) async {
    await harness(tester, activationHost, () async {
      expect(find.textContaining('لم يبدأ تتبع الكروت'), findsOneWidget); expect(find.text('غير متاح'), findsWidgets); expect(find.text('0'), findsNothing);
      await expectReachable(tester, find.textContaining('بدأ التتبع في هذا النطاق'));
    }, height: 640, response: (_) => {'coverage': {'devices': 0}, 'activationValueYER': null, 'breakdown': [], 'series': []});
  });
  for (final viewport in [(320.0, 640.0, 1.3), (390.0, 640.0, 1.3), (1366.0, 768.0, 1.3), (844.0, 360.0, 2.0)]) {
    testWidgets('owner home scrolls financial cards and expanded history at ${viewport.$1}x${viewport.$2}, text ${viewport.$3}', (tester) async {
      await harness(tester, (a) => EmergencyHome(account: a, onDevice: (_, _) {}, onDevices: () {}), () async {
        final shortcut = find.widgetWithText(OutlinedButton, 'الدخول وقيمة التفعيل');
        await tester.ensureVisible(shortcut); await tester.tap(shortcut); await tester.pumpAndSettle();
        expect(find.text('قيمة التفعيل المعروفة · ريال يمني'), findsOneWidget); expect(find.text('500'), findsOneWidget);
        final history = find.text('تاريخ التفعيل خلال 30 يومًا');
        await expectReachable(tester, history); await tester.tap(history); await tester.pumpAndSettle();
        await expectReachable(tester, find.text('2026-01-01'));
      }, width: viewport.$1, height: viewport.$2, textScale: viewport.$3, response: (r) {
        if (r.url.path.endsWith('/devices')) return {'items': [device()]};
        if (r.url.path.endsWith('/incidents')) return {'items': [], 'total': 0, 'summary': {'active': 0, 'critical': 0}};
        return {'coverage': {'devices': 1, 'recentDevices': 1, 'startedAt': DateTime.now().toUtc().toIso8601String()}, 'firstActivations': 3, 'activationValueYER': 500, 'loginAccountsObserved': 1, 'activeAccountsObserved': 1, 'freeActivations': 1, 'unknownPrice': 1, 'unknownFirstUse': 2, 'breakdown': [{'planName': 'فئة اختبار', 'price': 500, 'count': 1, 'valueYER': 500}], 'resellers': [{'resellerName': 'موزع اختبار', 'siteName': 'الموقع أ', 'count': 1, 'unknownPrice': 0, 'valueYER': 500}], 'series': [for (var day = 1; day <= 30; day++) {'day': '2026-01-${day.toString().padLeft(2, '0')}', 'count': day == 30 ? 1 : 0, 'valueYER': day == 30 ? 500 : 0}]};
      });
    });
  }
  testWidgets('client list needs a second actual reading and starts with automatic refresh disabled', (tester) async {
    int reads = 0;
    await harness(tester, (a) => CommandClientsPage(account: a, id: 'device'), () async {
      expect(reads, 1); expect(tester.widget<SwitchListTile>(find.byType(SwitchListTile)).value, false);
      expect(find.textContaining('تنزيل إلى المشترك: غير متاح'), findsOneWidget);
      await tester.tap(find.byTooltip('تحديث الجلسات')); await tester.pumpAndSettle(); expect(reads, 2); expect(find.textContaining('2.00 Mbps'), findsOneWidget);
    }, response: (_) { reads++; return {'sessions': 1, 'total': 1, 'observedAt': DateTime.now().toUtc().toIso8601String(), 'items': [{'address': '192.0.2.10', 'macAddress': '02:00:00:00:00:01', 'uptime': '1m', 'bytesIn': '100', 'bytesOut': '200', 'downloadBps': reads > 1 ? 2000000 : null, 'uploadBps': null, 'reason': reads > 1 ? null : 'insufficient_samples'}]}; });
  });
  testWidgets('incident AI never posts before consent and never executes a repair by generating text', (tester) async {
    final posted = <http.Request>[]; final hash = List.filled(64, 'a').join();
    await harness(tester, (a) => EmergencyAiDialog(account: a, incidentId: 'incident'), () async {
      expect(posted, isEmpty); expect(tester.widget<FilledButton>(find.byKey(const Key('emergency-ai-send'))).onPressed, isNull);
      await tester.ensureVisible(find.byKey(const Key('emergency-ai-consent'))); await tester.tap(find.byKey(const Key('emergency-ai-consent'))); await tester.pumpAndSettle();
      await tester.tap(find.byKey(const Key('emergency-ai-send'))); await tester.pumpAndSettle();
      expect(posted.length, 1); expect(posted.single.url.path.endsWith('/ai-explanation'), true); expect(jsonDecode(posted.single.body)['share'], true);
      expect(find.textContaining('لم يُنفّذ هذا التحليل تغييرًا'), findsOneWidget); expect(posted.any((r) => r.url.path.endsWith('/execute')), false);
    }, response: (r) { if (r.method == 'POST') { posted.add(r); return {'source': 'gemini', 'routerWrite': false, 'deviceAccess': false, 'contextHash': hash, 'text': 'شرح اختبار محلي.', 'truncated': false, 'actions': [], 'cached': false, 'generatedAt': DateTime.now().toUtc().toIso8601String()}; } return {'available': true, 'hash': hash, 'text': 'بيانات الدليل فقط', 'observedAt': DateTime.now().toUtc().toIso8601String()}; });
  });
}
