import 'dart:convert';
import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:network_copilot/account_api.dart';
import 'package:network_copilot/main.dart';
import 'package:network_copilot/health_dialogs.dart';
import 'package:network_copilot/health_api.dart';
import 'package:network_copilot/network_startup.dart';
import 'package:network_copilot/ui.dart';
import 'account_test.dart' show MemoryStore, profile;
import 'health_fixture.dart';

http.Response response(Object value, [int status = 200]) =>
    http.Response.bytes(utf8.encode(jsonEncode(value)), status);
const captureKey = Key('health-capture');
Widget previewBadge(Widget child) =>
    Platform.environment['COPILOT_VISUAL_DIR'] == null
    ? child
    : Banner(
        message: 'بيانات اختبار',
        location: BannerLocation.topEnd,
        color: const Color(0xFF0369A1),
        textStyle: const TextStyle(
          fontFamily: 'Tajawal',
          fontSize: 11,
          fontWeight: FontWeight.w700,
          color: Colors.white,
        ),
        child: child,
      );
Future<void> capture(WidgetTester tester, String name) async {
  final destination = Platform.environment['COPILOT_VISUAL_DIR'];
  if (destination == null) return;
  await tester.runAsync(() async {
    final boundary = tester.renderObject<RenderRepaintBoundary>(
      find.byKey(captureKey),
    );
    final image = await boundary.toImage(pixelRatio: 1),
        bytes = await image.toByteData(format: ui.ImageByteFormat.png);
    await Directory(destination).create(recursive: true);
    await File(
      '$destination/$name.png',
    ).writeAsBytes(bytes!.buffer.asUint8List());
    image.dispose();
  });
}

Future<AccountController> accountWith(
  Future<http.Response> Function(http.Request) handler, {
  String role = 'owner',
}) async {
  final account = AccountController(
    store: MemoryStore(),
    clientFactory: () => MockClient((req) async {
      if (req.url.path == '/v1/me') return response(profile(role: role));
      return handler(req);
    }),
  );
  await account.accept({'token': 'fixture-session'});
  // This isolated widget harness has no AccountGate to own session refresh.
  account.suspend();
  return account;
}

Future<void> harness(
  WidgetTester tester,
  AccountController account, {
  double width = 390,
  Brightness brightness = Brightness.dark,
}) async {
  tester.view.physicalSize = Size(width, 1050);
  tester.view.devicePixelRatio = 1;
  addTearDown(tester.view.resetPhysicalSize);
  addTearDown(tester.view.resetDevicePixelRatio);
  addTearDown(() async {
    await tester.pumpWidget(const SizedBox.shrink());
  });
  if (Platform.environment['COPILOT_VISUAL_DIR'] != null) {
    await (FontLoader(
      'MaterialIcons',
    )..addFont(rootBundle.load('fonts/MaterialIcons-Regular.otf'))).load();
    await (FontLoader('Tajawal')
          ..addFont(rootBundle.load('assets/fonts/Tajawal-Regular.ttf'))
          ..addFont(rootBundle.load('assets/fonts/Tajawal-Bold.ttf')))
        .load();
    await (FontLoader('JetBrainsMono')
          ..addFont(rootBundle.load('assets/fonts/JetBrainsMono-Regular.ttf')))
        .load();
  }
  await tester.pumpWidget(
    MaterialApp(
      theme: brightness == Brightness.dark
          ? CopilotTheme.dark()
          : CopilotTheme.light(),
      home: Directionality(
        textDirection: TextDirection.rtl,
        child: RepaintBoundary(
          key: captureKey,
          child: previewBadge(
            ProviderScope(
              overrides: [accountProvider.overrideWith((ref) => account)],
              child: DeviceScreen(
                onTheme: () {},
                initialConnection: account.connection('router-one'),
                accountMode: true,
                deviceName: 'راوتر المختبر',
                canChat: account.canChat,
                onBack: () {},
              ),
            ),
          ),
        ),
      ),
    ),
  );
  await tester.pumpAndSettle();
}

void main() {
  for (final width in [390.0, 1366.0]) {
    for (final brightness in [Brightness.dark, Brightness.light]) {
      testWidgets(
        'health center shows evidence, unknown coverage and rates at $width / ${brightness.name}',
        (tester) async {
          final scan = healthFixture();
          final account = await accountWith((req) async {
            if (req.url.path.endsWith('/health-profile')) {
              return response({
                'profile': {'version': 0, 'links': []},
                'siteName': 'مختبر CHR',
              });
            }
            if (req.url.path.endsWith('/health-scans')) {
              return response({
                'items': [healthSummary(scan)],
              });
            }
            return response({'scan': scan});
          });
          await harness(tester, account, width: width, brightness: brightness);
          expect(find.text('مركز صحة الشبكة'), findsOneWidget);
          expect(find.text('مختبر CHR'), findsOneWidget);
          expect(find.textContaining('6 من 8'), findsOneWidget);
          expect(find.text('الشبكة سليمة 100%'), findsNothing);
          await capture(tester, 'health-${width.toInt()}-${brightness.name}');
          await tester.ensureVisible(find.byKey(const Key('health-tab-2')));
          await tester.tap(find.byKey(const Key('health-tab-2')));
          await tester.pumpAndSettle();
          final finding = find.text('خدمات الإدارة غير المشفّرة');
          await tester.ensureVisible(finding);
          await tester.tap(finding);
          await tester.pumpAndSettle();
          expect(find.text('الدليل'), findsOneWidget);
          expect(find.textContaining('منفذ 21'), findsOneWidget);
          await tester.tap(find.byTooltip('إغلاق'));
          await tester.pumpAndSettle();
          expect(tester.takeException(), isNull);
        },
      );
    }
  }
  testWidgets(
    'a scan can start, complete, persist and be reopened for comparison',
    (tester) async {
      bool started = false, done = false;
      final previous = healthFixture(id: 'previous', minute: 30),
          current = healthFixture(id: 'new');
      current['report']['resources']['cpuLoad'] = 70;
      final running = {
        'id': 'new',
        'status': 'running',
        'stage': 'sampling',
        'progress': 10,
        'createdAt': current['createdAt'],
      };
      final account = await accountWith((req) async {
        if (req.url.path.endsWith('/health-profile')) {
          return response({
            'profile': {'version': 0, 'links': []},
            'siteName': 'المختبر',
          });
        }
        if (req.url.path.endsWith('/health-scans') && req.method == 'POST') {
          started = true;
          return response({'scan': running});
        }
        if (req.url.path.endsWith('/health-scans')) {
          return response({
            'items': [
              if (started) done ? healthSummary(current) : running,
              healthSummary(previous),
            ],
          });
        }
        if (req.url.path.endsWith('/previous')) {
          return response({'scan': previous});
        }
        done = true;
        return response({'scan': current});
      });
      await harness(tester, account);
      await tester.tap(find.byKey(const Key('health-start')));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 1200));
      await tester.pumpAndSettle();
      expect(started, true);
      expect(done, true);
      await tester.ensureVisible(find.byKey(const Key('health-tab-3')));
      await tester.tap(find.byKey(const Key('health-tab-3')));
      await tester.pumpAndSettle();
      for (final box in find.byType(Checkbox).evaluate().toList()) {
        final finder = find.byWidget(box.widget);
        await tester.ensureVisible(finder);
        await tester.tap(finder);
        await tester.pumpAndSettle();
      }
      await tester.ensureVisible(find.byKey(const Key('health-compare')));
      await tester.tap(find.byKey(const Key('health-compare')));
      await tester.pumpAndSettle();
      expect(find.text('مقارنة الفحصين'), findsOneWidget);
      expect(
        find.descendant(of: find.byType(DataTable), matching: find.text('34%')),
        findsOneWidget,
      );
      expect(
        find.descendant(of: find.byType(DataTable), matching: find.text('70%')),
        findsOneWidget,
      );
      expect(tester.takeException(), isNull);
    },
  );
  testWidgets(
    'cancelled scans are confirmed and failed collection does not turn old readings green',
    (tester) async {
      bool started = false, cancelled = false;
      Map<String, dynamic> state() => {
        'id': 'cancel-test',
        'status': cancelled ? 'cancelled' : 'running',
        'stage': cancelled ? 'finished' : 'sampling',
        'progress': 10,
        'createdAt': '2026-11-07T15:35:00Z',
      };
      final account = await accountWith((req) async {
        if (req.url.path.endsWith('/health-profile')) {
          return response({
            'profile': {'version': 0, 'links': []},
          });
        }
        if (req.url.path.endsWith('/cancel')) {
          cancelled = true;
          return response({'ok': true});
        }
        if (req.url.path.endsWith('/health-scans') && req.method == 'POST') {
          started = true;
          return response({'scan': state()});
        }
        if (req.url.path.endsWith('/health-scans')) {
          return response({
            'items': started ? [state()] : [],
          });
        }
        return response({'scan': state()});
      });
      await harness(tester, account);
      await tester.tap(find.byKey(const Key('health-start')));
      await tester.pumpAndSettle();
      await tester.ensureVisible(find.byKey(const Key('health-cancel')));
      await tester.tap(find.byKey(const Key('health-cancel')));
      await tester.pumpAndSettle();
      expect(cancelled, true);
      expect(find.textContaining('أُلغي الفحص.'), findsOneWidget);
      expect(find.text('نجح الفحص'), findsNothing);
    },
  );
  testWidgets(
    'viewer can read reports and cannot launch scans or send data to AI',
    (tester) async {
      final scan = healthFixture();
      final writes = <String>[];
      final account = await accountWith((req) async {
        if (req.method != 'GET') writes.add(req.url.path);
        if (req.url.path.endsWith('/health-profile')) {
          return response({
            'profile': {'version': 0, 'links': []},
          });
        }
        if (req.url.path.endsWith('/health-scans')) {
          return response({
            'items': [healthSummary(scan)],
          });
        }
        return response({'scan': scan});
      }, role: 'viewer');
      await harness(tester, account);
      expect(find.byKey(const Key('health-start')), findsNothing);
      expect(find.byKey(const Key('health-ai')), findsNothing);
      expect(writes, isEmpty);
    },
  );
  testWidgets(
    'AI stays local until the explicit send action and provider failure preserves the report',
    (tester) async {
      var sends = 0;
      final scan = HealthScan.parse(healthFixture());
      final account = await accountWith((req) async {
        sends++;
        return response({'error': 'ai_unavailable'}, 502);
      });
      addTearDown(account.dispose);
      addTearDown(() => tester.pumpWidget(const SizedBox.shrink()));
      await tester.pumpWidget(
        MaterialApp(
          theme: CopilotTheme.dark(),
          home: Scaffold(
            body: HealthExplanation(scan: scan, account: account),
          ),
        ),
      );
      await tester.pumpAndSettle();
      expect(sends, 0);
      await tester.ensureVisible(
        find.widgetWithText(FilledButton, 'إرسال للشرح'),
      );
      await tester.tap(find.widgetWithText(FilledButton, 'إرسال للشرح'));
      await tester.pumpAndSettle();
      expect(sends, 1);
      expect(find.textContaining('تقرير الفحص ما زال متاحًا'), findsOneWidget);
      expect(scan.completed, true);
    },
  );
  testWidgets(
    'profile conflicts preserve the editor and do not overwrite newer settings',
    (tester) async {
      final scan = healthFixture();
      Map<String, dynamic>? saved;
      final account = await accountWith((req) async {
        if (req.url.path.endsWith('/health-profile') && req.method == 'PATCH') {
          saved = jsonDecode(req.body) as Map<String, dynamic>;
          return response({'error': 'version_conflict'}, 409);
        }
        if (req.url.path.endsWith('/health-profile')) {
          return response({
            'profile': {'version': 0, 'links': []},
          });
        }
        if (req.url.path.endsWith('/health-scans')) {
          return response({
            'items': [healthSummary(scan)],
          });
        }
        return response({'scan': scan});
      });
      await harness(tester, account);
      await tester.tap(find.byTooltip('إعدادات الفحص'));
      await tester.pumpAndSettle();
      final checkbox = find.byType(Checkbox).first;
      await tester.ensureVisible(checkbox);
      await tester.tap(checkbox);
      await tester.pumpAndSettle();
      final save = find.widgetWithText(FilledButton, 'حفظ إعدادات الفحص');
      await tester.ensureVisible(save);
      await tester.tap(save);
      await tester.pumpAndSettle();
      expect(saved!['version'], 0);
      expect((saved!['links'] as List).single['required'], true);
      expect(find.textContaining('تغير السجل منذ فتحه'), findsOneWidget);
      expect(find.text('أدوار الواجهات والروابط المطلوبة'), findsOneWidget);
      expect(tester.takeException(), isNull);
    },
  );
  testWidgets(
    'failed refresh retains the timestamped report and offers retry without relabeling it live',
    (tester) async {
      var offline = false;
      final scan = healthFixture();
      final account = await accountWith((req) async {
        if (offline) throw http.ClientException('fixture offline');
        if (req.url.path.endsWith('/health-profile')) {
          return response({
            'profile': {'version': 0, 'links': []},
          });
        }
        if (req.url.path.endsWith('/health-scans')) {
          return response({
            'items': [healthSummary(scan)],
          });
        }
        return response({'scan': scan});
      });
      await harness(tester, account);
      offline = true;
      await tester.tap(find.byTooltip('تحديث التقارير'));
      await tester.pumpAndSettle();
      expect(find.textContaining('تعذر الاتصال الآمن بالخادم'), findsOneWidget);
      expect(find.textContaining('وقت التقرير:'), findsOneWidget);
      expect(find.text('إعادة المحاولة'), findsOneWidget);
      expect(tester.takeException(), isNull);
    },
  );
  testWidgets(
    'an access denial clears cached measurements instead of retaining another scope of data',
    (tester) async {
      var denied = false;
      final scan = healthFixture();
      final account = await accountWith((req) async {
        if (denied) return response({'error': 'not_found'}, 404);
        if (req.url.path.endsWith('/health-profile')) {
          return response({
            'profile': {'version': 0, 'links': []},
          });
        }
        if (req.url.path.endsWith('/health-scans')) {
          return response({
            'items': [healthSummary(scan)],
          });
        }
        return response({'scan': scan});
      });
      await harness(tester, account);
      expect(find.text('34%'), findsOneWidget);
      denied = true;
      await tester.tap(find.byTooltip('تحديث التقارير'));
      await tester.pumpAndSettle();
      expect(find.text('34%'), findsNothing);
      expect(find.textContaining('وقت التقرير:'), findsNothing);
      expect(
        tester
            .widget<FilledButton>(find.byKey(const Key('health-start')))
            .onPressed,
        isNull,
      );
      expect(tester.takeException(), isNull);
    },
  );
  testWidgets(
    'startup uses the branded background and honors reduced motion without a forced delay',
    (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: MediaQuery(
            data: const MediaQueryData(disableAnimations: true),
            child: const NetworkStartup(),
          ),
        ),
      );
      expect(
        tester.widget<Scaffold>(find.byType(Scaffold)).backgroundColor,
        startupBackground,
      );
      await tester.pump(const Duration(seconds: 5));
      expect(tester.binding.transientCallbackCount, 0);
      await tester.pumpWidget(const MaterialApp(home: Text('جاهز')));
      await tester.pump();
      expect(find.text('جاهز'), findsOneWidget);
    },
  );
}
