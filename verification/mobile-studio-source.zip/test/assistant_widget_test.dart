import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:network_copilot/api.dart';
import 'package:network_copilot/assistant_panel.dart';
import 'package:network_copilot/chat_api.dart';
import 'package:network_copilot/main.dart';
import 'package:network_copilot/markdown_view.dart';
import 'package:network_copilot/ui.dart';

class FakeGateway implements ChatGateway {
  FakeGateway({this.reply, this.failure, this.pending});
  final ChatReply? reply;
  final ApiFailure? failure;
  final Completer<ChatReply>? pending;
  final requests = <List<ChatMessage>>[];
  bool disposed = false;
  int cancellations = 0;

  @override
  Future<ChatReply> send(List<ChatMessage> messages) async {
    requests.add(List.of(messages));
    if (failure != null) {
      throw failure!;
    }
    if (pending != null) {
      return pending!.future;
    }
    return reply ?? const ChatReply(text: 'رد قصير', truncated: false);
  }

  @override
  void cancel() {
    cancellations++;
  }

  @override
  void dispose() {
    disposed = true;
    cancel();
  }
}

Map<String, dynamic> observation(DeviceRead query) => {
  'deviceId': query.connection.deviceId,
  'siteId': 'lab-site',
  'status': 'observed',
  'observedAt': '2026-11-05T08:00:00Z',
  if (query.kind == ReadKind.health)
    'health': {
      'version': '7.24.5 (stable)',
      'uptime': '6h10m',
      'cpuLoad': 4,
      'freeMemory': 830000000,
      'totalMemory': 1073741824,
      'boardName': 'CHR VirtualBox',
    }
  else if (query.kind == ReadKind.interfaces)
    'items': [
      for (var index = 1; index <= 3; index++)
        {
          'id': '*$index',
          'name': 'ether$index',
          'type': 'ether',
          'running': true,
          'disabled': false,
          'mtu': 1500,
          'rxBytes': '1000',
          'txBytes': '2000',
        },
    ]
  else
    'items': [
      {
        'id': '*1',
        'address': '192.168.10.200',
        'macAddress': 'AA:BB:CC:DD:EE:FF',
        'uptime': '2m',
        'bytesIn': '4000',
        'bytesOut': '2000',
      },
    ],
};

Future<void> login(WidgetTester tester) async {
  await tester.enterText(
    find.byKey(const Key('server-url')),
    'https://example.invalid',
  );
  await tester.enterText(
    find.byKey(const Key('access-token')),
    'fixture-app-token',
  );
  await tester.enterText(find.byKey(const Key('device-id')), 'chr-lab');
  await tester.ensureVisible(find.byKey(const Key('connect')));
  await tester.tap(find.byKey(const Key('connect')));
  await tester.pumpAndSettle();
}

void setSize(WidgetTester tester, Size size) {
  tester.view.physicalSize = size;
  tester.view.devicePixelRatio = 1;
  addTearDown(tester.view.resetPhysicalSize);
  addTearDown(tester.view.resetDevicePixelRatio);
}

void main() {
  for (final size in [const Size(390, 844), const Size(1366, 768)]) {
    testWidgets('read pages and explicit chat send at ${size.width}px', (
      tester,
    ) async {
      setSize(tester, size);
      final gateway = FakeGateway(
        reply: const ChatReply(
          text: '### إجابة واضحة\nهذا **شرح مختصر** للقراءة.',
          truncated: false,
        ),
      );
      var interfaceReads = 0;
      await tester.pumpWidget(
        ProviderScope(
          retry: (count, error) => null,
          overrides: [
            deviceReadProvider.overrideWith((ref, query) async {
              if (query.kind == ReadKind.interfaces) {
                interfaceReads++;
              }
              return observation(query);
            }),
            chatGatewayFactoryProvider.overrideWithValue((config) => gateway),
          ],
          child: const CopilotApp(legacyLab: true),
        ),
      );
      await tester.pumpAndSettle();
      await login(tester);
      expect(find.text('7.24.5 (stable)'), findsOneWidget);
      await tester.tap(find.byKey(const Key('nav-interfaces')));
      await tester.pumpAndSettle();
      expect(find.text('ether1'), findsOneWidget);
      await tester.enterText(
        find.byKey(const Key('snapshot-search')),
        'ether2',
      );
      await tester.pumpAndSettle();
      expect(find.text('ether1'), findsNothing);
      expect(interfaceReads, 1);
      await tester.tap(find.byKey(const Key('nav-sessions')));
      await tester.pumpAndSettle();
      expect(find.text('192.168.10.200'), findsOneWidget);
      await tester.tap(find.byKey(const Key('nav-assistant')));
      await tester.pumpAndSettle();
      expect(gateway.requests, isEmpty);
      await tester.enterText(
        find.byKey(const Key('chat-input')),
        'اشرح عدادات الواجهة',
      );
      await tester.pump();
      await tester.tap(find.byKey(const Key('chat-send')));
      await tester.pumpAndSettle();
      expect(gateway.requests.length, 1);
      expect(gateway.requests.single.single.text, 'اشرح عدادات الواجهة');
      expect(find.text('إجابة واضحة'), findsOneWidget);
      expect(find.textContaining('###'), findsNothing);
      expect(find.textContaining('fixture-app-token'), findsNothing);
      expect(tester.takeException(), isNull);
      await tester.tap(find.byKey(const Key('nav-overview')));
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const Key('nav-assistant')));
      await tester.pumpAndSettle();
      expect(find.text('إجابة واضحة'), findsOneWidget);
      expect(gateway.requests.length, 1);
    });
  }

  testWidgets('stop does not display a late reply or retry it', (tester) async {
    setSize(tester, const Size(390, 844));
    final pending = Completer<ChatReply>();
    final gateway = FakeGateway(pending: pending);
    await tester.pumpWidget(
      ProviderScope(
        retry: (count, error) => null,
        overrides: [
          deviceReadProvider.overrideWith(
            (ref, query) async => observation(query),
          ),
          chatGatewayFactoryProvider.overrideWithValue((config) => gateway),
        ],
        child: const CopilotApp(legacyLab: true),
      ),
    );
    await tester.pumpAndSettle();
    await login(tester);
    await tester.tap(find.byKey(const Key('nav-assistant')));
    await tester.pumpAndSettle();
    await tester.enterText(find.byKey(const Key('chat-input')), 'سؤال مؤقت');
    await tester.pump();
    await tester.tap(find.byKey(const Key('chat-send')));
    await tester.pump();
    expect(find.text('جارٍ إعداد الرد…'), findsOneWidget);
    await tester.tap(find.byKey(const Key('chat-stop')));
    await tester.pumpAndSettle();
    pending.complete(
      const ChatReply(text: 'رد قديم يجب تجاهله', truncated: false),
    );
    await tester.pumpAndSettle();
    expect(find.text('رد قديم يجب تجاهله'), findsNothing);
    expect(gateway.requests.length, 1);
    expect(gateway.cancellations, 1);
    expect(tester.takeException(), isNull);
  });

  testWidgets(
    'connection changes clear the chat and discard its pending reply',
    (tester) async {
      setSize(tester, const Size(390, 844));
      const original = LabConnection(
        endpoint: 'https://first.invalid',
        token: 'first-token',
        deviceId: 'first',
      );
      const next = LabConnection(
        endpoint: 'https://second.invalid',
        token: 'second-token',
        deviceId: 'second',
      );
      final pending = Completer<ChatReply>();
      final first = FakeGateway(pending: pending);
      final second = FakeGateway();
      Widget app(LabConnection connection) => ProviderScope(
        overrides: [
          chatGatewayFactoryProvider.overrideWithValue(
            (config) => config == original ? first : second,
          ),
        ],
        child: MaterialApp(
          theme: CopilotTheme.light(),
          home: Directionality(
            textDirection: TextDirection.rtl,
            child: Scaffold(body: AssistantPanel(connection: connection)),
          ),
        ),
      );
      await tester.pumpWidget(app(original));
      await tester.pumpAndSettle();
      await tester.enterText(
        find.byKey(const Key('chat-input')),
        'سياق الاتصال الأول',
      );
      await tester.pump();
      await tester.tap(find.byKey(const Key('chat-send')));
      await tester.pump();
      expect(first.requests.length, 1);
      await tester.pumpWidget(app(next));
      await tester.pumpAndSettle();
      expect(first.disposed, isTrue);
      pending.complete(
        const ChatReply(text: 'رد يخص الاتصال الأول', truncated: false),
      );
      await tester.pumpAndSettle();
      expect(find.text('رد يخص الاتصال الأول'), findsNothing);
      expect(find.text('سياق الاتصال الأول'), findsNothing);
      expect(second.requests, isEmpty);
      expect(tester.takeException(), isNull);
    },
  );

  testWidgets(
    'Markdown renders tables and code as text without loading images',
    (tester) async {
      setSize(tester, const Size(390, 844));
      final fence = String.fromCharCodes([96, 96, 96]);
      final text =
          '### عنوان واضح\n'
          'هذا **نص مهم**.\n\n'
          '| البند | القيمة |\n| --- | --- |\n| MTU | 1500 |\n\n'
          '${fence}routeros\n/ip hotspot active print\n$fence\n'
          '<script>unsafe()</script>\n'
          '![صورة](https://example.invalid/never-load.png)';
      await tester.pumpWidget(
        MaterialApp(
          theme: CopilotTheme.light(),
          home: Directionality(
            textDirection: TextDirection.rtl,
            child: Scaffold(
              body: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: MarkdownView(text: text),
              ),
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();
      expect(find.text('عنوان واضح'), findsOneWidget);
      expect(find.byType(Table), findsOneWidget);
      expect(find.text('/ip hotspot active print'), findsOneWidget);
      expect(find.textContaining('<script>unsafe()</script>'), findsOneWidget);
      expect(find.byType(Image), findsNothing);
      expect(tester.takeException(), isNull);
    },
  );
}
