import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:network_copilot/account_api.dart';
import 'account_test.dart' show MemoryStore;

http.Client parserClient() => MockClient((request) async {
  final root = Directory.current.parent.parent.path;
  final result = await Process.run('node', [
    '$root/apps/server/test/fixtures/account-parser.mjs',
    jsonEncode({
      'method': request.method,
      'path': request.url.path,
      'headers': request.headers,
      'body': request.body,
    }),
  ], workingDirectory: root);
  expect(result.exitCode, 0, reason: 'The local Fastify parser must run.');
  final response = jsonDecode(result.stdout as String) as Map<String, dynamic>;
  return http.Response.bytes(
    utf8.encode(response['body'] as String),
    response['status'] as int,
  );
});

void main() {
  final enabled = Platform.environment['COPILOT_ACCOUNT_WIRE_TEST'] == '1';
  test(
    'bodyless session revocation and JSON refresh/logout pass the real Fastify parser',
    () async {
      final store = MemoryStore();
      final account = AccountController(
        store: store,
        clientFactory: parserClient,
      );
      addTearDown(account.dispose);
      await account.accept({'token': 'fixture-wire-token'});
      expect(await account.request('DELETE', '/v1/sessions/fixture-session'), {
        'ok': true,
      });
      expect(account.signedIn, true);
      await account.refresh();
      expect(account.signedIn, true);
      await account.logout();
      expect(account.signedIn, false);
      expect(store.value, isNull);
    },
    skip: !enabled,
  );
  test(
    'login retains JSON encoding and required request data stays required',
    () async {
      final account = AccountController(
        store: MemoryStore(),
        clientFactory: parserClient,
      );
      addTearDown(account.dispose);
      await account.login('owner@example.test', 'fixture-password');
      expect(account.signedIn, true);
      await expectLater(
        account.request('POST', '/v1/auth/login', auth: false),
        throwsA(isA<AccountFailure>().having((e) => e.status, 'status', 400)),
      );
    },
    skip: !enabled,
  );
}
