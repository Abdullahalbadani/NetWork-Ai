import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:network_copilot/api.dart';
import 'package:network_copilot/main.dart';

void main() {
  test('provider keys redact the access token', () {
    const config = LabConnection(
      endpoint: 'https://example.invalid',
      token: 'test-token-must-not-appear',
      deviceId: 'chr-lab',
    );
    expect(config.toString(), isNot(contains(config.token)));
    expect(
      DeviceRead(config, ReadKind.health).toString(),
      isNot(contains(config.token)),
    );
  });

  testWidgets('a failed refresh removes the previous resource observation', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(390, 844);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    var fail = false;
    await tester.pumpWidget(
      ProviderScope(
        retry: (count, error) => null,
        overrides: [
          deviceReadProvider.overrideWith((ref, query) async {
            if (fail) throw const ApiFailure('تعذر الاتصال بخادم الإدارة.');
            return <String, dynamic>{
              'deviceId': query.connection.deviceId,
              'siteId': 'lab-site',
              'status': 'observed',
              'observedAt': '2026-11-04T14:00:00Z',
              'health': <String, dynamic>{
                'version': '7.24.5 (stable)',
                'uptime': '1h',
                'cpuLoad': 4,
                'freeMemory': 512,
                'totalMemory': 1024,
                'boardName': 'CHR',
              },
            };
          }),
        ],
        child: const CopilotApp(legacyLab: true),
      ),
    );
    await tester.pumpAndSettle();
    await tester.enterText(
      find.byKey(const Key('server-url')),
      'https://example.invalid',
    );
    await tester.enterText(
      find.byKey(const Key('access-token')),
      'fixture-app-token',
    );
    await tester.enterText(find.byKey(const Key('device-id')), 'chr-lab');
    await tester.ensureVisible(find.byKey(const Key('connect')));
    await tester.tap(find.byKey(const Key('connect')));
    await tester.pumpAndSettle();
    expect(find.text('7.24.5 (stable)'), findsOneWidget);
    expect(tester.takeException(), isNull);
    fail = true;
    await tester.tap(find.byKey(const Key('refresh')));
    await tester.pumpAndSettle();
    expect(find.text('الحالة غير معروفة'), findsOneWidget);
    expect(find.text('7.24.5 (stable)'), findsNothing);
    expect(find.textContaining('fixture-app-token'), findsNothing);
  });
}
