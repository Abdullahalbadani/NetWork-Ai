import 'dart:async';
import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:network_copilot/api.dart';
import 'package:network_copilot/chat_api.dart';
import 'package:network_copilot/chat_session.dart';

const connection = LabConnection(
  endpoint: 'https://example.invalid',
  token: 'fixture-access-token-do-not-expose',
  deviceId: 'chr-lab',
);
const question = ChatMessage(ChatRole.user, 'سؤال تجريبي');
const reply = ChatReply(text: 'رد تجريبي', truncated: false);
const validBody = {
  'text': 'رد تجريبي',
  'truncated': false,
  'source': 'gemini',
  'deviceAccess': false,
};

class ControlledGateway implements ChatGateway {
  final requests = <List<ChatMessage>>[];
  final completions = <Completer<ChatReply>>[];
  bool disposed = false;
  int cancellations = 0;

  @override
  Future<ChatReply> send(List<ChatMessage> messages) {
    requests.add(List.of(messages));
    final completer = Completer<ChatReply>();
    completions.add(completer);
    return completer.future;
  }

  @override
  void cancel() {
    cancellations++;
  }

  @override
  void dispose() {
    disposed = true;
    cancel();
  }
}

void main() {
  test(
    'chat posts only the bounded conversation to the configured API',
    () async {
      var calls = 0;
      final api = ChatApi(
        connection,
        clientFactory: () => MockClient.streaming((request, stream) async {
          calls++;
          expect(request.url.toString(), 'https://example.invalid/v1/chat');
          expect(request.method, 'POST');
          expect(request.followRedirects, isFalse);
          expect(
            request.headers['Authorization'],
            'Bearer ${connection.token}',
          );
          final bytes = await stream.expand((chunk) => chunk).toList();
          final body = utf8.decode(bytes);
          expect(body, isNot(contains(connection.token)));
          expect(jsonDecode(body), {
            'messages': [
              {'role': 'user', 'text': question.text},
            ],
          });
          return http.StreamedResponse(
            Stream.value(utf8.encode(jsonEncode(validBody))),
            200,
          );
        }),
      );
      addTearDown(api.dispose);
      final result = await api.send([question]);
      expect(result.text, reply.text);
      expect(calls, 1);
      expect(question.toString(), isNot(contains(question.text)));
    },
  );

  test(
    'provider errors are actionable without exposing raw diagnostics',
    () async {
      const cases = {
        'ai_model_unavailable': 'النموذج المحدد غير متاح',
        'ai_access_denied': 'رفض Gemini صلاحية',
        'ai_rate_limited': 'الخدمة مشغولة',
        'ai_timeout': 'انتهت مهلة',
      };
      for (final entry in cases.entries) {
        var calls = 0;
        final api = ChatApi(
          connection,
          clientFactory: () => MockClient((request) async {
            calls++;
            return http.Response(
              jsonEncode({
                'error': entry.key,
                'privateDiagnostic': connection.token,
              }),
              502,
            );
          }),
        );
        try {
          await expectLater(
            api.send([question]),
            throwsA(
              isA<ApiFailure>().having(
                (error) => error.message,
                'safe, useful message',
                allOf(
                  contains(entry.value),
                  isNot(contains(connection.token)),
                  isNot(contains('privateDiagnostic')),
                ),
              ),
            ),
          );
          expect(calls, 1);
        } finally {
          api.dispose();
        }
      }
    },
  );

  test(
    'malformed, oversized and unexpected device access are rejected',
    () async {
      final bodies = <String>[
        'not-json',
        jsonEncode({...validBody, 'deviceAccess': true}),
        jsonEncode({...validBody, 'source': 'other'}),
        jsonEncode({...validBody, 'text': ''}),
        jsonEncode({...validBody, 'truncated': 'false'}),
        'x' * (128 * 1024 + 1),
      ];
      for (final body in bodies) {
        final api = ChatApi(
          connection,
          clientFactory: () => MockClient((request) async {
            return http.Response.bytes(utf8.encode(body), 200);
          }),
        );
        await expectLater(api.send([question]), throwsA(isA<ApiFailure>()));
        api.dispose();
      }
    },
  );

  test(
    'invalid origin and invalid context never create an HTTP client',
    () async {
      var clients = 0;
      http.Client factory() {
        clients++;
        return MockClient((request) async => http.Response('{}', 200));
      }

      final invalidOrigin = ChatApi(
        const LabConnection(
          endpoint: 'http://example.invalid',
          token: 'fixture-token',
          deviceId: 'chr-lab',
        ),
        clientFactory: factory,
      );
      await expectLater(
        invalidOrigin.send([question]),
        throwsA(isA<ApiFailure>()),
      );
      final invalidContext = ChatApi(connection, clientFactory: factory);
      await expectLater(
        invalidContext.send([
          const ChatMessage(ChatRole.assistant, 'invalid first role'),
        ]),
        throwsA(isA<ApiFailure>()),
      );
      await expectLater(
        invalidContext.send([ChatMessage(ChatRole.user, 'x' * 2001)]),
        throwsA(isA<ApiFailure>()),
      );
      expect(clients, 0);
      invalidOrigin.dispose();
      invalidContext.dispose();
    },
  );

  test('chat deadline closes a request without an automatic retry', () async {
    var calls = 0;
    final completed = Completer<http.Response>();
    final api = ChatApi(
      connection,
      timeout: const Duration(milliseconds: 5),
      clientFactory: () => MockClient((request) {
        calls++;
        return completed.future;
      }),
    );
    await expectLater(api.send([question]), throwsA(isA<ApiFailure>()));
    expect(calls, 1);
    completed.complete(
      http.Response.bytes(utf8.encode(jsonEncode(validBody)), 200),
    );
    await Future<void>.delayed(Duration.zero);
    api.dispose();
  });

  test('context stays within role, size and Unicode boundaries', () {
    final exchanges = List.generate(
      20,
      (index) => ChatExchange(
        question: 'سؤال $index',
        reply: ChatReply(text: '😀' * 1800, truncated: false),
      ),
    );
    final context = buildChatContext(exchanges, 'السؤال الأخير');
    expect(context.length, lessThanOrEqualTo(7));
    expect(context.length.isOdd, isTrue);
    expect(
      context.fold<int>(0, (sum, message) => sum + message.text.length),
      lessThanOrEqualTo(6000),
    );
    for (final entry in context.indexed) {
      expect(entry.$2.text.length, lessThanOrEqualTo(2000));
      expect(
        entry.$2.role,
        entry.$1.isEven ? ChatRole.user : ChatRole.assistant,
      );
      expect(utf8.decode(utf8.encode(entry.$2.text)), entry.$2.text);
    }
    expect(context.last.text, 'السؤال الأخير');
    expect(
      context.where((message) => message.role == ChatRole.assistant).first.text,
      contains('[اقتُطع جزء من هذا الرد]'),
    );
    expect(exchanges.last.reply.text.length, 3600);
  });

  test('failed turns do not become history or trigger retries', () async {
    final gateway = ControlledGateway();
    final session = ChatSession(gateway);
    final failed = session.send('السؤال الأول');
    expect(gateway.requests.length, 1);
    gateway.completions.first.completeError(const ApiFailure('خطأ آمن'));
    expect(await failed, isFalse);
    expect(session.exchanges, isEmpty);
    expect(session.error, 'خطأ آمن');
    expect(gateway.requests.length, 1);
    final success = session.send('السؤال الثاني');
    expect(gateway.requests.last.length, 1);
    expect(gateway.requests.last.single.text, 'السؤال الثاني');
    gateway.completions.last.complete(reply);
    expect(await success, isTrue);
    expect(session.exchanges.single.question, 'السؤال الثاني');
    session.dispose();
  });

  test(
    'cancelled completions cannot overwrite a newer conversation turn',
    () async {
      final gateway = ControlledGateway();
      final session = ChatSession(gateway);
      final old = session.send('طلب قديم');
      expect(await session.send('طلب متزامن'), isFalse);
      expect(gateway.requests.length, 1);
      session.cancel();
      expect(session.busy, isFalse);
      expect(session.notice, contains('قد تكون الخدمة'));
      final fresh = session.send('طلب جديد');
      gateway.completions.first.complete(
        const ChatReply(text: 'رد قديم', truncated: false),
      );
      expect(await old, isFalse);
      expect(session.busy, isTrue);
      expect(session.exchanges, isEmpty);
      gateway.completions.last.complete(reply);
      expect(await fresh, isTrue);
      expect(session.exchanges.single.question, 'طلب جديد');
      session.dispose();
    },
  );

  test(
    'disposing a session discards in-flight data and its local history',
    () async {
      final gateway = ControlledGateway();
      final session = ChatSession(gateway);
      var changes = 0;
      session.addListener(() => changes++);
      final pending = session.send('سؤال خاص بهذا الاتصال');
      session.dispose();
      expect(gateway.disposed, isTrue);
      gateway.completions.first.complete(reply);
      expect(await pending, isFalse);
      expect(session.exchanges, isEmpty);
      expect(changes, 1);
    },
  );
}
