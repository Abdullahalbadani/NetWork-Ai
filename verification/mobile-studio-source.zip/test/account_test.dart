import 'dart:async';
import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:network_copilot/account_api.dart';
import 'package:network_copilot/session_store.dart';

class MemoryStore implements SessionStore {
  String? value;
  bool fail = false;
  @override
  Future<String?> read() async => value;
  @override
  Future<void> write(String next) async {
    if (fail) throw StateError('storage locked');
    value = next;
  }

  @override
  Future<void> clear() async {
    value = null;
  }
}

Map<String, dynamic> profile({
  String role = 'owner',
  bool mfa = false,
  bool password = false,
}) => {
  'user': {'id': 'fixture-user', 'name': 'مالك', 'email': 'owner@example.test'},
  'expiresAt': '2026-11-06T12:00:00Z',
  'mfaRequired': mfa,
  'passwordChangeRequired': password,
  'workspaces': [
    {'id': 'workspace-a', 'name': 'المختبر', 'role': role},
  ],
};
http.Response json(Object value, [int status = 200]) =>
    http.Response.bytes(utf8.encode(jsonEncode(value)), status);

void main() {
  test(
    'switching workspace invalidates a response belonging to the previous workspace',
    () async {
      final pending = Completer<http.Response>(), started = Completer<void>();
      final data = profile();
      (data['workspaces'] as List).add({
        'id': 'workspace-b',
        'name': 'الموقع الثاني',
        'role': 'viewer',
      });
      final account = AccountController(
        store: MemoryStore(),
        clientFactory: () => MockClient((r) async {
          if (r.url.path == '/v1/me') return json(data);
          if (r.url.path == '/v1/stale') {
            started.complete();
            return pending.future;
          }
          return json({'items': []});
        }),
      );
      addTearDown(account.dispose);
      await account.accept({'token': 'fixture-session'});
      final oldRequest = account.request('GET', '/v1/stale');
      await started.future;
      account.selectWorkspace('workspace-b');
      pending.complete(json({'privateOldWorkspace': 'must-not-surface'}));
      await expectLater(
        oldRequest,
        throwsA(
          isA<AccountFailure>().having(
            (e) => e.code,
            'code',
            'operation_cancelled',
          ),
        ),
      );
      expect(account.workspaceId, 'workspace-b');
      expect(account.role, 'viewer');
    },
  );
  test(
    'login stores only the app session and sends bearer plus verified workspace on later requests',
    () async {
      final store = MemoryStore(), requests = <http.Request>[];
      final account = AccountController(
        store: store,
        clientFactory: () => MockClient((r) async {
          requests.add(r);
          if (r.url.path == '/v1/auth/login') {
            return json({'token': 'fixture-session-token'});
          }
          if (r.url.path == '/v1/me') return json(profile());
          return json({'items': []});
        }),
      );
      addTearDown(account.dispose);
      await account.login('owner@example.test', 'fixture-user-password');
      expect(account.signedIn, true);
      expect(account.canManage, true);
      expect(store.value, contains('fixture-session-token'));
      expect(store.value, isNot(contains('fixture-user-password')));
      await account.request('GET', '/v1/devices');
      expect(
        requests.last.headers['Authorization'],
        'Bearer fixture-session-token',
      );
      expect(requests.last.headers['X-Workspace-Id'], 'workspace-a');
      expect(requests.every((r) => !r.followRedirects), true);
      expect(requests.every((r) => !r.headers.containsKey('Cookie')), true);
    },
  );
  test(
    'MFA challenge remains transient and no bearer is issued until verification',
    () async {
      final store = MemoryStore();
      final account = AccountController(
        store: store,
        clientFactory: () => MockClient((r) async {
          if (r.url.path == '/v1/auth/login') {
            return json({
              'challengeId': 'fixture-challenge',
              'mfaRequired': true,
            });
          }
          if (r.url.path == '/v1/auth/verify') {
            return json({'token': 'verified-token'});
          }
          return json(profile());
        }),
      );
      addTearDown(account.dispose);
      final result = await account.login(
        'owner@example.test',
        'fixture-password',
      );
      expect(result['challengeId'], 'fixture-challenge');
      expect(account.signedIn, false);
      expect(store.value, isNull);
      await account.verify('fixture-challenge', '123456', false);
      expect(account.signedIn, true);
      expect(store.value, isNot(contains('123456')));
    },
  );
  test(
    'expired or revoked session clears memory and the protected store, without automatic retry',
    () async {
      final store = MemoryStore();
      int calls = 0;
      bool expired = false;
      final account = AccountController(
        store: store,
        clientFactory: () => MockClient((r) async {
          calls++;
          return expired
              ? json({'error': 'unauthorized'}, 401)
              : json(profile());
        }),
      );
      addTearDown(account.dispose);
      await account.accept({'token': 'revoked-token'});
      expired = true;
      final before = calls;
      await expectLater(
        account.request('GET', '/v1/devices'),
        throwsA(isA<AccountFailure>()),
      );
      expect(calls, before + 1);
      expect(account.signedIn, false);
      expect(store.value, isNull);
    },
  );
  test(
    'offline restoration preserves a protected session for explicit retry and never shows stale profile data',
    () async {
      final store = MemoryStore()
        ..value = jsonEncode({
          'endpoint': 'https://127.0.0.1:3443',
          'token': 'restorable-token',
          'certificate': null,
        });
      bool offline = true;
      final account = AccountController(
        store: store,
        clientFactory: () => MockClient((r) async {
          if (offline) throw http.ClientException('private-network-diagnostic');
          return json(profile());
        }),
      );
      addTearDown(account.dispose);
      await account.restore();
      expect(account.signedIn, false);
      expect(account.restoreError, isNotNull);
      expect(store.value, contains('restorable-token'));
      offline = false;
      await account.restore();
      expect(account.signedIn, true);
      expect(account.restoreError, isNull);
    },
  );
  test(
    'secure storage failure prevents a persistent login and has no plaintext fallback',
    () async {
      final store = MemoryStore()..fail = true;
      final account = AccountController(
        store: store,
        clientFactory: () => MockClient((r) async => json(profile())),
      );
      addTearDown(account.dispose);
      await expectLater(
        account.accept({'token': 'protected-token'}),
        throwsA(
          isA<AccountFailure>().having(
            (e) => e.code,
            'code',
            'secure_storage_failed',
          ),
        ),
      );
      expect(account.signedIn, false);
      expect(store.value, isNull);
    },
  );
  test(
    'viewer capabilities and workspace selection are derived from the authenticated profile',
    () async {
      final account = AccountController(
        store: MemoryStore(),
        clientFactory: () =>
            MockClient((r) async => json(profile(role: 'viewer'))),
      );
      addTearDown(account.dispose);
      await account.accept({'token': 'viewer-token'});
      expect(account.canManage, false);
      expect(account.canChat, false);
      expect(
        () => account.selectWorkspace('foreign-workspace'),
        throwsA(isA<AccountFailure>()),
      );
      final connection = account.connection('r1');
      expect(connection.workspaceId, 'workspace-a');
      expect(connection.toString(), isNot(contains('viewer-token')));
    },
  );
  test(
    'late account response after logout cannot restore an erased session or profile',
    () async {
      final pending = Completer<http.Response>();
      bool delay = false;
      final account = AccountController(
        store: MemoryStore(),
        clientFactory: () =>
            MockClient((r) async => delay ? pending.future : json(profile())),
      );
      addTearDown(account.dispose);
      await account.accept({'token': 'old-token'});
      delay = true;
      final load = account.loadProfile();
      await Future<void>.delayed(Duration.zero);
      await account.forget();
      pending.complete(json(profile()));
      await expectLater(load, throwsA(isA<AccountFailure>()));
      expect(account.profile, isNull);
      expect(account.signedIn, false);
    },
  );
  test(
    'invalid origins, malformed profiles and upstream diagnostics are rejected without disclosure',
    () async {
      final account = AccountController(
        store: MemoryStore(),
        clientFactory: () =>
            MockClient((r) async => json({'raw': 'fixture-secret'}, 500)),
      );
      addTearDown(account.dispose);
      expect(
        () => account.setEndpoint('http://127.0.0.1:3443'),
        throwsA(isA<AccountFailure>()),
      );
      await expectLater(
        account.login('a@example.test', 'fixture-password'),
        throwsA(
          isA<AccountFailure>().having(
            (e) => e.toString(),
            'safe message',
            isNot(contains('fixture-secret')),
          ),
        ),
      );
    },
  );
  test('an old response cannot erase a newer login', () async {
    final pending = Completer<http.Response>();
    bool delay = false;
    final account = AccountController(
      store: MemoryStore(),
      clientFactory: () =>
          MockClient((r) async => delay ? pending.future : json(profile())),
    );
    addTearDown(account.dispose);
    await account.accept({'token': 'old-token'});
    delay = true;
    final old = account.loadProfile();
    final rejected = expectLater(old, throwsA(isA<AccountFailure>()));
    await Future<void>.delayed(Duration.zero);
    await account.forget();
    delay = false;
    await account.accept({'token': 'new-token'});
    pending.complete(json(profile()));
    await rejected;
    expect(account.signedIn, true);
    expect(account.connection('r1').token, 'new-token');
  });
  test(
    'a slow secure-store write completes before the queued logout erasure',
    () async {
      final store = DelayedStore();
      final account = AccountController(
        store: store,
        clientFactory: () => MockClient((r) async => json(profile())),
      );
      addTearDown(account.dispose);
      final login = account.accept({'token': 'pending-store-token'});
      final rejected = expectLater(login, throwsA(isA<AccountFailure>()));
      await store.started.future;
      final cleared = account.forget();
      store.release.complete();
      await rejected;
      await cleared;
      expect(account.signedIn, false);
      expect(store.value, isNull);
    },
  );
  test('a delayed logout belongs to its original session', () async {
    final pending = Completer<http.Response>();
    final account = AccountController(
      store: MemoryStore(),
      clientFactory: () => MockClient(
        (r) async =>
            r.url.path == '/v1/auth/logout' ? pending.future : json(profile()),
      ),
    );
    addTearDown(account.dispose);
    await account.accept({'token': 'old-logout-token'});
    final logout = account.logout();
    final rejected = expectLater(logout, throwsA(isA<AccountFailure>()));
    await Future<void>.delayed(Duration.zero);
    await account.forget();
    await account.accept({'token': 'new-login-token'});
    pending.complete(json({'ok': true}));
    await rejected;
    expect(account.signedIn, true);
    expect(account.connection('r1').token, 'new-login-token');
  });
}

class DelayedStore extends MemoryStore {
  final started = Completer<void>(), release = Completer<void>();
  @override
  Future<void> write(String value) async {
    started.complete();
    await release.future;
    this.value = value;
  }
}
