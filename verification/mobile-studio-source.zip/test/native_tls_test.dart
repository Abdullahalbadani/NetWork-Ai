import 'dart:io';
import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:network_copilot/transport.dart';
import 'package:network_copilot/account_views.dart' show certificateFingerprint;

class NativeHttp extends HttpOverrides {}

void main() {
  test(
    'native transport verifies the selected CA and address without accepting an untrusted certificate',
    () async {
      final directory = await Directory.systemTemp.createTemp(
        'copilot-native-tls-',
      );
      Future<void> certificate(String name, String ip) async {
        final result = await Process.run('openssl', [
          'req',
          '-x509',
          '-newkey',
          'rsa:2048',
          '-nodes',
          '-keyout',
          '${directory.path}/$name.key',
          '-out',
          '${directory.path}/$name.crt',
          '-days',
          '1',
          '-subj',
          '/CN=Fixture Native TLS',
          '-addext',
          'subjectAltName=IP:$ip',
        ]);
        expect(result.exitCode, 0);
      }

      HttpServer? good, bad;
      try {
        await certificate('good', '127.0.0.1');
        await certificate('bad', '192.168.56.10');
        SecurityContext serverContext(String name) => SecurityContext()
          ..useCertificateChain('${directory.path}/$name.crt')
          ..usePrivateKey('${directory.path}/$name.key');
        good = await HttpServer.bindSecure(
          '127.0.0.1',
          0,
          serverContext('good'),
        );
        bad = await HttpServer.bindSecure('127.0.0.1', 0, serverContext('bad'));
        good.listen((request) {
          request.response.write('verified');
          request.response.close();
        });
        bad.listen((request) {
          request.response.write('must not be accepted');
          request.response.close();
        });
        final goodPort = good.port, badPort = bad.port;
        final ca = await File('${directory.path}/good.crt').readAsBytes();
        final fingerprint = await Process.run('openssl', [
          'x509',
          '-in',
          '${directory.path}/good.crt',
          '-noout',
          '-fingerprint',
          '-sha256',
        ]);
        expect(
          certificateFingerprint(utf8.decode(ca)),
          fingerprint.stdout.toString().trim().split('=').last,
        );
        await HttpOverrides.runWithHttpOverrides(() async {
          setLabTrust(null);
          var client = createTransport();
          await expectLater(
            client
                .get(Uri.parse('https://127.0.0.1:$goodPort'))
                .timeout(const Duration(seconds: 5)),
            throwsA(anything),
          );
          client.close();
          setLabTrust(ca);
          client = createTransport();
          final verified = await client.get(
            Uri.parse('https://127.0.0.1:$goodPort'),
          );
          expect(verified.statusCode, 200);
          expect(verified.body, 'verified');
          client.close();
          setLabTrust(await File('${directory.path}/bad.crt').readAsBytes());
          client = createTransport();
          await expectLater(
            client
                .get(Uri.parse('https://127.0.0.1:$badPort'))
                .timeout(const Duration(seconds: 5)),
            throwsA(anything),
          );
          client.close();
        }, NativeHttp());
      } finally {
        setLabTrust(null);
        await good?.close(force: true);
        await bad?.close(force: true);
        await directory.delete(recursive: true);
      }
    },
    skip:
        !Platform.isLinux ||
        Platform.environment['COPILOT_NATIVE_TLS_TEST'] != '1',
  );
}
