import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:network_copilot/account_api.dart';
import 'package:network_copilot/health_api.dart';
import 'health_fixture.dart';

void main() {
  test(
    'health report validates coverage and preserves unknown rates rather than substituting zero',
    () {
      final scan = HealthScan.parse(healthFixture());
      expect(scan.coverage!['unknown'], 2);
      expect(scan.interfaces.last['rxBps'], isNull);
      final invalid = healthFixture();
      invalid['report']['coverage']['unknown'] = 0;
      expect(() => HealthScan.parse(invalid), throwsA(isA<AccountFailure>()));
      final inconsistent = healthFixture();
      inconsistent['report']['findings'][0]['id'] = 'arbitrary-rule';
      expect(
        () => HealthScan.parse(inconsistent),
        throwsA(isA<AccountFailure>()),
      );
    },
  );
  test(
    'AI explanation only includes chosen rule identifiers, states and finite numeric measurements',
    () {
      final value = healthFixture();
      value['report']['findings'][5]['summary'] =
          'private-router-password 192.168.56.10 secret-name';
      value['report']['interfaces'][0]['name'] = 'private-interface-name';
      final scan = HealthScan.parse(value),
          prompt = explanationPrompt(HealthScan.parse(value), {
            'management.services',
          });
      expect(scan.completed, true);
      expect(prompt.length, lessThan(2000));
      for (final text in [
        'private-router-password',
        '192.168.56.10',
        'secret-name',
        'private-interface-name',
      ]) {
        expect(prompt, isNot(contains(text)));
      }
      final data = jsonDecode(prompt.split('\n').last) as Map;
      expect(data['findings'], [
        {'id': 'management.services', 'state': 'warning'},
      ]);
    },
  );
  test('scan request identifiers are independent UUIDs for safe retries', () {
    final first = newScanRequestId(), second = newScanRequestId();
    expect(
      first,
      matches(
        RegExp(
          r'^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$',
        ),
      ),
    );
    expect(first, isNot(second));
  });
}
