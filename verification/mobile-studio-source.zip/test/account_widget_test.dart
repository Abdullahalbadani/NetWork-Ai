import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:network_copilot/account_api.dart';
import 'package:network_copilot/api.dart';
import 'package:network_copilot/main.dart';
import 'account_test.dart' show MemoryStore, profile;

http.Response json(Object data, [int status = 200]) =>
    http.Response.bytes(utf8.encode(jsonEncode(data)), status);
Future<void> signIn(WidgetTester tester) async {
  await tester.enterText(
    find.byKey(const Key('account-email')),
    'owner@example.test',
  );
  await tester.enterText(
    find.byKey(const Key('account-password')),
    'fixture-owner-password',
  );
  await tester.ensureVisible(find.byKey(const Key('account-submit')));
  await tester.tap(find.byKey(const Key('account-submit')));
  await tester.pumpAndSettle();
}

Future<void> harness(
  WidgetTester tester,
  AccountController account,
  double width,
) async {
  tester.view.physicalSize = Size(width, 900);
  tester.view.devicePixelRatio = 1;
  addTearDown(tester.view.resetPhysicalSize);
  addTearDown(tester.view.resetDevicePixelRatio);
  addTearDown(() => tester.pumpWidget(const SizedBox.shrink()));
  await tester.pumpWidget(
    ProviderScope(
      retry: (n, e) => null,
      overrides: [
        accountProvider.overrideWith((ref) => account),
        deviceReadProvider.overrideWith(
          (ref, q) async => {
            'deviceId': q.connection.deviceId,
            'siteId': 'site-a',
            'status': 'observed',
            'observedAt': '2026-11-05T12:00:00Z',
            'health': {
              'version': '7.24.5',
              'uptime': '1h',
              'cpuLoad': 1,
              'freeMemory': 50,
              'totalMemory': 100,
              'boardName': 'CHR',
            },
          },
        ),
      ],
      child: const CopilotApp(),
    ),
  );
  await tester.pumpAndSettle();
}

void main() {
  for (final width in [390.0, 1366.0]) {
    testWidgets('owner creates and edits a site and signs out at ${width}px', (
      tester,
    ) async {
      final sites = <Map<String, dynamic>>[];
      final writes = <Map<String, dynamic>>[];
      final account = AccountController(
        store: MemoryStore(),
        clientFactory: () => MockClient((r) async {
          if (r.url.path == '/v1/auth/login') {
            return json({'token': 'fixture-session'});
          }
          if (r.url.path == '/v1/me') return json(profile());
          if (r.url.path == '/v1/routes') {
            return json({
              'items': [
                {
                  'id': 'local-lab',
                  'cidrs': ['192.168.56.0/24'],
                  'ports': [8443],
                },
              ],
            });
          }
          if (r.url.path == '/v1/sites' && r.method == 'POST') {
            final data = jsonDecode(r.body) as Map<String, dynamic>;
            writes.add(data);
            sites.add({...data, 'id': 'site-a', 'version': 1});
            return json({'id': 'site-a', 'version': 1});
          }
          if (r.url.path == '/v1/sites/site-a' && r.method == 'PATCH') {
            final data = jsonDecode(r.body) as Map<String, dynamic>;
            writes.add(data);
            sites[0] = {...data, 'id': 'site-a', 'version': 2};
            return json({'id': 'site-a', 'version': 2});
          }
          if (r.url.path == '/v1/sites') return json({'items': sites});
          return json({'items': [], 'ok': true});
        }),
      );
      await harness(tester, account, width);
      await signIn(tester);
      expect(find.text('رادار الطوارئ'), findsOneWidget);
      if (width < 1050) {
        await tester.tap(find.byKey(const Key('workspace-nav-more')));
        await tester.pumpAndSettle();
      }
      await tester.tap(find.text('المواقع').last);
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const Key('workspace-add')));
      await tester.pumpAndSettle();
      await tester.enterText(
        find.byType(TextFormField).first,
        'مختبر الاختبار',
      );
      await tester.ensureVisible(find.widgetWithText(FilledButton, 'حفظ'));
      await tester.tap(find.widgetWithText(FilledButton, 'حفظ'));
      await tester.pumpAndSettle();
      expect(find.text('مختبر الاختبار'), findsOneWidget);
      expect(writes.single['routeId'], 'local-lab');
      await tester.tap(find.byTooltip('تعديل الموقع'));
      await tester.pumpAndSettle();
      await tester.enterText(find.byType(TextFormField).first, 'مختبر محدث');
      await tester.ensureVisible(find.widgetWithText(FilledButton, 'حفظ'));
      await tester.tap(find.widgetWithText(FilledButton, 'حفظ'));
      await tester.pumpAndSettle();
      expect(writes.last['version'], 1);
      expect(find.text('مختبر محدث'), findsOneWidget);
      expect(tester.takeException(), isNull);
      await tester.tap(find.byTooltip('الحساب'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('تسجيل الخروج'));
      await tester.pumpAndSettle();
      expect(find.byKey(const Key('account-submit')), findsOneWidget);
      expect(account.signedIn, false);
    });
  }
  testWidgets(
    'MFA enrollment cannot finish until recovery codes have been acknowledged',
    (tester) async {
      bool confirmed = false, enrolled = false;
      final account = AccountController(
        store: MemoryStore(),
        clientFactory: () => MockClient((r) async {
          if (r.url.path == '/v1/auth/login') {
            return json({'token': 'pre-enrollment'});
          }
          if (r.url.path == '/v1/me') return json(profile(mfa: !enrolled));
          if (r.url.path == '/v1/auth/mfa/enroll') {
            return json({
              'totpURI':
                  'otpauth://totp/fixture?secret=JBSWY3DPEHPK3PXP&issuer=Fixture',
              'backupCodes': ['fixture-code-a', 'fixture-code-b'],
            });
          }
          if (r.url.path == '/v1/auth/mfa/confirm') {
            confirmed = true;
            enrolled = true;
            return json({'token': 'enrolled-session'});
          }
          return json({'items': []});
        }),
      );
      await harness(tester, account, 390);
      await signIn(tester);
      await tester.enterText(
        find.byKey(const Key('enroll-password')),
        'fixture-owner-password',
      );
      await tester.tap(find.text('إعداد تطبيق المصادقة'));
      await tester.pumpAndSettle();
      final confirm = find.byKey(const Key('enroll-confirm'));
      expect(tester.widget<FilledButton>(confirm).onPressed, isNull);
      expect(confirmed, false);
      await tester.ensureVisible(find.byKey(const Key('recovery-saved')));
      await tester.tap(find.byKey(const Key('recovery-saved')));
      await tester.pumpAndSettle();
      await tester.enterText(find.byKey(const Key('enroll-code')), '123456');
      await tester.ensureVisible(confirm);
      await tester.tap(confirm);
      await tester.pumpAndSettle();
      expect(confirmed, true);
      expect(find.text('رادار الطوارئ'), findsOneWidget);
      expect(tester.takeException(), isNull);
    },
  );
  testWidgets(
    'viewer sees assigned devices without administration or AI controls',
    (tester) async {
      final account = AccountController(
        store: MemoryStore(),
        clientFactory: () => MockClient((r) async {
          if (r.url.path == '/v1/auth/login') {
            return json({'token': 'viewer-session'});
          }
          if (r.url.path == '/v1/me') return json(profile(role: 'viewer'));
          if (r.url.path == '/v1/sites') {
            return json({
              'items': [
                {
                  'id': 'site-a',
                  'name': 'المختبر',
                  'network': '192.168.56.0/24',
                  'routeId': 'local-lab',
                  'version': 1,
                },
              ],
            });
          }
          if (r.url.path == '/v1/devices') {
            return json({
              'items': [
                {
                  'id': 'device-a',
                  'siteId': 'site-a',
                  'name': 'راوتر تجريبي',
                  'origin': 'https://192.168.56.10:8443',
                  'enabled': true,
                  'version': 1,
                },
              ],
            });
          }
          return json({'items': []});
        }),
      );
      await harness(tester, account, 390);
      await signIn(tester);
      expect(find.byKey(const Key('workspace-add')), findsNothing);
      expect(find.text('المستخدمون'), findsNothing);
      await tester.tap(find.byKey(const Key('workspace-nav-devices')));
      await tester.pumpAndSettle();
      await tester.ensureVisible(find.byKey(const Key('open-device-device-a')));
      await tester.tap(find.byKey(const Key('open-device-device-a')));
      await tester.pumpAndSettle();
      expect(find.byKey(const Key('nav-assistant')), findsNothing);
      expect(find.byTooltip('إدارة الأجهزة'), findsOneWidget);
      expect(tester.takeException(), isNull);
    },
  );
  testWidgets(
    'offline logout during enrollment clears the session and shows an honest notice',
    (tester) async {
      final account = AccountController(
        store: MemoryStore(),
        clientFactory: () => MockClient((r) async {
          if (r.url.path == '/v1/auth/login') {
            return json({'token': 'fixture-enrollment-session'});
          }
          if (r.url.path == '/v1/me') return json(profile(mfa: true));
          if (r.url.path == '/v1/auth/logout') {
            throw http.ClientException('fixture-offline');
          }
          return json({'items': []});
        }),
      );
      await harness(tester, account, 390);
      await signIn(tester);
      await tester.tap(find.byTooltip('خروج'));
      await tester.pumpAndSettle();
      expect(account.signedIn, false);
      expect(find.byKey(const Key('account-submit')), findsOneWidget);
      expect(find.textContaining('تعذر تأكيد الإلغاء'), findsOneWidget);
      expect(tester.takeException(), isNull);
    },
  );
}
