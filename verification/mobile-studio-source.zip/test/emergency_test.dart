import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:network_copilot/account_api.dart';
import 'package:network_copilot/emergency_api.dart';
import 'package:network_copilot/emergency_home.dart';
import 'package:network_copilot/emergency_common.dart';
import 'package:network_copilot/emergency_incident.dart';
import 'package:network_copilot/emergency_repair.dart';
import 'package:network_copilot/emergency_settings.dart';
import 'package:network_copilot/ui.dart';
import 'account_test.dart' show MemoryStore, profile;

final _policy = <String,dynamic>{'intervalSeconds':120,'probesEnabled':false,'securityLogsEnabled':false,'thresholds':{'cpuWarning':80,'cpuHigh':95,'freeMemoryWarning':15,'freeMemoryHigh':5,'freeStorageWarning':15,'freeStorageHigh':5,'temperatureWarning':80,'temperatureHigh':90,'minimumVoltage':null,'minimumSignal':-80,'minimumCcq':60}};
Map<String,dynamic> _device() => {'id':'device-a','siteId':'site-a','name':'راوتر الاختبار','siteName':'الموقع أ','enabled':true,'monitoring':false,'policy':_policy,'version':0,'lastRunAt':DateTime.now().toUtc().toIso8601String(),'lastError':null,'requestId':null,'lastRequestId':null,'coverage':{'measured':12,'total':20,'unknown':8,'unavailable':[{'title':'حرارة الجهاز','reason':'هذا الطراز لم يقدم حساس حرارة مقروءًا.'}]}};
Map<String,dynamic> _incident() => {'id':'incident-a','deviceId':'device-a','siteId':'site-a','deviceName':'راوتر الاختبار','deviceEnabled':true,'siteName':'الموقع أ','state':'open','observation':'alarm','severity':'high','version':1,'lastSeenAt':DateTime.now().toUtc().toIso8601String(),'firstSeenAt':DateTime.now().toUtc().toIso8601String(),'finding':{'rule':'management.plain_service','title':'خدمة إدارة غير مشفرة: telnet','summary':'الخدمة مفعلة؛ هذا لا يثبت أنها مكشوفة للإنترنت.','source':'ip/service','action':'معاينة تأمين خدمة الإدارة','evidence':[{'label':'المنفذ','value':'23'}],'steps':['راجع اعتماد الشبكة على هذه الخدمة.','تحقق من بقاء اتصال HTTPS بعد التغيير.'],'metadata':{'targetId':'*a','serviceName':'telnet'},'repairs':['service.disable_plain']}};
Map<String,dynamic> _operation({String status='preview'}) => {'id':'repair-a','kind':'service.disable_plain','status':status,'version':1,'digest':List.filled(64,'a').join(),'expiresAt':DateTime.now().add(const Duration(minutes:5)).toIso8601String(),'plan':{'kind':'service.disable_plain','targetId':'*a','before':{'.id':'*a','name':'telnet','port':'23','disabled':'false'},'after':{'.id':'*a','name':'telnet','port':'23','disabled':'true'}}};
Future<void> _harness(WidgetTester tester, Widget Function(AccountController) screen, Future<void> Function() exercise, {String role='viewer',double width=390,double scale=1,Map<String,dynamic> Function(http.Request)? response}) async {
 final account=AccountController(store:MemoryStore(),clientFactory:()=>MockClient((request) async {
  final data=request.url.path=='/v1/me'?profile(role:role):response?.call(request)??switch(request.url.path){
   '/v1/emergency/devices'=>{'items':[_device()]},
   '/v1/emergency/incidents'=>{'items':[_incident()],'total':1,'summary':{'active':1,'critical':0}},
   '/v1/emergency/incidents/incident-a'=>{'incident':_incident(),'events':[]},
   '/v1/emergency/incidents/incident-a/repairs'=>{'items':[]},
   '/v1/emergency/incidents/incident-a/repair-options'=>{'grant':null,'actions':[],'radios':[]},
   '/v1/emergency/repairs/repair-a'=>{'operation':_operation(),'title':'تعطيل خدمة الإدارة غير المشفرة','impact':'تتوقف الخدمة غير المشفرة ويُفحص استمرار HTTPS.'},
   _=>{'items':[]},
  };
  return http.Response.bytes(utf8.encode(jsonEncode(data)),200);
 }));
 tester.view.physicalSize=Size(width,1200);tester.view.devicePixelRatio=1;addTearDown(tester.view.resetPhysicalSize);addTearDown(tester.view.resetDevicePixelRatio);
 try { await account.accept({'token':'fixture-session'});await tester.pumpWidget(MaterialApp(theme:CopilotTheme.dark(),builder:(context,child)=>MediaQuery(data:MediaQuery.of(context).copyWith(textScaler:TextScaler.linear(scale)),child:Directionality(textDirection:TextDirection.rtl,child:child!)),home:Scaffold(body:screen(account))));await tester.pumpAndSettle();await exercise();expect(tester.takeException(),isNull); }
 finally { try { await tester.pumpWidget(const SizedBox.shrink()); } finally { account.dispose(); } }
}
void main(){
 test('emergency request IDs are independent UUID v4 and availability is explicit',(){final ids=List.generate(200,(_)=>emergencyRequestId());expect(ids.toSet().length,200);expect(ids.every((v)=>RegExp(r'^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$').hasMatch(v)),true);expect(emergencyTime(null),'لم يُقَس بعد');expect(emergencyAvailabilityNames['unsupported'],'غير مدعوم');});
 for(final width in [320.0,390.0,1366.0]){
  testWidgets('radar wraps real incident action and keeps viewer read-only at $width',(tester)async{
   await _harness(tester,(account)=>EmergencyHome(account:account,onDevice:(_,_) {},onDevices:() {}),()async{
    expect(find.text('رادار الطوارئ'),findsOneWidget);final remedy=find.byKey(const Key('emergency-remedy-incident-a'));await tester.ensureVisible(remedy);expect(find.text('معاينة تأمين خدمة الإدارة'),findsOneWidget);expect(find.text('قياس الآن'),findsNothing);await tester.tap(remedy);await tester.pumpAndSettle();expect(find.text('الدليل المقاس'),findsOneWidget);expect(find.text('استلام متابعة العطل'),findsNothing);expect(find.byKey(const Key('emergency-execute')),findsNothing);
   },width:width,scale:width==390?1.4:1);
  });
 }
 testWidgets('no incidents does not turn unavailable measurements into healthy data',(tester)async{
  await _harness(tester,(account)=>EmergencyHome(account:account,onDevice:(_,_) {},onDevices:() {}),()async{
   expect(find.textContaining('غياب البلاغ لا يثبت'),findsOneWidget);await tester.ensureVisible(find.text('المصادر غير المتاحة وأسبابها'));await tester.tap(find.text('المصادر غير المتاحة وأسبابها'));await tester.pumpAndSettle();expect(find.text('هذا الطراز لم يقدم حساس حرارة مقروءًا.'),findsOneWidget);
  },response:(r)=>r.url.path=='/v1/emergency/incidents'?{'items':[],'total':0,'summary':{'active':0,'critical':0}}:{'items':[_device()]});
 });
 testWidgets('preview cannot write until explicit confirmation; abandoning keeps execution absent',(tester)async{
  final writes=<http.Request>[];
  await _harness(tester,(account)=>EmergencyRepairPage(account:account,id:'repair-a'),()async{
   await tester.ensureVisible(find.byKey(const Key('emergency-execute')));await tester.tap(find.byKey(const Key('emergency-execute')));await tester.pumpAndSettle();expect(find.text('أعتمد التنفيذ'),findsOneWidget);expect(writes,isEmpty);await tester.tap(find.text('عودة'));await tester.pumpAndSettle();expect(writes,isEmpty);
  },role:'owner',width:320,response:(r){if(r.method=='POST')writes.add(r);return {'operation':_operation(),'title':'تعطيل خدمة الإدارة غير المشفرة','impact':'تبقى إدارة HTTPS مطلوبة.'};});
 });
 testWidgets('uncertain operation offers read-only reconciliation and no execute button',(tester)async{
  await _harness(tester,(account)=>EmergencyRepairPage(account:account,id:'repair-a'),()async{
   expect(find.textContaining('قد يكون التغيير قد وصل'),findsOneWidget);expect(find.byKey(const Key('emergency-execute')),findsNothing);await tester.ensureVisible(find.text('التحقق من الحالة دون إعادة التنفيذ'));expect(find.text('التحقق من الحالة دون إعادة التنفيذ'),findsOneWidget);
  },role:'owner',response:(_)=>{'operation':_operation(status:'unknown'),'title':'تعطيل خدمة الإدارة غير المشفرة','impact':'تحقق قبل أي كتابة أخرى.'});
 });
 testWidgets('viewer detail has measured evidence and no write controls',(tester)async{
  await _harness(tester,(account)=>EmergencyIncidentPage(account:account,id:'incident-a',onDevice:(_,_) {}),()async{expect(find.text('المنفذ: 23'),findsOneWidget);expect(find.text('تغيير محكوم على الراوتر'),findsNothing);expect(find.text('إعادة قياس الرادار'),findsNothing);});
 });
 testWidgets('monitor settings preserve existing policy and never send writer credentials on monitor save',(tester)async{
  Map<String,dynamic>? submitted;
  await _harness(tester,(account)=>EmergencySettings(account:account,device:_device()),()async{
   await tester.ensureVisible(find.text('حفظ إعداد المراقبة'));await tester.tap(find.text('حفظ إعداد المراقبة'));await tester.pumpAndSettle();expect(submitted?['policy'],_policy);expect(submitted?['enabled'],false);expect(submitted!.containsKey('password'),false);
  },role:'owner',response:(r){if(r.url.path.endsWith('/monitor')){submitted=jsonDecode(r.body)as Map<String,dynamic>;return{'version':1};}if(r.url.path.endsWith('/write-grant'))return{'grant':null};if(r.url.path.endsWith('/health-profile'))return{'profile':{'version':0,'links':[]}};return{'items':[]};});
 });
 testWidgets('pushed emergency content disappears immediately after account scope is forgotten',(tester)async{
  late AccountController active;
  await _harness(tester,(account){active=account;return EmergencyScopeGuard(account:account,child:const Text('دليل خاص بالمساحة السابقة'));},()async{
   expect(find.text('دليل خاص بالمساحة السابقة'),findsOneWidget);await active.forget();await tester.pumpAndSettle();expect(find.text('دليل خاص بالمساحة السابقة'),findsNothing);expect(find.text('العودة إلى المساحة الحالية'),findsOneWidget);
  });
 });

}
