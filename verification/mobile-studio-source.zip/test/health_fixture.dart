import 'package:network_copilot/health_api.dart';

// Explicit test data; never loaded by the production app.
Map<String, dynamic> healthFixture({String id = 'scan-one', int minute = 35}) {
  final at = '2026-11-07T15:${minute.toString().padLeft(2, '0')}:00.000Z';
  const titles = [
    'اتصال الإدارة الآمن',
    'حمل المعالج',
    'الذاكرة المتاحة',
    'مساحة التخزين',
    'الروابط المطلوبة',
    'خدمات الإدارة غير المشفّرة',
    'قياس الاستقبال والإرسال',
    'الإنترنت وDNS عبر الراوتر',
  ];
  const states = [
    'pass',
    'pass',
    'pass',
    'pass',
    'unknown',
    'warning',
    'pass',
    'unknown',
  ];
  return {
    'id': id,
    'status': 'completed',
    'stage': 'finished',
    'progress': 100,
    'createdAt': at,
    'finishedAt': at,
    'report': {
      'rulesVersion': 1,
      'startedAt': at,
      'completedAt': at,
      'profile': {'version': 0, 'links': []},
      'coverage': {
        'total': 8,
        'measured': 6,
        'passed': 5,
        'warnings': 1,
        'unknown': 2,
      },
      'resources': {
        'cpuLoad': 34,
        'freeMemory': 799000000,
        'totalMemory': 1024000000,
        'freeHddSpace': 80000000,
        'totalHddSpace': 128000000,
        'uptime': '51m34s',
        'version': '7.24.5',
        'observedAt': at,
      },
      'findings': [
        for (var i = 0; i < 8; i++)
          {
            'id': healthRuleIds[i],
            'title': titles[i],
            'state': states[i],
            'observedAt': states[i] == 'unknown' ? null : at,
            'summary': i == 5
                ? 'خدمة إدارة غير مشفّرة مفعّلة. هذا وحده لا يثبت أنها مكشوفة للإنترنت.'
                : i == 4
                ? 'لم تحدد الواجهات المتوقع اتصالها بعد.'
                : i == 7
                ? 'لم تُعتمد نقطة قياس تمر عبر هذا الراوتر ضمن صلاحيات القراءة الحالية.'
                : 'نجح الاختبار المحدد وقت القراءة.',
            'recommendation':
                'راجع الدليل وحدود القياس قبل اتخاذ إجراء على الشبكة.',
            'source': 'test-fixture',
            'evidence': i == 5
                ? [
                    {
                      'label': 'ftp',
                      'value': 'منفذ 21؛ لا توجد قيود عناوين على الخدمة نفسها',
                    },
                  ]
                : [],
          },
      ],
      'interfaces': [
        for (var i = 1; i <= 3; i++)
          {
            'id': '*$i',
            'name': 'ether$i',
            'type': 'ether',
            'running': i != 3,
            'disabled': false,
            'rxBps': i == 1
                ? 12400000
                : i == 2
                ? 2800000
                : null,
            'txBps': i == 1
                ? 4100000
                : i == 2
                ? 600000
                : null,
            'reason': i == 3 ? 'counter_reset' : null,
          },
      ],
      'sampleGapMs': 3120,
      'traffic': [
        for (var i = 0; i < 3; i++)
          for (var j = 1; j <= 2; j++)
            {
              'at':
                  '2026-11-07T15:${minute.toString().padLeft(2, '0')}:0$i.000Z',
              'interfaceId': '*$j',
              'elapsedMs': (i + 1) * 1000,
              'rxBps': [7100000, 10300000, 12400000][i] ~/ j,
              'txBps': [2100000, 3200000, 4100000][i] ~/ j,
            },
      ],
    },
  };
}

Map<String, dynamic> healthSummary(Map<String, dynamic> scan) => {
  ...scan,
  'report': null,
  'coverage': (scan['report'] as Map)['coverage'],
};
