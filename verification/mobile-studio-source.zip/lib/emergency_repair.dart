import 'dart:async';
import 'package:flutter/material.dart';
import 'account_api.dart';
import 'account_views.dart';
import 'emergency_api.dart';
import 'emergency_common.dart';

const _fieldNames = {'.id':'معرّف العنصر', 'name':'الاسم', 'disabled':'معطّل', 'port':'المنفذ', 'servers':'خوادم DNS الثابتة', 'dynamic-servers':'خوادم DNS الديناميكية', 'type':'نوع المنفذ', 'dynamic':'عنصر ديناميكي', 'country':'البلد', 'configuration.country':'البلد', 'frequency':'التردد MHz', 'channel.frequency':'التردد MHz', 'frequency-mode':'نظام التردد', 'master-interface':'الراديو الرئيسي'};
class EmergencyPlan extends StatelessWidget {
  const EmergencyPlan({super.key, required this.before, required this.after});
  final Map<String, dynamic> before, after;
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    for (final entry in before.entries.where((e) => after[e.key] != e.value)) Padding(padding: const EdgeInsets.symmetric(vertical: 10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(_fieldNames[entry.key] ?? entry.key, style: const TextStyle(fontWeight: FontWeight.bold)),
      SelectableText('قبل: ${entry.value}\nبعد: ${after[entry.key]}'),
    ])),
    ExpansionTile(tilePadding: EdgeInsets.zero, title: const Text('هوية العنصر والقيم التي سيتحقق منها الخادم'), children: [for (final entry in before.entries) ListTile(contentPadding: EdgeInsets.zero, title: Text(_fieldNames[entry.key] ?? entry.key), subtitle: SelectableText('${entry.value}'))]),
  ]);
}
class EmergencyRepairPage extends StatefulWidget {
  const EmergencyRepairPage({super.key, required this.account, required this.id});
  final AccountController account; final String id;
  @override
  State<EmergencyRepairPage> createState() => _EmergencyRepairPageState();
}
class _EmergencyRepairPageState extends State<EmergencyRepairPage> with WidgetsBindingObserver {
  late final api = EmergencyApi(widget.account);
  Map<String, dynamic>? data;
  bool busy = false, loading = false, foreground = true;
  String? error;
  Timer? timer;
  @override
  void initState() { super.initState(); WidgetsBinding.instance.addObserver(this); _load(); timer = Timer.periodic(const Duration(seconds: 8), (_) { if (foreground && !busy && !loading && ['running','restoring'].contains(emergencyMap(data?['operation'])['status'])) _load(); }); }
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) { foreground = state == AppLifecycleState.resumed; if (foreground && !loading) _load(); }
  @override
  void dispose() { timer?.cancel(); WidgetsBinding.instance.removeObserver(this); super.dispose(); }
  Future<void> _load() async { if (loading) return; loading = true; try { final value = await api.get('repairs/${widget.id}'); if (mounted) setState(() { data = value; error = null; }); } catch (e) { if (mounted) setState(() { error = accountError(e); if (e is AccountFailure && [401,403,404].contains(e.status)) data = null; }); } finally { if (mounted) setState(() => loading = false); } }
  Future<void> _act(Future<void> Function() action) async {
    setState(() { busy = true; error = null; });
    try { await emergencyMutation(context, widget.account, action); await _load(); }
    catch (e) { if (mounted) setState(() => error = accountError(e)); }
    finally { if (mounted) setState(() => busy = false); }
  }
  Future<void> _execute(Map<String, dynamic> op) async {
    final yes = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(title: const Text('اعتماد التغيير المحدد'), content: SingleChildScrollView(child: Text('${data?['impact'] ?? ''}\n\nسينفذ الخادم التغيير المعروض مرة واحدة ثم يقرأ الحالة للتحقق. هذا الاعتماد يخص هذه المعاينة فقط.')), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('عودة')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('أعتمد التنفيذ'))]));
    if (yes != true || !mounted) return;
    await _act(() async { await api.post('repairs/${widget.id}/execute', {'version': op['version'], 'digest': op['digest']}); });
  }
  Future<void> _restore() => _act(() async {
    final preview = await api.post('repairs/${widget.id}/restore-preview', {}); if (!mounted) return;
    final yes = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(title: const Text('معاينة استعادة القيم'), content: SizedBox(width: 500, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [Text('${preview['impact']}'), EmergencyPlan(before: emergencyMap(preview['before']), after: emergencyMap(preview['after']))]))), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('عودة')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('أعتمد الاستعادة'))]));
    if (yes == true) await api.post('repairs/${widget.id}/restore', {'version': preview['version'], 'digest': preview['digest']});
  });
  @override
  Widget build(BuildContext context) {
    final op = emergencyMap(data?['operation']), plan = emergencyMap(op['plan']), status = '${op['status']}';
    return Scaffold(appBar: AppBar(title: const Text('المعالجة', maxLines: 1, overflow: TextOverflow.ellipsis), actions: [IconButton(tooltip: 'تحديث نتيجة المعالجة', onPressed: loading || busy ? null : _load, icon: const Icon(Icons.refresh))]), body: data == null && loading ? const Center(child: CircularProgressIndicator()) : SingleChildScrollView(padding: const EdgeInsets.all(18), child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 800), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      if (error != null) ...[emergencyMessage(context, error!, error: true, retry: _load), const SizedBox(height: 16)],
      if (data != null) emergencyCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text('${data!['title']}', style: Theme.of(context).textTheme.titleLarge), const SizedBox(height: 14),
        EmergencyBadge(emergencyStatusNames[status] ?? 'حالة غير متاحة', state: status), const SizedBox(height: 14),
        Text('${data!['impact']}'), const SizedBox(height: 12),
        if (['unknown','restore_unknown'].contains(status)) const Text('قد يكون التغيير قد وصل إلى الراوتر. استخدم التحقق من الحالة؛ لا تعِد التنفيذ قبل حسم النتيجة.'),
        if (status == 'verified') const Text('تأكدت القيم المستهدفة واستمرار HTTPS. زوال العطل نفسه يحتاج قياسات الرادار التالية.'),
        if (status == 'preview') Text('تنتهي صلاحية هذه المعاينة: ${emergencyTime(op['expiresAt'])}'),
        if (['running','restoring'].contains(status)) const Padding(padding: EdgeInsets.symmetric(vertical: 16), child: LinearProgressIndicator()),
        EmergencyPlan(before: emergencyMap(plan['before']), after: emergencyMap(plan['after'])),
        const SizedBox(height: 18),
        if (widget.account.canManage) Wrap(spacing: 10, runSpacing: 10, children: [
          if (status == 'preview') FilledButton.icon(key: const Key('emergency-execute'), onPressed: busy ? null : () => _execute(op), icon: const Icon(Icons.verified_user_outlined), label: const Text('اعتماد وتنفيذ التغيير')),
          if (['unknown','restore_unknown'].contains(status)) FilledButton.icon(onPressed: busy ? null : () => _act(() async { await api.post('repairs/${widget.id}/reconcile', {}); }), icon: const Icon(Icons.fact_check_outlined), label: const Text('التحقق من الحالة دون إعادة التنفيذ')),
          if (['verified','unknown'].contains(status)) OutlinedButton.icon(onPressed: busy ? null : _restore, icon: const Icon(Icons.undo), label: const Text('معاينة استعادة القيم السابقة')),
          if (['preview','running','restoring'].contains(status)) OutlinedButton(onPressed: busy ? null : () => _act(() async { await api.post('repairs/${widget.id}/cancel', {}); }), child: Text(status == 'preview' ? 'إلغاء المعاينة' : 'طلب الإيقاف')),
        ]),
        if (busy) const Padding(padding: EdgeInsets.only(top: 16), child: LinearProgressIndicator()),
        const SizedBox(height: 14), Text('العملية: ${op['id']}', style: Theme.of(context).textTheme.bodySmall),
      ])),
    ])))));
  }
}
