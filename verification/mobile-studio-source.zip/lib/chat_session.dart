import 'package:flutter/foundation.dart';

import 'api.dart';
import 'chat_api.dart';

class ChatExchange {
  const ChatExchange({required this.question, required this.reply});
  final String question;
  final ChatReply reply;
}

String _contextExcerpt(String text) {
  if (text.length <= 2000) {
    return text;
  }
  const marker = '\n[اقتُطع جزء من هذا الرد]\n';
  final available = 2000 - marker.length;
  var head = (available * 0.75).floor();
  var tailStart = text.length - (available - head);
  if (text.codeUnitAt(head - 1) >= 0xD800 &&
      text.codeUnitAt(head - 1) <= 0xDBFF) {
    head--;
  }
  if (text.codeUnitAt(tailStart) >= 0xDC00 &&
      text.codeUnitAt(tailStart) <= 0xDFFF) {
    tailStart++;
  }
  return text.substring(0, head) + marker + text.substring(tailStart);
}

List<ChatMessage> buildChatContext(
  List<ChatExchange> exchanges,
  String question,
) {
  final messages = <ChatMessage>[];
  for (final exchange in exchanges) {
    messages.add(ChatMessage(ChatRole.user, exchange.question));
    messages.add(
      ChatMessage(ChatRole.assistant, _contextExcerpt(exchange.reply.text)),
    );
  }
  while (messages.length > 6 ||
      messages.fold<int>(0, (sum, item) => sum + item.text.length) > 4000) {
    messages.removeRange(0, 2);
  }
  messages.add(ChatMessage(ChatRole.user, question));
  return List.unmodifiable(messages);
}

class ChatSession extends ChangeNotifier {
  ChatSession(this._gateway);

  final ChatGateway _gateway;
  final List<ChatExchange> _exchanges = [];
  bool _busy = false;
  bool _disposed = false;
  int _operation = 0;
  String? _pending;
  String? _error;
  String? _notice;

  List<ChatExchange> get exchanges => List.unmodifiable(_exchanges);
  bool get busy => _busy;
  String? get pending => _pending;
  String? get error => _error;
  String? get notice => _notice;

  bool _current(int operation) => !_disposed && operation == _operation;

  Future<bool> send(String draft) async {
    if (_disposed || _busy) {
      return false;
    }
    final question = draft.trim();
    if (question.isEmpty || question.length > 2000) {
      _error = 'اكتب سؤالًا بين حرف واحد و2000 حرف.';
      notifyListeners();
      return false;
    }
    final operation = ++_operation;
    _busy = true;
    _pending = question;
    _error = null;
    _notice = null;
    notifyListeners();
    try {
      final reply = await _gateway.send(buildChatContext(_exchanges, question));
      if (!_current(operation)) {
        return false;
      }
      _exchanges.add(ChatExchange(question: question, reply: reply));
      if (_exchanges.length > 20) {
        _exchanges.removeAt(0);
      }
      return true;
    } catch (error) {
      if (_current(operation)) {
        _error = error is ApiFailure
            ? error.message
            : 'تعذر إكمال الرد الآن. يمكنك المحاولة مجددًا.';
      }
      return false;
    } finally {
      if (_current(operation)) {
        _busy = false;
        _pending = null;
        notifyListeners();
      }
    }
  }

  void cancel() {
    if (_disposed || !_busy) {
      return;
    }
    _operation++;
    _gateway.cancel();
    _busy = false;
    _pending = null;
    _notice = 'تم إيقاف الانتظار. قد تكون الخدمة بدأت معالجة الطلب بالفعل.';
    _error = null;
    notifyListeners();
  }

  void clear() {
    if (_disposed) {
      return;
    }
    _operation++;
    _gateway.cancel();
    _exchanges.clear();
    _busy = false;
    _pending = null;
    _error = null;
    _notice = null;
    notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _operation++;
    _gateway.dispose();
    _exchanges.clear();
    super.dispose();
  }
}
