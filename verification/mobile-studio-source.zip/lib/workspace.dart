import 'dart:async';
import 'package:flutter/material.dart';
import 'account_api.dart';
import 'account_views.dart';
import 'ui.dart';
import 'operations_screen.dart';
import 'card_studio.dart';
import 'emergency_home.dart';

const roleNames = {
  'owner': 'المالك',
  'admin': 'مدير',
  'technician': 'فني',
  'viewer': 'مراقب',
};
const actionNames = {
  'workspace_profile_updated': 'تعديل اسم مساحة الشبكة',
  'command_tariff_saved': 'اعتماد سعر فئة لإحصائيات التفعيل',
  'emergency_ai_requested': 'طلب شرح عطل بالذكاء الاصطناعي',
  'device_trust_rotated': 'تحديث شهادة الراوتر بعد التحقق',
  'emergency_monitor_enabled': 'تفعيل مراقبة الطوارئ',
  'emergency_monitor_disabled': 'إيقاف مراقبة الطوارئ',
  'emergency_scan_requested': 'طلب قياس الرادار',
  'emergency_scan_cancelled': 'إلغاء قياس الرادار',
  'emergency_incident_acknowledged': 'استلام متابعة عطل',
  'emergency_write_grant_enabled': 'تفعيل حساب معالجة الطوارئ',
  'emergency_write_grant_disabled': 'إيقاف حساب معالجة الطوارئ',
  'emergency_repair_started': 'اعتماد معالجة على الراوتر',
  'emergency_restore_started': 'اعتماد استعادة قيم الراوتر',
  'emergency_repair_verified': 'تأكد تطبيق المعالجة',
  'emergency_repair_restored': 'تأكدت استعادة القيم',
  'emergency_repair_unknown': 'نتيجة المعالجة غير محسومة',
  'emergency_repair_restore_unknown': 'نتيجة الاستعادة غير محسومة',
  'emergency_repair_reconciled': 'التحقق من نتيجة المعالجة',
  'operations_plans_created': 'إضافة باقة',
  'operations_plans_updated': 'تعديل باقة',
  'operations_resellers_created': 'إضافة نقطة بيع',
  'operations_resellers_updated': 'تعديل نقطة بيع',
  'operations_subscribers_created': 'إضافة مشترك',
  'operations_subscribers_updated': 'تعديل مشترك',
  'voucher_write_grant_enabled': 'تفعيل حساب إنشاء الكروت',
  'voucher_write_grant_disabled': 'إيقاف حساب إنشاء الكروت',
  'voucher_batch_created': 'توليد مسودة كروت',
  'voucher_batch_approved': 'اعتماد دفعة الكروت',
  'voucher_execution_started': 'بدء إنشاء الكروت على الراوتر',
  'voucher_execution_finished': 'انتهاء محاولة إنشاء الكروت',
  'voucher_batch_cancel_requested': 'طلب إيقاف المتبقي',
  'voucher_print_exported': 'تصدير صفحة كروت للطباعة',
  'portal_draft_saved': 'حفظ مسودة الهوتسبوت',
  'portal_design_approved': 'اعتماد تصميم الهوتسبوت',
  'portal_package_exported': 'تصدير حزمة الهوتسبوت',

  'access_denied': 'محاولة وصول مرفوضة',
  'site_created': 'إنشاء موقع',
  'site_updated': 'تعديل موقع',
  'device_registered': 'تسجيل جهاز',
  'device_updated': 'تعديل جهاز',
  'device_disabled': 'تعطيل جهاز',
  'device_registration': 'التحقق من جهاز',
  'device_secret_rotated': 'تدوير بيانات وصول جهاز',
  'member_created': 'إضافة مستخدم',
  'member_permissions_updated': 'تغيير الصلاحيات',
  'member_disabled': 'تعطيل مستخدم',
  'health_scan_started': 'بدء فحص الراوتر',
  'health_scan_completed': 'حفظ تقرير فحص',
  'health_scan_cancelled': 'إلغاء فحص',
  'health_scan_interrupted': 'تعذر إكمال الفحص',
  'health_profile_updated': 'تعديل إعدادات الفحص',
};

class Workspace extends StatefulWidget {
  const Workspace({
    super.key,
    required this.account,
    required this.onTheme,
    required this.deviceBuilder,
  });
  final AccountController account;
  final VoidCallback onTheme;
  final Widget Function(BuildContext, String, String, VoidCallback)
  deviceBuilder;
  @override
  State<Workspace> createState() => _WorkspaceState();
}

class _WorkspaceState extends State<Workspace> {
  int _tab = 0, _page = 0, _epoch = 0;
  bool _loading = true;
  String _query = '';
  String? _error, _siteId, _deviceId, _deviceName;
  List<Map<String, dynamic>> _sites = [],
      _devices = [],
      _members = [],
      _events = [],
      _sessions = [],
      _securityEvents = [];
  AccountController get account => widget.account;
  List<String> get titles => [
    'الرئيسية',
    'الأجهزة',
    'المواقع',
    if (account.canManage) 'المستخدمون',
    if (account.canManage) 'سجل الإدارة',
    'أمان الحساب',
    'إدارة الشبكة',
    if (account.canManage) 'استوديو الكروت',
  ];
  List<IconData> get icons => [
    Icons.radar,
    Icons.router_outlined,
    Icons.location_on_outlined,
    if (account.canManage) Icons.people_outline,
    if (account.canManage) Icons.history,
    Icons.shield_outlined,
    Icons.storefront_outlined,
    if (account.canManage) Icons.style_outlined,
  ];
  String get section => titles[_tab];
  @override
  void initState() {
    super.initState();
    unawaited(_load());
  }

  @override
  void dispose() {
    _epoch++;
    super.dispose();
  }

  List<Map<String, dynamic>> _items(Map<String, dynamic> data) =>
      (data['items'] as List).cast<Map<String, dynamic>>();
  Future<void> _load() async {
    final epoch = ++_epoch;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final core = await Future.wait([
        account.request('GET', '/v1/sites'),
        account.request('GET', '/v1/devices'),
      ]);
      final sites = _items(core[0]), devices = _items(core[1]);
      List<Map<String, dynamic>> rows = [], extra = [];
      if (section == 'المستخدمون') {
        rows = _items(await account.request('GET', '/v1/members'));
      }
      if (section == 'سجل الإدارة') {
        rows = _items(await account.request('GET', '/v1/audit'));
      }
      if (section == 'أمان الحساب') {
        final security = await Future.wait([
          account.request('GET', '/v1/sessions'),
          account.request('GET', '/v1/security/events'),
        ]);
        rows = _items(security[0]);
        extra = _items(security[1]);
      }
      if (!mounted || epoch != _epoch) return;
      setState(() {
        _sites = sites;
        _devices = devices;
        if (!_sites.any((s) => s['id'] == _siteId)) _siteId = null;
        if (section == 'المستخدمون') _members = rows;
        if (section == 'سجل الإدارة') _events = rows;
        if (section == 'أمان الحساب') {
          _sessions = rows;
          _securityEvents = extra;
        }
        _loading = false;
      });
    } catch (e) {
      if (mounted && epoch == _epoch) {
        setState(() {
          _error = accountError(e);
          _loading = false;
          _sites = [];
          _devices = [];
          _members = [];
          _events = [];
          _sessions = [];
          _securityEvents = [];
        });
      }
    }
  }

  void _select(int value) {
    setState(() {
      _tab = value;
      _query = '';
      _page = 0;
    });
    unawaited(_load());
  }

  Future<bool> _stepUp() async {
    final code = TextEditingController();
    try {
      return await _editor(
        'تأكيد هويتك',
        [EditorField('رمز تطبيق المصادقة', code, number: true)],
        () async {
          await account.stepUp(code.text.trim());
        },
      );
    } finally {
      code.dispose();
    }
  }

  Future<void> _mutation(Future<void> Function() action) async {
    try {
      await action();
    } on AccountFailure catch (e) {
      if (e.code != 'step_up_required') rethrow;
      if (!await _stepUp()) {
        throw const AccountFailure('action_cancelled', 0);
      }
      // The original request was rejected before mutation. A second submission requires explicit MFA confirmation.
      await action();
    }
  }

  Future<bool> _editor(
    String title,
    List<EditorField> fields,
    Future<void> Function() save, {
    Widget Function(StateSetter)? extra,
  }) async {
    bool busy = false;
    String? error;
    final form = GlobalKey<FormState>();
    final route = DialogRoute<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, update) => Dialog(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 620),
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(26),
              child: Form(
                key: form,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      title,
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 24),
                    errorBox(error),
                    for (final field in fields) ...[
                      if (field.certificate) ...[
                        OutlinedButton.icon(
                          onPressed: busy
                              ? null
                              : () async {
                                  try {
                                    final cert = await pickCertificate();
                                    if (cert != null && context.mounted) {
                                      update(
                                        () => field.controller.text = cert,
                                      );
                                    }
                                  } catch (e) {
                                    if (context.mounted) {
                                      update(() => error = accountError(e));
                                    }
                                  }
                                },
                          icon: const Icon(Icons.upload_file_outlined),
                          label: Text(
                            field.controller.text.isEmpty
                                ? 'اختيار ${field.label}'
                                : 'تغيير ${field.label}',
                          ),
                        ),
                        if (field.controller.text.isNotEmpty)
                          SelectableText(
                            'SHA256: ${certificateFingerprint(field.controller.text)}',
                            textDirection: TextDirection.ltr,
                            style: const TextStyle(fontSize: 11),
                          ),
                        if (field.controller.text.isEmpty)
                          const Text(
                            'اختر ملف شهادة CA العامة للراوتر.',
                            style: TextStyle(fontSize: 12),
                          ),
                      ] else
                        TextFormField(
                          controller: field.controller,
                          enabled: !busy,
                          obscureText: field.secret,
                          autocorrect: !field.secret,
                          enableSuggestions: !field.secret,
                          textDirection: field.ltr || field.secret
                              ? TextDirection.ltr
                              : null,
                          keyboardType: field.number
                              ? TextInputType.number
                              : TextInputType.text,
                          maxLength: field.secret ? 256 : field.maxLength,
                          decoration: InputDecoration(
                            labelText: field.label,
                            counterText: '',
                            helperText: field.help,
                          ),
                          validator: (v) =>
                              (v?.trim().length ?? 0) < field.minimum
                              ? '${field.label}: ${field.minimum > 1 ? 'الحد الأدنى ${field.minimum} حرفًا' : 'حقل مطلوب'}.'
                              : null,
                        ),
                      const SizedBox(height: 18),
                    ],
                    if (extra != null) extra(update),
                    const SizedBox(height: 22),
                    Row(
                      children: [
                        Expanded(
                          child: FilledButton(
                            onPressed: busy
                                ? null
                                : () async {
                                    if (!form.currentState!.validate() ||
                                        fields.any(
                                          (f) =>
                                              f.certificate &&
                                              f.controller.text.isEmpty,
                                        )) {
                                      return;
                                    }
                                    update(() {
                                      busy = true;
                                      error = null;
                                    });
                                    try {
                                      await save();
                                      if (dialogContext.mounted) {
                                        Navigator.pop(dialogContext, true);
                                      }
                                    } catch (e) {
                                      if (context.mounted) {
                                        update(() => error = accountError(e));
                                      }
                                    } finally {
                                      if (context.mounted) {
                                        update(() => busy = false);
                                      }
                                    }
                                  },
                            child: Text(busy ? 'جارٍ التحقق والحفظ…' : 'حفظ'),
                          ),
                        ),
                        const SizedBox(width: 12),
                        TextButton(
                          onPressed: busy
                              ? null
                              : () => Navigator.pop(dialogContext, false),
                          child: const Text('إلغاء'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
    final result = await Navigator.of(context, rootNavigator: true).push(route);
    await route.completed;
    return result == true;
  }

  Future<void> _siteEditor([Map<String, dynamic>? existing]) async {
    List<Map<String, dynamic>> routes;
    try {
      routes = _items(await account.request('GET', '/v1/routes'));
    } catch (e) {
      _notice(accountError(e));
      return;
    }
    if (!mounted) return;
    if (routes.isEmpty) {
      _notice('لا يوجد مسار اتصال مخصص لهذه المساحة في إعداد الخادم.');
      return;
    }
    final name = TextEditingController(
          text: existing?['name'] as String? ?? '',
        ),
        network = TextEditingController(
          text: existing?['network'] as String? ?? '192.168.56.0/24',
        );
    String routeId =
        existing?['routeId'] as String? ?? routes.first['id'] as String;
    try {
      final saved = await _editor(
        existing == null ? 'إضافة موقع' : 'تعديل الموقع',
        [
          EditorField('اسم الموقع', name),
          EditorField(
            'نطاق إدارة الأجهزة',
            network,
            ltr: true,
            help: 'مثال: 192.168.56.0/24',
          ),
        ],
        () => _mutation(() async {
          await account.request(
            existing == null ? 'POST' : 'PATCH',
            existing == null ? '/v1/sites' : '/v1/sites/${existing['id']}',
            body: {
              'name': name.text.trim(),
              'network': network.text.trim(),
              'routeId': routeId,
              if (existing != null) 'version': existing['version'],
            },
          );
        }),
        extra: (update) => DropdownButtonFormField<String>(
          initialValue: routeId,
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'مسار الاتصال المخصص'),
          items: routes
              .map(
                (r) => DropdownMenuItem(
                  value: r['id'] as String,
                  child: Text(
                    '${r['id']} — ${(r['cidrs'] as List).join('، ')}',
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              )
              .toList(),
          onChanged: (v) => update(() => routeId = v!),
        ),
      );
      if (saved && mounted) {
        _notice('حُفظ الموقع.');
        await _load();
      }
    } finally {
      name.dispose();
      network.dispose();
    }
  }

  Future<void> _deviceEditor() async {
    if (_sites.isEmpty) {
      _notice('أضف موقعًا قبل تسجيل الجهاز.');
      return;
    }
    final name = TextEditingController(),
        origin = TextEditingController(text: 'https://192.168.56.10:8443'),
        user = TextEditingController(),
        password = TextEditingController(),
        ca = TextEditingController();
    String siteId = _siteId ?? _sites.first['id'] as String;
    try {
      final saved = await _editor(
        'تسجيل راوتر للقراءة',
        [
          EditorField('اسم الجهاز', name),
          EditorField('عنوان HTTPS للراوتر', origin, ltr: true),
          EditorField('اسم مستخدم القراءة', user, ltr: true),
          EditorField('كلمة مرور الراوتر', password, secret: true),
          EditorField('شهادة الراوتر', ca, certificate: true),
        ],
        () => _mutation(() async {
          await account.request(
            'POST',
            '/v1/devices',
            body: {
              'name': name.text.trim(),
              'siteId': siteId,
              'origin': origin.text.trim(),
              'username': user.text,
              'password': password.text,
              'ca': ca.text,
            },
          );
        }),
        extra: (update) => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            DropdownButtonFormField<String>(
              initialValue: siteId,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'الموقع'),
              items: _sites
                  .map(
                    (s) => DropdownMenuItem(
                      value: s['id'] as String,
                      child: Text(s['name'] as String),
                    ),
                  )
                  .toList(),
              onChanged: (v) => update(() => siteId = v!),
            ),
            const SizedBox(height: 16),
            const Text(
              'نتحقق من TLS وقراءة موارد الراوتر قبل تسجيله. لا يتغير إعداد الراوتر.',
              style: TextStyle(fontSize: 13, height: 1.6),
            ),
          ],
        ),
      );
      if (saved && mounted) {
        _notice('نجح التحقق وحُفظ الجهاز.');
        await _load();
      }
    } finally {
      name.dispose();
      origin.dispose();
      user.dispose();
      password.dispose();
      ca.dispose();
    }
  }

  Future<void> _editDevice(Map<String, dynamic> device) async {
    final name = TextEditingController(text: device['name'] as String);
    bool enabled = device['enabled'] as bool;
    String kind = device['kind'] as String? ?? 'router';
    try {
      final saved = await _editor(
        'إعداد سجل الجهاز',
        [EditorField('اسم الجهاز', name)],
        () => _mutation(() async {
          await account.request(
            'PATCH',
            '/v1/devices/${device['id']}',
            body: {
              'name': name.text.trim(),
              'enabled': enabled,
              'kind': kind,
              'version': device['version'],
            },
          );
        }),
        extra: (update) => Column(mainAxisSize: MainAxisSize.min, children: [DropdownButtonFormField<String>(initialValue: kind, isExpanded: true, decoration: const InputDecoration(labelText: 'تصنيف الجهاز في السجل'), items: const [DropdownMenuItem(value: 'router', child: Text('راوتر')), DropdownMenuItem(value: 'access_point', child: Text('أكسس بوينت')), DropdownMenuItem(value: 'antenna', child: Text('أنتينا / ربط لاسلكي')), DropdownMenuItem(value: 'switch', child: Text('سويتش')), DropdownMenuItem(value: 'other', child: Text('أخرى'))], onChanged: (v) { if (v != null) update(() => kind = v); }), const SizedBox(height: 12), SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('السماح بقراءة الجهاز'),
          subtitle: const Text('يتحكم في الوصول من التطبيق.'),
          value: enabled,
          onChanged: (v) => update(() => enabled = v),
        )]),
      );
      if (saved && mounted) await _load();
    } finally {
      name.dispose();
    }
  }

  Future<void> _rotate(Map<String, dynamic> device) async {
    final password = TextEditingController();
    try {
      final saved = await _editor(
        'تحديث بيانات وصول الجهاز',
        [
          EditorField(
            'كلمة المرور الجديدة',
            password,
            secret: true,
            help: 'أدخل كلمة مرور حساب القراءة بعد تغييرها على الراوتر.',
          ),
        ],
        () => _mutation(() async {
          await account.request(
            'POST',
            '/v1/devices/${device['id']}/credential',
            body: {'password': password.text, 'version': device['version']},
          );
        }),
      );
      if (saved && mounted) {
        _notice('نجحت القراءة وحُفظ مرجع الوصول الجديد.');
        await _load();
      }
    } finally {
      password.dispose();
    }
  }

  Future<void> _memberEditor([Map<String, dynamic>? existing]) async {
    final name = TextEditingController(
          text: existing?['name'] as String? ?? '',
        ),
        email = TextEditingController(
          text: existing?['email'] as String? ?? '',
        ),
        password = TextEditingController();
    String role = existing?['role'] as String? ?? 'viewer';
    bool active = existing?['active'] as bool? ?? true;
    final sites = (existing?['siteIds'] as List? ?? []).cast<String>().toSet();
    try {
      final saved = await _editor(
        existing == null ? 'إضافة مستخدم' : 'صلاحيات ${existing['name']}',
        [
          if (existing == null) ...[
            EditorField('الاسم', name),
            EditorField('الحساب', email, ltr: true, maxLength: 254),
            EditorField(
              'كلمة المرور الأولية',
              password,
              secret: true,
              minimum: 14,
              help: 'يُلزم المستخدم بتغييرها وتفعيل المصادقة عند دخوله.',
            ),
          ],
        ],
        () => _mutation(() async {
          await account.request(
            existing == null ? 'POST' : 'PATCH',
            existing == null ? '/v1/members' : '/v1/members/${existing['id']}',
            body: {
              if (existing == null) ...{
                'name': name.text.trim(),
                'email': email.text.trim(),
                'password': password.text,
              },
              'role': role,
              'siteIds': sites.toList(),
              if (existing != null) ...{
                'active': active,
                'version': existing['version'],
              },
            },
          );
        }),
        extra: (update) => Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            DropdownButtonFormField<String>(
              initialValue: role,
              decoration: const InputDecoration(labelText: 'الدور'),
              items:
                  [if (account.role == 'owner') 'admin', 'technician', 'viewer']
                      .map(
                        (r) => DropdownMenuItem(
                          value: r,
                          child: Text(roleNames[r]!),
                        ),
                      )
                      .toList(),
              onChanged: (v) => update(() => role = v!),
            ),
            const SizedBox(height: 16),
            if (role == 'admin')
              const Text(
                'المدير يدير سجلات مساحة العمل وجميع مواقعها. حساب المالك محفوظ من تعديل المدير.',
              )
            else ...[
              Text(
                role == 'technician'
                    ? 'قراءة المواقع المحددة واستخدام المساعد.'
                    : 'قراءة المواقع المحددة.',
              ),
              for (final site in _sites)
                CheckboxListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  value: sites.contains(site['id']),
                  title: Text(site['name'] as String),
                  onChanged: (v) => update(() {
                    v == true
                        ? sites.add(site['id'] as String)
                        : sites.remove(site['id']);
                  }),
                ),
              if (_sites.isEmpty)
                const Text('يمكن إضافة صلاحيات المواقع بعد إنشائها.'),
            ],
            if (existing != null)
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('العضوية مفعلة'),
                subtitle: const Text(
                  'تُلغى جلسات المستخدم عند حفظ تغيير الصلاحيات.',
                ),
                value: active,
                onChanged: (v) => update(() => active = v),
              ),
          ],
        ),
      );
      if (saved && mounted) {
        _notice('حُفظت العضوية.');
        await _load();
      }
    } finally {
      name.dispose();
      email.dispose();
      password.dispose();
    }
  }

  void _notice(String message) {
    if (mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(message)));
    }
  }

  Future<void> _logout() => exitAccount(context, account);

  String _siteName(dynamic id) =>
      _sites.where((s) => s['id'] == id).firstOrNull?['name'] as String? ??
      'موقع غير متاح';
  @override
  Widget build(BuildContext context) {
    if (_deviceId != null) {
      return widget.deviceBuilder(
        context,
        _deviceId!,
        _deviceName!,
        () => setState(() => _deviceId = null),
      );
    }
    final wide = MediaQuery.sizeOf(context).width >= 1050;
    return Scaffold(
      appBar: AppBar(
        title: Text(section, maxLines: 1, overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(
            key: const Key('workspace-refresh'),
            tooltip: 'تحديث البيانات',
            onPressed: _loading ? null : _load,
            icon: const Icon(Icons.refresh),
          ),
          IconButton(
            tooltip: 'تبديل المظهر',
            onPressed: widget.onTheme,
            icon: const Icon(Icons.contrast),
          ),
          PopupMenuButton<String>(
            tooltip: 'الحساب',
            onSelected: (value) {
              if (value == 'logout') unawaited(_logout());
            },
            itemBuilder: (_) => [
              PopupMenuItem(
                enabled: false,
                child: Text(
                  '${account.profile!['user']['name']} · ${roleNames[account.role] ?? ''}',
                ),
              ),
              const PopupMenuItem(value: 'logout', child: Text('تسجيل الخروج')),
            ],
          ),
        ],
      ),
      body: SafeArea(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (wide)
              NavigationRail(
                extended: true,
                minExtendedWidth: 225,
                selectedIndex: _tab,
                onDestinationSelected: _select,
                leading: const Padding(
                  padding: EdgeInsets.all(18),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      BrandMark(size: 35),
                      SizedBox(width: 12),
                      Text(
                        'مساعد الشبكة',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
                destinations: List.generate(
                  titles.length,
                  (i) => NavigationRailDestination(
                    icon: Icon(icons[i]),
                    label: Text(titles[i]),
                  ),
                ),
              ),
            Expanded(child: _body(wide)),
          ],
        ),
      ),
      bottomNavigationBar: wide ? null : NavigationBar(
        selectedIndex: section == 'الرئيسية' ? 0 : section == 'الأجهزة' ? 1 : section == 'إدارة الشبكة' ? 2 : section == 'استوديو الكروت' ? 3 : account.canManage ? 4 : 3,
        onDestinationSelected: (value) async {
          if (value < 3) { _select(titles.indexOf(['الرئيسية', 'الأجهزة', 'إدارة الشبكة'][value])); return; }
          if (account.canManage && value == 3) { _select(titles.indexOf('استوديو الكروت')); return; }
          final selected = await showModalBottomSheet<int>(context: context, builder: (ctx) => SafeArea(child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Padding(padding: EdgeInsets.all(20), child: Text('المزيد', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
            for (var i = 0; i < titles.length; i++) if (!['الرئيسية', 'الأجهزة', 'إدارة الشبكة', if (account.canManage) 'استوديو الكروت'].contains(titles[i])) ListTile(leading: Icon(icons[i]), title: Text(titles[i]), selected: _tab == i, onTap: () => Navigator.pop(ctx, i)),
          ]))));
          if (mounted && selected != null) _select(selected);
        },
        destinations: [
          const NavigationDestination(key: Key('workspace-nav-home'), icon: Icon(Icons.radar), label: 'الرئيسية'),
          const NavigationDestination(key: Key('workspace-nav-devices'), icon: Icon(Icons.router_outlined), label: 'الأجهزة'),
          const NavigationDestination(key: Key('workspace-nav-operations'), icon: Icon(Icons.storefront_outlined), label: 'إدارة الشبكة'),
          if (account.canManage) const NavigationDestination(key: Key('workspace-nav-studio'), icon: Icon(Icons.style_outlined), label: 'الكروت'),
          const NavigationDestination(key: Key('workspace-nav-more'), icon: Icon(Icons.menu), label: 'المزيد'),
        ],
      ),
    );
  }

  Widget _body(bool wide) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.cloud_off_outlined, size: 44),
              const SizedBox(height: 18),
              Text(_error!, textAlign: TextAlign.center),
              const SizedBox(height: 18),
              OutlinedButton(
                onPressed: _load,
                child: const Text('إعادة المحاولة'),
              ),
            ],
          ),
        ),
      );
    }
    if (section == 'الرئيسية') return EmergencyHome(key: ValueKey(account.workspaceId), account: account, onDevices: () => _select(titles.indexOf('الأجهزة')), onDevice: (id, name) => setState(() { _deviceId = id; _deviceName = name; }));
    if (section == 'استوديو الكروت') return CardStudioScreen(key: ValueKey(account.workspaceId), account: account);
    if (section == 'إدارة الشبكة') return OperationsScreen(key: ValueKey(account.workspaceId), account: account, sites: _sites, devices: _devices);
    return SingleChildScrollView(
      key: ValueKey(section),
      padding: EdgeInsets.all(wide ? 32 : 18),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1280),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Wrap(
                alignment: WrapAlignment.spaceBetween,
                crossAxisAlignment: WrapCrossAlignment.center,
                spacing: 16,
                runSpacing: 16,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        section == 'الأجهزة' ? 'شبكتك في مساحة واحدة' : section,
                        style: Theme.of(context).textTheme.headlineSmall
                            ?.copyWith(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        '${account.workspaces.where((w) => w['id'] == account.workspaceId).firstOrNull?['name'] ?? ''} · ${roleNames[account.role] ?? ''}',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                  if (account.canManage &&
                      ['الأجهزة', 'المواقع', 'المستخدمون'].contains(section))
                    FilledButton.icon(
                      key: const Key('workspace-add'),
                      onPressed: section == 'الأجهزة'
                          ? _deviceEditor
                          : section == 'المواقع'
                          ? () => _siteEditor()
                          : () => _memberEditor(),
                      icon: const Icon(Icons.add),
                      label: Text(
                        section == 'الأجهزة'
                            ? 'إضافة جهاز'
                            : section == 'المواقع'
                            ? 'إضافة موقع'
                            : 'إضافة مستخدم',
                      ),
                    ),
                ],
              ),
              if (account.workspaces.length > 1) ...[
                const SizedBox(height: 20),
                DropdownButtonFormField<String>(
                  initialValue: account.workspaceId,
                  decoration: const InputDecoration(labelText: 'مساحة العمل'),
                  items: account.workspaces
                      .map(
                        (w) => DropdownMenuItem(
                          value: w['id'] as String,
                          child: Text(w['name'] as String),
                        ),
                      )
                      .toList(),
                  onChanged: (v) {
                    if (v != null) account.selectWorkspace(v);
                  },
                ),
              ],
              const SizedBox(height: 26),
              if (section == 'الأجهزة') ...[
                Wrap(
                  spacing: 16,
                  runSpacing: 16,
                  children: [
                    _stat(
                      'المواقع المتاحة',
                      _sites.length,
                      Icons.location_on_outlined,
                    ),
                    _stat(
                      'الأجهزة المسجلة',
                      _devices.length,
                      Icons.router_outlined,
                    ),
                    _stat(
                      'سجلات مفعلة',
                      _devices.where((d) => d['enabled'] == true).length,
                      Icons.lock_open_outlined,
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                DropdownButtonFormField<String>(
                  initialValue: _siteId ?? '',
                  decoration: const InputDecoration(
                    labelText: 'تصفية حسب الموقع',
                  ),
                  items: [
                    const DropdownMenuItem(
                      value: '',
                      child: Text('كل المواقع المتاحة'),
                    ),
                    ..._sites.map(
                      (s) => DropdownMenuItem(
                        value: s['id'] as String,
                        child: Text(s['name'] as String),
                      ),
                    ),
                  ],
                  onChanged: (v) => setState(() {
                    _siteId = v == '' ? null : v;
                    _page = 0;
                  }),
                ),
                const SizedBox(height: 18),
              ],
              if (section == 'أمان الحساب')
                _security()
              else ...[
                TextField(
                  key: const Key('workspace-search'),
                  decoration: const InputDecoration(
                    hintText: 'بحث في السجلات المعروضة',
                    prefixIcon: Icon(Icons.search),
                  ),
                  onChanged: (v) => setState(() {
                    _query = v;
                    _page = 0;
                  }),
                ),
                const SizedBox(height: 20),
                _records(),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _stat(String title, int value, IconData icon) => SizedBox(
    width: 220,
    child: Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 14),
            Text(
              '$value',
              style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
            ),
            Text(title),
          ],
        ),
      ),
    ),
  );
  Widget _records() {
    final source = section == 'الأجهزة'
        ? _devices
        : section == 'المواقع'
        ? _sites
        : section == 'المستخدمون'
        ? _members
        : _events;
    final rows = source
        .where(
          (r) =>
              (_siteId == null ||
                  section != 'الأجهزة' ||
                  r['siteId'] == _siteId) &&
              r.values
                  .whereType<String>()
                  .join(' ')
                  .toLowerCase()
                  .contains(_query.toLowerCase()),
        )
        .toList();
    if (rows.isEmpty) {
      return _empty(
        section == 'الأجهزة'
            ? 'لا توجد أجهزة في هذه القائمة.'
            : section == 'المواقع'
            ? 'لا توجد مواقع متاحة.'
            : section == 'المستخدمون'
            ? 'لا توجد عضويات مطابقة.'
            : 'لا توجد أحداث مطابقة.',
      );
    }
    final pages = (rows.length / 10).ceil(), page = _page.clamp(0, pages - 1);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          '${rows.length} سجلًا',
          style: Theme.of(context).textTheme.bodySmall,
        ),
        const SizedBox(height: 12),
        for (final row in rows.skip(page * 10).take(10))
          Padding(
            padding: const EdgeInsets.only(bottom: 14),
            child: section == 'الأجهزة'
                ? _deviceCard(row)
                : section == 'المواقع'
                ? _siteCard(row)
                : section == 'المستخدمون'
                ? _memberCard(row)
                : _auditCard(row),
          ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            IconButton(
              tooltip: 'الصفحة السابقة',
              onPressed: page == 0
                  ? null
                  : () => setState(() => _page = page - 1),
              icon: const Icon(Icons.chevron_right),
            ),
            Text('${page + 1} / $pages'),
            IconButton(
              tooltip: 'الصفحة التالية',
              onPressed: page + 1 >= pages
                  ? null
                  : () => setState(() => _page = page + 1),
              icon: const Icon(Icons.chevron_left),
            ),
          ],
        ),
        if (section == 'سجل الإدارة')
          const Text(
            'تُعرض آخر 100 عملية. يبقى السجل الكامل محفوظًا في قاعدة البيانات.',
            style: TextStyle(fontSize: 12),
          ),
      ],
    );
  }

  Widget _card(Widget child) => Card(
    child: Padding(padding: const EdgeInsets.all(20), child: child),
  );
  Widget _empty(String title) => _card(
    Padding(
      padding: const EdgeInsets.symmetric(vertical: 36),
      child: Column(
        children: [
          const Icon(Icons.inbox_outlined, size: 42),
          const SizedBox(height: 14),
          Text(title, textAlign: TextAlign.center),
        ],
      ),
    ),
  );
  Widget _deviceCard(Map<String, dynamic> d) => _card(
    Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Icon(Icons.router_outlined),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                d['name'] as String,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Chip(
              label: Text(
                d['enabled'] == true ? 'مفعّل في التطبيق' : 'معطّل في التطبيق',
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Text(_siteName(d['siteId'])),
        SelectableText(d['origin'] as String, textDirection: TextDirection.ltr),
        if (d['verifiedAt'] != null)
          Text(
            'آخر تحقق عند التسجيل: ${localTimestamp(d['verifiedAt'] as String)}',
            style: Theme.of(context).textTheme.bodySmall,
          ),
        const SizedBox(height: 18),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            FilledButton.tonalIcon(
              key: Key('open-device-${d['id']}'),
              onPressed: d['enabled'] != true
                  ? null
                  : () => setState(() {
                      _deviceId = d['id'] as String;
                      _deviceName = d['name'] as String;
                    }),
              icon: const Icon(Icons.dashboard_outlined),
              label: const Text('فتح القراءات'),
            ),
            if (account.canManage) ...[
              OutlinedButton(
                onPressed: () => _editDevice(d),
                child: const Text('إعداد السجل'),
              ),
              TextButton.icon(
                onPressed: () => _rotate(d),
                icon: const Icon(Icons.key_outlined),
                label: const Text('تحديث بيانات الوصول'),
              ),
            ],
          ],
        ),
      ],
    ),
  );
  Widget _siteCard(Map<String, dynamic> s) => _card(
    Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Icon(Icons.location_on_outlined),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                s['name'] as String,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            if (account.canManage)
              IconButton(
                tooltip: 'تعديل الموقع',
                onPressed: () => _siteEditor(s),
                icon: const Icon(Icons.edit_outlined),
              ),
          ],
        ),
        const SizedBox(height: 12),
        SelectableText(
          s['network'] as String,
          textDirection: TextDirection.ltr,
        ),
        Text(
          'أجهزة متاحة: ${_devices.where((d) => d['siteId'] == s['id']).length}',
        ),
      ],
    ),
  );
  Widget _memberCard(Map<String, dynamic> m) => _card(
    Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Icon(Icons.person_outline),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                m['name'] as String,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
            Chip(label: Text(roleNames[m['role']] ?? '')),
            if (m['role'] != 'owner' &&
                (account.role == 'owner' || m['role'] != 'admin'))
              IconButton(
                tooltip: 'تعديل الصلاحيات',
                onPressed: () => _memberEditor(m),
                icon: const Icon(Icons.manage_accounts_outlined),
              ),
          ],
        ),
        Text(m['email'] as String),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          children: [
            Chip(
              label: Text(m['active'] == true ? 'عضوية مفعّلة' : 'عضوية معطلة'),
            ),
            Chip(
              label: Text(
                m['mfaEnabled'] == true ? 'المصادقة مفعلة' : 'بانتظار المصادقة',
              ),
            ),
            if (m['passwordChangeRequired'] == true)
              const Chip(label: Text('بانتظار تغيير كلمة المرور')),
          ],
        ),
      ],
    ),
  );
  Widget _auditCard(Map<String, dynamic> e) => _card(
    Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          actionNames[e['action']] ?? e['action'] as String,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        Text(
          '${e['result'] == 'success'
              ? 'نجح'
              : e['result'] == 'denied'
              ? 'رُفض'
              : 'لم ينجح'} · ${localTimestamp(e['occurredAt'] as String)}',
        ),
        Text('بواسطة: ${e['actorName'] ?? e['actorId']}'),
        SelectableText(
          'المرجع: ${e['target']}',
          style: const TextStyle(fontSize: 11),
        ),
      ],
    ),
  );
  Widget _security() => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      _card(
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.verified_user_outlined),
                SizedBox(width: 12),
                Text(
                  'الحساب محمي بتطبيق المصادقة',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ],
            ),
            const SizedBox(height: 18),
            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: [
                OutlinedButton.icon(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute<void>(
                      builder: (_) => PasswordView(account: account),
                    ),
                  ),
                  icon: const Icon(Icons.password),
                  label: const Text('تغيير كلمة المرور'),
                ),
                OutlinedButton.icon(
                  onPressed: _stepUp,
                  icon: const Icon(Icons.verified_outlined),
                  label: const Text('تأكيد الهوية للإدارة'),
                ),
                TextButton.icon(
                  onPressed: _logout,
                  icon: const Icon(Icons.logout),
                  label: const Text('تسجيل الخروج'),
                ),
              ],
            ),
          ],
        ),
      ),
      const SizedBox(height: 24),
      const Text(
        'جلساتك النشطة',
        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
      ),
      const SizedBox(height: 14),
      for (final session in _sessions)
        _card(
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.devices_outlined),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      session['current'] == true ? 'هذا الجهاز' : 'جلسة أخرى',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                  TextButton(
                    onPressed: () async {
                      try {
                        await _mutation(() async {
                          await account.request(
                            'DELETE',
                            '/v1/sessions/${session['id']}',
                          );
                        });
                        if (session['current'] == true) {
                          await account.forget();
                        } else if (mounted) {
                          await _load();
                        }
                      } catch (e) {
                        _notice(accountError(e));
                      }
                    },
                    child: const Text('إلغاء الجلسة'),
                  ),
                ],
              ),
              Text('بدأت: ${localTimestamp(session['createdAt'] as String)}'),
              Text('تنتهي: ${localTimestamp(session['expiresAt'] as String)}'),
              Text(
                (session['userAgent'] as String? ?? 'عميل التطبيق').characters
                    .take(140)
                    .toString(),
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
        ),
      const SizedBox(height: 24),
      const Text(
        'آخر أحداث أمان حسابك',
        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
      ),
      for (final event in _securityEvents.take(10))
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.lock_clock_outlined),
          title: Text(securityActionName(event['action'] as String)),
          subtitle: Text(localTimestamp(event['occurredAt'] as String)),
        ),
    ],
  );
}

class EditorField {
  const EditorField(
    this.label,
    this.controller, {
    this.secret = false,
    this.certificate = false,
    this.ltr = false,
    this.number = false,
    this.minimum = 1,
    this.maxLength = 100,
    this.help,
  });
  final String label;
  final TextEditingController controller;
  final bool secret, certificate, ltr, number;
  final int minimum, maxLength;
  final String? help;
}

String securityActionName(String value) =>
    const {
      'access_denied': 'محاولة وصول مرفوضة',
      'login': 'تسجيل دخول',
      'login_mfa': 'تسجيل دخول بالمصادقة',
      'login_recovery': 'استعادة الدخول',
      'mfa_enrollment_started': 'بدء إعداد المصادقة',
      'mfa_enabled': 'تفعيل المصادقة',
      'step_up': 'تأكيد الهوية',
      'password_changed': 'تغيير كلمة المرور',
      'session_revoked': 'إلغاء جلسة',
      'logout': 'تسجيل خروج',
    }[value] ??
    'إجراء أمان';
