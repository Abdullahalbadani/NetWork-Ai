import 'dart:async';
import 'package:flutter/material.dart';
import 'account_api.dart';
import 'account_views.dart';
import 'emergency_api.dart';
import 'emergency_common.dart';
import 'health_chart.dart';
import 'command_tariffs.dart';
import 'emergency_settings.dart';

const commandRoleNames = {'wan': 'إنترنت WAN', 'lan': 'شبكة داخلية LAN', 'management': 'إدارة', 'uplink': 'ربط رئيسي', 'other': 'غير محدد'};

String commandBytes(num? value) {
  if (value == null) return 'غير متاح';
  if (value >= 1073741824) return '${(value / 1073741824).toStringAsFixed(2)} GiB';
  if (value >= 1048576) return '${(value / 1048576).toStringAsFixed(1)} MiB';
  if (value >= 1024) return '${(value / 1024).toStringAsFixed(1)} KiB';
  return '${value.toStringAsFixed(0)} B';
}

class CommandStatGrid extends StatelessWidget {
  const CommandStatGrid({super.key, required this.items});
  final List<(String, String, IconData)> items;
  @override
  Widget build(BuildContext context) => LayoutBuilder(builder: (context, box) {
    final columns = box.maxWidth >= 850 ? 4 : box.maxWidth >= 430 ? 2 : 1;
    return Wrap(spacing: 12, runSpacing: 12, children: [
      for (final item in items) SizedBox(width: (box.maxWidth - 12 * (columns - 1)) / columns,
        child: emergencyCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(item.$3, color: Theme.of(context).colorScheme.primary),
          const SizedBox(height: 10), Text(item.$2, style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 6), Text(item.$1),
        ]))),
    ]);
  });
}

class CommandOverview extends StatelessWidget {
  const CommandOverview({super.key, required this.devices, required this.worker, required this.onDetails});
  final List<Map<String, dynamic>> devices;
  final Map<String, dynamic> worker;
  final void Function(Map<String, dynamic>) onDetails;
  bool fresh(Map<String, dynamic> d) {
    final date = DateTime.tryParse('${d['lastRunAt']}');
    if (date == null || date.isAfter(DateTime.now().add(const Duration(seconds: 5)))) return false;
    return DateTime.now().difference(date).inSeconds <= (emergencyMap(d['policy'])['intervalSeconds'] as int? ?? 120) * 2 + 60;
  }
  @override
  Widget build(BuildContext context) {
    final enabled = devices.where((d) => d['enabled'] == true).toList();
    final readings = enabled.where((d) => fresh(d) && d['lastError'] == null && emergencyMap(d['commandMetrics'])['managementReadable'] == true).toList();
    final cpus = [for (final d in readings) if (emergencyMap(emergencyMap(d['commandMetrics'])['resources'])['cpuPercent'] is num) emergencyMap(emergencyMap(d['commandMetrics'])['resources'])['cpuPercent'] as num];
    num? sum(String part, String field) {
      if (enabled.isEmpty || readings.length != enabled.length) return null;
      final values = [for (final d in enabled) emergencyMap(emergencyMap(d['commandMetrics'])[part])[field]];
      if (values.any((v) => v is! num)) return null;
      return values.fold<num>(0, (a, b) => a + (b as num));
    }
    String count(num? value) => value == null ? 'غير متاح' : value.toStringAsFixed(0);
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Text('نبض الشبكة والإحصائيات', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 8), const Text('تُحسب ضمن نطاقك الحالي من آخر القراءات المحفوظة. الأرقام المفقودة أو القديمة لا تتحول إلى صفر.'),
      const SizedBox(height: 16), CommandStatGrid(items: [
        ('المواقع ضمن النطاق', '${devices.map((d) => d['siteId']).toSet().length}', Icons.location_on_outlined),
        ('الأجهزة المسجّلة', '${devices.length}', Icons.router_outlined),
        ('راوترات مصنفة في السجل', '${devices.where((d) => (d['kind'] ?? 'router') == 'router').length}', Icons.router),
        ('أكسسات مصنفة في السجل', '${devices.where((d) => d['kind'] == 'access_point').length}', Icons.wifi),
        ('أنتينات مصنفة في السجل', '${devices.where((d) => d['kind'] == 'antenna').length}', Icons.cell_tower_outlined),
        ('قراءة إدارة ناجحة حديثة', '${readings.length} من ${enabled.length}', Icons.verified_outlined),
        ('المراقبة المستمرة مفعّلة', '${enabled.where((d) => d['monitoring'] == true).length}', Icons.radar),
        ('أجهزة معطّلة داخل التطبيق', '${devices.length - enabled.length}', Icons.pause_circle_outline),
        ('أعلى حمل معالج مقاس', cpus.isEmpty ? 'غير متاح' : '${cpus.reduce((a, b) => a > b ? a : b).toStringAsFixed(1)}%', Icons.memory_outlined),
        ('وارد واجهات WAN المعلنة', formatBitRate(sum('wanTraffic', 'rxBps')), Icons.south),
        ('صادر واجهات WAN المعلنة', formatBitRate(sum('wanTraffic', 'txBps')), Icons.north),
        ('جلسات Hotspot النشطة', count(sum('clients', 'activeSessions')), Icons.wifi),
        ('حسابات Hotspot لكل راوتر', count(sum('clients', 'activeAccounts')), Icons.people_outline),
        ('مضيفو Hotspot بانتظار الدخول', count(sum('clients', 'waitingHosts')), Icons.login),
        ('مضيفو Hotspot المتجاوزون للدخول', count(sum('clients', 'bypassedHosts')), Icons.route_outlined),
      ]),
      const SizedBox(height: 12), const Text('RX/TX من منظور منفذ الراوتر، ومتوسط خلال الفاصل بين عينتين؛ لا يعبّر عن سعة خط الإنترنت. حسابات الراوترات ليست عدد أشخاص فريدًا عبر الشبكة.'),
      const SizedBox(height: 12), Text(worker['error'] == null ? 'آخر دورة لعامل المراقبة: ${emergencyTime(worker['lastTickAt'])}' : 'تعذر إكمال دورة عامل المراقبة. راجع تشغيل الخدمة ثم حدّث.'),
      const SizedBox(height: 18), emergencyCard(child: ExpansionTile(tilePadding: EdgeInsets.zero, title: const Text('خريطة المواقع والأجهزة'), subtitle: const Text('تجميع السجلات المعتمدة؛ لا يفترض روابط مادية غير مكتشفة.'), children: [
        for (final site in devices.map((d) => '${d['siteId']}').toSet()) ExpansionTile(title: Text('${devices.firstWhere((d) => '${d['siteId']}' == site)['siteName']}'), children: [
          for (final d in devices.where((d) => '${d['siteId']}' == site)) ListTile(leading: const Icon(Icons.router_outlined), title: Text('${d['name']}'), subtitle: Text(fresh(d) ? 'قراءة حديثة' : 'تحتاج قراءة حديثة'), trailing: const Icon(Icons.chevron_left), onTap: () => onDetails(d)),
        ]),
        if (devices.isEmpty) const ListTile(title: Text('لا توجد أجهزة ظاهرة في هذا النطاق.')),
      ])),
    ]);
  }
}

class CommandActivationSummary extends StatefulWidget {
  const CommandActivationSummary({super.key, required this.account, this.siteId, this.deviceId});
  final AccountController account;
  final String? siteId, deviceId;
  @override
  State<CommandActivationSummary> createState() => _CommandActivationSummaryState();
}
class _CommandActivationSummaryState extends State<CommandActivationSummary> {
  Map<String, dynamic>? data;
  String? error;
  bool loading = false;
  int epoch = 0;
  DateTime selected = DateTime.now().toUtc().add(const Duration(hours: 3));
  String get day => '${selected.year.toString().padLeft(4, '0')}-${selected.month.toString().padLeft(2, '0')}-${selected.day.toString().padLeft(2, '0')}';
  @override
  void initState() { super.initState(); load(); }
  @override
  void didUpdateWidget(CommandActivationSummary oldWidget) { super.didUpdateWidget(oldWidget); if (widget.siteId != oldWidget.siteId || widget.deviceId != oldWidget.deviceId || widget.account != oldWidget.account) { data = null; load(); } }
  @override
  void dispose() { epoch++; super.dispose(); }
  Future<void> load() async {
    final current = ++epoch;
    setState(() { loading = true; error = null; });
    try {
      final result = await EmergencyApi(widget.account).get('activation-statistics', query: {'date': day, 'siteId': ?widget.siteId, 'deviceId': ?widget.deviceId});
      if (mounted && current == epoch) setState(() => data = result);
    } catch (e) { if (mounted && current == epoch) setState(() { error = accountError(e); if (e is AccountFailure && [401, 403, 404].contains(e.status)) data = null; }); }
    finally { if (mounted && current == epoch) setState(() => loading = false); }
  }
  Future<void> prices() async {
    String? device = widget.deviceId;
    try {
      if (device == null) {
        final value = await EmergencyApi(widget.account).get('devices');
        if (!mounted) return;
        final devices = emergencyRows(value['items']).where((v) => widget.siteId == null || v['siteId'] == widget.siteId).toList();
        if (devices.isEmpty) { setState(() => error = 'أضف راوترًا في النطاق الحالي أولًا.'); return; }
        if (devices.length == 1) { device = '${devices.first['id']}'; }
        else { device = await showModalBottomSheet<String>(context: context, builder: (ctx) => EmergencyScopeGuard(account: widget.account, child: SafeArea(child: ListView(shrinkWrap: true, children: [for (final d in devices) ListTile(title: Text('${d['name']}'), subtitle: Text('${d['siteName']}'), onTap: () => Navigator.pop(ctx, '${d['id']}'))])))); }
      }
      final selectedDevice = device;
      if (!mounted || selectedDevice == null) return;
      await Navigator.push(context, MaterialPageRoute<void>(builder: (_) => EmergencyScopeGuard(account: widget.account, child: CommandTariffsPage(account: widget.account, deviceId: selectedDevice))));
      if (mounted) await load();
    } catch (e) { if (mounted) setState(() => error = accountError(e)); }
  }
  @override
  Widget build(BuildContext context) {
    final d = data, tracked = emergencyMap(d?['coverage'])['devices'] as int? ?? 0;
    String number(String key) => d == null || tracked == 0 ? 'غير متاح' : '${d[key] ?? 'غير متاح'}';
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const SizedBox(height: 24), Wrap(alignment: WrapAlignment.spaceBetween, spacing: 12, runSpacing: 10, crossAxisAlignment: WrapCrossAlignment.center, children: [
        Text('الدخول وقيمة تفعيل الكروت', style: Theme.of(context).textTheme.titleLarge),
        OutlinedButton.icon(onPressed: loading ? null : () async {
          final today = DateTime.now().toUtc().add(const Duration(hours: 3));
          final value = await showDatePicker(context: context, initialDate: selected, firstDate: DateTime(2020), lastDate: today);
          if (value != null && mounted) { setState(() { selected = value; data = null; }); await load(); }
        }, icon: const Icon(Icons.calendar_month_outlined), label: Text('$day · عدن')),
        IconButton(tooltip: 'تحديث إحصائيات التفعيل', onPressed: loading ? null : load, icon: const Icon(Icons.refresh)),
        OutlinedButton.icon(onPressed: loading ? null : prices, icon: const Icon(Icons.price_change_outlined), label: const Text('أسعار الفئات')),
      ]),
      const SizedBox(height: 12), if (loading) const LinearProgressIndicator(),
      if (error != null) emergencyMessage(context, error!, error: true, retry: load),
      if (d != null) ...[
        if (tracked == 0) emergencyMessage(context, 'لم يبدأ تتبع الكروت لهذا النطاق. فعّل قراءة المتصلين والتفعيل من إعداد الرادار بحساب المالك أو المدير.'),
        if (tracked > 0 && emergencyMap(d['coverage'])['recentDevices'] != tracked) emergencyMessage(context, 'التتبع لا يملك قراءة حديثة لكل الأجهزة. قد تنقص إحصائيات هذا اليوم؛ راجع المراقبة والاتصال والصلاحيات.'),
        CommandStatGrid(items: [
          ('أول تفعيل مثبت لهذا اليوم', number('firstActivations'), Icons.new_releases_outlined),
          ('قيمة التفعيل المعروفة · ريال يمني', number('activationValueYER'), Icons.payments_outlined),
          ('حسابات رُصد دخولها اليوم', number('loginAccountsObserved'), Icons.login),
          ('حسابات نشطة رُصدت خلال اليوم', number('activeAccountsObserved'), Icons.people_outline),
          ('تفعيلات مجانية', number('freeActivations'), Icons.redeem_outlined),
          ('تفعيلات بسعر غير معروف', number('unknownPrice'), Icons.help_outline),
          ('حسابات بتاريخ أول استخدام غير معلوم', number('unknownFirstUse'), Icons.history),
        ]),
        const SizedBox(height: 14), const Text('القيمة تعكس أسعار الكروت المعروفة التي ثبت أول استخدامها، ولا تثبت تحصيل المال. تُرصد الحسابات دوريًا؛ الجلسة التي تبدأ وتنتهي بين القراءات قد لا تُلتقط. العودة بنفس الكرت لا تضيف قيمة جديدة.'),
        const SizedBox(height: 10), Text('بدأ التتبع في هذا النطاق: ${emergencyTime(emergencyMap(d['coverage'])['startedAt'])}'),
        if (emergencyRows(d['breakdown']).isNotEmpty) emergencyCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text('التوزيع حسب الفئة', style: Theme.of(context).textTheme.titleMedium),
          for (final row in emergencyRows(d['breakdown'])) ListTile(contentPadding: EdgeInsets.zero, title: Text('${row['planName'] ?? 'فئة غير معروفة'}'), subtitle: Text('${row['count']} كرت · سعر الوحدة: ${row['price'] ?? 'غير معروف'}'), trailing: Text(row['valueYER'] == null ? 'غير متاح' : '${row['valueYER']} ر.ي')),
        ])),
        if (emergencyRows(d['resellers']).isNotEmpty) emergencyCard(child: ExpansionTile(tilePadding: EdgeInsets.zero, title: const Text('الموزعون المسجّلون مع الكروت'), subtitle: const Text('يعتمد على الموزع المحفوظ وقت الإصدار؛ لا يثبت تحصيله للثمن.'), children: [
          for (final row in emergencyRows(d['resellers'])) ListTile(contentPadding: EdgeInsets.zero, title: Text('${row['resellerName'] ?? 'الموزع غير مسجّل'}'), subtitle: Text('${row['siteName']} · ${row['count']} تفعيل · ${row['unknownPrice']} بسعر غير معلوم'), trailing: Text('${row['valueYER']} ر.ي')),
        ])),
        if (emergencyRows(d['series']).isNotEmpty) emergencyCard(child: ExpansionTile(tilePadding: EdgeInsets.zero, title: const Text('تاريخ التفعيل خلال 30 يومًا'), children: [
          for (final row in emergencyRows(d['series']).reversed) ListTile(contentPadding: EdgeInsets.zero, title: Text('${row['day']}'), subtitle: Text(row['count'] == null ? 'قبل بدء التتبع' : '${row['count']} تفعيل مثبت'), trailing: Text(row['valueYER'] == null ? 'غير متاح' : '${row['valueYER']} ر.ي')),
        ])),
      ],
    ]);
  }
}

class CommandDevicePage extends StatefulWidget {
  const CommandDevicePage({super.key, required this.account, required this.id, this.sampleId});
  final AccountController account;
  final String id;
  final String? sampleId;
  @override
  State<CommandDevicePage> createState() => _CommandDevicePageState();
}
class _CommandDevicePageState extends State<CommandDevicePage> with WidgetsBindingObserver {
  Map<String, dynamic>? data;
  String? error;
  bool loading = false, starting = false, foreground = true;
  String? notice;
  Timer? timer;
  int epoch = 0;
  @override
  void initState() { super.initState(); WidgetsBinding.instance.addObserver(this); load(); timer = Timer.periodic(const Duration(seconds: 3), (_) { if (foreground && !loading && !starting && pending && ModalRoute.of(context)?.isCurrent == true) load(); }); }
  @override
  void dispose() { epoch++; timer?.cancel(); WidgetsBinding.instance.removeObserver(this); super.dispose(); }
  bool get pending { final d = emergencyMap(data?['device']); return d['requestId'] != null && d['requestId'] != d['lastRequestId']; }
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) { foreground = state == AppLifecycleState.resumed; if (foreground && !loading && !starting) load(); }
  Future<void> scan({bool cancel = false}) async {
    if (starting) return;
    setState(() { starting = true; error = null; notice = null; });
    try {
      final d = emergencyMap(data?['device']);
      await EmergencyApi(widget.account).post('devices/${widget.id}/${cancel ? 'cancel-scan' : 'scan'}', {'requestId': cancel ? d['requestId'] : emergencyRequestId()});
      if (mounted) setState(() => notice = cancel ? 'أُلغي طلب القياس. القراءات السابقة تبقى بتاريخها.' : 'قُبل طلب القياس؛ تُحدّث النتيجة بعد اكتمال قراءة الخادم.');
      if (mounted) await load();
    } catch (e) { if (mounted) setState(() => error = accountError(e)); }
    finally { if (mounted) setState(() => starting = false); }
  }
  Future<void> load() async {
    final current = ++epoch;
    setState(() { loading = true; error = null; });
    try { final result = await EmergencyApi(widget.account).get('devices/${widget.id}/command', query: {'sampleId': ?widget.sampleId}); if (mounted && current == epoch) setState(() => data = result); }
    catch (e) { if (mounted && current == epoch) setState(() { error = accountError(e); if (e is AccountFailure && [401, 403, 404].contains(e.status)) data = null; }); }
    finally { if (mounted && current == epoch) setState(() => loading = false); }
  }
  Widget panel(String title, List<Widget> children) => emergencyCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [Text(title, style: Theme.of(context).textTheme.titleLarge), const SizedBox(height: 14), ...children]));
  @override
  Widget build(BuildContext context) {
    final device = emergencyMap(data?['device']), metrics = emergencyMap(device['metrics']), resources = emergencyMap(metrics['resources']);
    final samples = emergencyRows(data?['samples']);
    final points = <Map<String, dynamic>>[];
    DateTime? start;
    for (final row in samples) { final at = DateTime.tryParse('${row['at']}'); if (at == null) continue; start ??= at; final traffic = emergencyMap(row['traffic']); points.add({'elapsedMs': at.difference(start).inMilliseconds, 'rxBps': traffic['rxBps'], 'txBps': traffic['txBps']}); }
    final ports = emergencyRows(metrics['ports']);
    final last = DateTime.tryParse('${device['lastRunAt']}'), now = DateTime.now();
    final stale = last == null || last.isAfter(now.add(const Duration(seconds: 5))) || now.difference(last).inSeconds > (emergencyMap(device['policy'])['intervalSeconds'] as int? ?? 120) * 2 + 60;
    return Scaffold(appBar: AppBar(title: Text('مركز التحكم · ${device['name'] ?? 'الجهاز'}', maxLines: 1, overflow: TextOverflow.ellipsis), actions: [IconButton(tooltip: 'تحديث النتائج المحفوظة', onPressed: loading ? null : load, icon: const Icon(Icons.refresh))]), body: SingleChildScrollView(padding: const EdgeInsets.all(18), child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 1050), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      if (loading) const LinearProgressIndicator(),
      if (error != null) emergencyMessage(context, error!, error: true, retry: load),
      if (notice != null) emergencyMessage(context, notice!),
      if (data != null) ...[
        Text('${device['siteName'] ?? ''} · آخر قراءة: ${emergencyTime(device['lastRunAt'])}'),
        if (data!['historical'] == true) const Padding(padding: EdgeInsets.only(top: 12), child: Text('هذه عينة محفوظة من الوقت الموضح. حالة الجلسات الحالية تُقرأ عند فتحها بشكل مستقل.')),
        if (stale && data!['historical'] != true) emergencyMessage(context, 'القراءة قديمة أو غير متاحة؛ لا تمثل الحالة الحالية للجهاز. اطلب قياسًا جديدًا أو تحقق من المراقبة.'),
        const SizedBox(height: 12), Wrap(spacing: 12, runSpacing: 10, children: [
          if (widget.account.role != 'viewer' && widget.sampleId == null && device['enabled'] == true) OutlinedButton.icon(onPressed: loading || starting ? null : () => scan(cancel: pending), icon: Icon(pending ? Icons.stop_circle_outlined : Icons.radar), label: Text(pending ? 'إلغاء طلب القياس' : 'طلب قياس جديد')),
          if (widget.account.canManage && widget.sampleId == null && device['enabled'] == true) OutlinedButton.icon(onPressed: () async { await Navigator.push(context, MaterialPageRoute<void>(builder: (_) => EmergencyScopeGuard(account: widget.account, child: EmergencySettings(account: widget.account, device: device)))); if (mounted) await load(); }, icon: const Icon(Icons.tune), label: const Text('إعداد الرادار والمعالجة')),
          OutlinedButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => EmergencyScopeGuard(account: widget.account, child: CommandClientsPage(account: widget.account, id: widget.id)))), icon: const Icon(Icons.people_outline), label: const Text('جلسات Hotspot الحالية وكبار المستهلكين')),
        ]),
        if (pending) const Padding(padding: EdgeInsets.only(top: 12), child: LinearProgressIndicator()),
        const SizedBox(height: 12),
        if (metrics.isEmpty) emergencyMessage(context, 'تحتاج الإحصائيات قراءة جديدة بعد تحديث الخادم. ارجع إلى بطاقة الجهاز واضغط قياس الآن.'),
        CommandStatGrid(items: [
          ('حمل المعالج', resources['cpuPercent'] == null ? 'غير متاح' : '${resources['cpuPercent']}%', Icons.memory_outlined),
          ('الذاكرة المتاحة', commandBytes(resources['freeMemory'] as num?), Icons.storage_outlined),
          ('إجمالي الذاكرة', commandBytes(resources['totalMemory'] as num?), Icons.memory),
          ('التخزين المتاح', commandBytes(resources['freeStorage'] as num?), Icons.save_outlined),
          ('إجمالي التخزين', commandBytes(resources['totalStorage'] as num?), Icons.save),
          ('مدة التشغيل', metrics['uptime'] == null ? 'غير متاح' : '${((metrics['uptime'] as num) / 3600).toStringAsFixed(1)} ساعة', Icons.timer_outlined),
          ('إصدار RouterOS', '${metrics['version'] ?? 'غير متاح'}', Icons.info_outline),
          ('المنافذ في المصدر', '${metrics['portCount'] ?? 'غير متاح'}', Icons.settings_ethernet),
        ]),
        const SizedBox(height: 18), panel('الخطوط وحركة WAN', [
          Text('RX: ${formatBitRate(emergencyMap(metrics['wanTraffic'])['rxBps'] as num?)} · TX: ${formatBitRate(emergencyMap(metrics['wanTraffic'])['txBps'] as num?)}'),
          const SizedBox(height: 8), Text('الفاصل المقاس: ${metrics['intervalSeconds'] ?? 'غير متاح'} ثانية. عيّن أدوار WAN من ملف الفحص؛ لا نجمع المرور الداخلي والخارجي معًا.'),
          HealthTrafficChart(samples: points, interfaceName: 'واجهات WAN المعلنة'),
          Text(metrics['routes'] == null ? 'المسار الافتراضي: غير متاح' : 'مسارات main الافتراضية: ${emergencyMap(metrics['routes'])['active'] ?? 'حالة غير متاحة'} فعّال من ${emergencyMap(metrics['routes'])['total']}'),
          const SizedBox(height: 12),
          for (final row in emergencyRows(metrics['probes'])) ListTile(contentPadding: EdgeInsets.zero, title: Text('${row['target']}'), subtitle: Text('فقد الحزم: ${row['lossPercent']}% · متوسط الرد: ${row['rttMs'] ?? 'غير متاح'} ms')),
          if (emergencyRows(metrics['probes']).isEmpty) const Text('اختبارات الاتصال غير مفعلة أو لم تتوفر نتائجها. نجاح منفذ أو مسار لا يثبت وصول كل خدمات الإنترنت.'),
        ]),
        const SizedBox(height: 18), panel('المنافذ وأدوارها', [
          if (ports.isEmpty) const Text('لا توجد منافذ مقروءة في هذه العينة.'),
          for (final port in ports) ExpansionTile(tilePadding: EdgeInsets.zero, title: Text('${port['name']}'), subtitle: Text('${commandRoleNames[port['role']] ?? 'غير محدد'} · ${port['disabled'] == true ? 'معطل إداريًا' : port['running'] == true ? 'عامل وقت القراءة' : port['running'] == false ? 'غير عامل وقت القراءة' : 'حالة غير متاحة'}'), children: [
            ListTile(contentPadding: EdgeInsets.zero, title: Text('RX: ${formatBitRate(port['rxBps'] as num?)} · TX: ${formatBitRate(port['txBps'] as num?)}'), subtitle: Text('عداد RX: ${port['rxBytes'] ?? 'غير متاح'} B · عداد TX: ${port['txBytes'] ?? 'غير متاح'} B')),
            if (port['reason'] != null) const ListTile(contentPadding: EdgeInsets.zero, title: Text('معدل النقل يحتاج عينتين مستمرتين وعدادات صالحة؛ قد يكون العداد تغيّر أو الجهاز أُعيد تشغيله.')),
          ]),
          if (metrics['portsTruncated'] == true) const Text('تُعرض تفاصيل أول 128 منفذًا مع أولوية للمنافذ المهيأة؛ إجمالي المصدر ظاهر أعلاه.'),
        ]),
        const SizedBox(height: 18), panel('الحساسات واللاسلكي', [
          for (final sensor in emergencyRows(metrics['sensors'])) ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.sensors), title: Text('${sensor['name']}'), trailing: Text('${sensor['value']} ${sensor['unit']}')),
          if (emergencyRows(metrics['sensors']).isEmpty) const Text('لم يتوفر حساس حرارة أو جهد مقروء؛ لا نقدّر قراءة طاقة لهذا الجهاز.'),
          for (final radio in emergencyRows(metrics['radios'])) ListTile(contentPadding: EdgeInsets.zero, title: Text('${radio['name']} · ${radio['driver']}'), subtitle: Text('${radio['registrations']} تسجيل · أدنى إشارة: ${radio['signalMinimum'] ?? 'غير متاح'} dBm · متوسط CCQ: ${radio['ccqAverage'] ?? 'غير متاح'}%')),
          if (emergencyRows(metrics['radios']).isEmpty) const Text('لا توجد تسجيلات لاسلكية مقروءة. CHR لا يقدم دليلًا على جودة راديو فعلي.'),
        ]),
        const SizedBox(height: 18), panel('مصادر القياس', [
          for (final row in emergencyMap(emergencyMap(device['coverage'])['sources']).entries) ListTile(contentPadding: EdgeInsets.zero, title: Text(emergencySourceNames[row.key] ?? row.key), subtitle: Text('${emergencyAvailabilityNames[emergencyMap(row.value)['state']] ?? 'غير متاح'} · ${emergencyTime(emergencyMap(row.value)['at'])}')),
        ]),
        const SizedBox(height: 18), panel('الأحداث الأخيرة', [EmergencyEvents(events: emergencyRows(data?['events']))]),
      ],
    ])))));
  }
}

class CommandClientsPage extends StatefulWidget {
  const CommandClientsPage({super.key, required this.account, required this.id});
  final AccountController account;
  final String id;
  @override
  State<CommandClientsPage> createState() => _CommandClientsPageState();
}
class _CommandClientsPageState extends State<CommandClientsPage> with WidgetsBindingObserver {
  final search = TextEditingController();
  Map<String, dynamic>? data;
  String? error;
  bool loading = false, automatic = false, foreground = true;
  String sort = 'download';
  int epoch = 0, offset = 0;
  Timer? timer, debounce;
  @override
  void initState() { super.initState(); WidgetsBinding.instance.addObserver(this); load(); timer = Timer.periodic(const Duration(seconds: 10), (_) { if (automatic && foreground && !loading) load(); }); }
  @override
  void dispose() { epoch++; timer?.cancel(); debounce?.cancel(); search.dispose(); WidgetsBinding.instance.removeObserver(this); super.dispose(); }
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) { foreground = state == AppLifecycleState.resumed; if (foreground && automatic && !loading) load(); }
  Future<void> load() async {
    final current = ++epoch;
    setState(() { loading = true; error = null; });
    try { final result = await EmergencyApi(widget.account).get('devices/${widget.id}/clients', query: {'offset': '$offset', 'limit': '20', 'q': search.text.trim(), 'sort': sort}); if (mounted && current == epoch) setState(() => data = result); }
    catch (e) { if (mounted && current == epoch) setState(() { error = accountError(e); if (e is AccountFailure && [401, 403, 404].contains(e.status)) data = null; if (e is AccountFailure && e.status == 429) automatic = false; }); }
    finally { if (mounted && current == epoch) setState(() => loading = false); }
  }
  @override
  Widget build(BuildContext context) {
    final total = data?['total'] as int? ?? 0;
    return Scaffold(appBar: AppBar(title: const Text('المتصلون وكبار المستهلكين'), actions: [IconButton(tooltip: 'تحديث الجلسات', onPressed: loading ? null : load, icon: const Icon(Icons.refresh))]), body: SingleChildScrollView(padding: const EdgeInsets.all(18), child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 1000), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const Text('جلسات Hotspot المقروءة من هذا الراوتر. لا نستنتج نوع الهاتف من عنوان MAC، ولا نعرض أسماء المستخدمين أو كلمات المرور.'),
      const SizedBox(height: 12), SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('تحديث كل 10 ثوانٍ أثناء فتح الشاشة'), value: automatic, onChanged: (v) => setState(() => automatic = v)),
      const SizedBox(height: 12), TextField(controller: search, decoration: const InputDecoration(labelText: 'ابحث بعنوان IP أو MAC', prefixIcon: Icon(Icons.search)), onChanged: (_) { debounce?.cancel(); debounce = Timer(const Duration(milliseconds: 500), () { offset = 0; load(); }); }),
      const SizedBox(height: 12), DropdownButtonFormField<String>(initialValue: sort, isExpanded: true, decoration: const InputDecoration(labelText: 'ترتيب المستهلكين'), items: const [DropdownMenuItem(value: 'download', child: Text('معدل التنزيل إلى المشترك')), DropdownMenuItem(value: 'upload', child: Text('معدل الرفع من المشترك')), DropdownMenuItem(value: 'total', child: Text('حجم المرور التراكمي للجلسة'))], onChanged: loading ? null : (v) { if (v != null) { setState(() { sort = v; offset = 0; }); load(); } }),
      const SizedBox(height: 16), if (loading) const LinearProgressIndicator(),
      if (error != null) emergencyMessage(context, error!, error: true, retry: load),
      if (data != null) ...[
        Text('${data!['sessions']} جلسة في المصدر · آخر قراءة: ${emergencyTime(data!['observedAt'])}'),
        const SizedBox(height: 8), const Text('المعدلات تحتاج قراءتين مستمرتين خلال دقيقتين؛ حدّث بعد ثوانٍ لقياس الفرق. العداد التراكمي ليس سرعة حالية.'),
        const SizedBox(height: 14), if (emergencyRows(data!['items']).isEmpty) emergencyMessage(context, 'لا توجد جلسات مطابقة لهذه التصفية وقت القراءة.'),
        for (final row in emergencyRows(data!['items'])) emergencyCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text('${row['address'] ?? 'عنوان غير متاح'}', textDirection: TextDirection.ltr, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8), Text('${row['macAddress'] ?? 'هوية غير متاحة'}', textDirection: TextDirection.ltr),
          const SizedBox(height: 12), Text('تنزيل إلى المشترك: ${formatBitRate(row['downloadBps'] as num?)} · رفع منه: ${formatBitRate(row['uploadBps'] as num?)}'),
          const SizedBox(height: 8), Text('حجم الجلسة: وارد ${commandBytes(num.tryParse('${row['bytesIn']}'))} · صادر ${commandBytes(num.tryParse('${row['bytesOut']}'))}'),
          const SizedBox(height: 8), Text('مدة الجلسة: ${row['uptime'] ?? 'غير متاح'}'),
          if (row['reason'] != null) const Padding(padding: EdgeInsets.only(top: 8), child: Text('المعدل غير متاح لعدم اكتمال العينتين أو تغير الجلسة أو العداد.')),
        ])),
        const SizedBox(height: 14), Wrap(alignment: WrapAlignment.center, spacing: 14, runSpacing: 10, crossAxisAlignment: WrapCrossAlignment.center, children: [
          OutlinedButton(onPressed: loading || offset == 0 ? null : () { offset -= 20; load(); }, child: const Text('السابق')),
          Text('${total == 0 ? 0 : offset + 1} — ${offset + 20 > total ? total : offset + 20} من $total'),
          OutlinedButton(onPressed: loading || offset + 20 >= total ? null : () { offset += 20; load(); }, child: const Text('التالي')),
        ]),
      ],
    ])))));
  }
}
