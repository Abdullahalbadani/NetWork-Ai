import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:http/http.dart' as http;
import 'transport.dart';
import 'session_expiry.dart';

const localLab =
    kIsWeb && kDebugMode && bool.fromEnvironment('COPILOT_LOCAL_LAB');

class LabConnection {
  const LabConnection({
    required this.endpoint,
    required this.token,
    required this.deviceId,
    this.workspaceId,
  });
  final String endpoint, token, deviceId;
  final String? workspaceId;
  @override
  bool operator ==(Object other) =>
      other is LabConnection &&
      other.endpoint == endpoint &&
      other.token == token &&
      other.deviceId == deviceId &&
      other.workspaceId == workspaceId;
  @override
  int get hashCode => Object.hash(endpoint, token, deviceId, workspaceId);
  @override
  String toString() => 'LabConnection(deviceId: $deviceId)';
}

enum ReadKind {
  health('health'),
  interfaces('interfaces'),
  hotspotSessions('hotspot-sessions');

  const ReadKind(this.path);
  final String path;
}

class DeviceRead {
  const DeviceRead(this.connection, this.kind);
  final LabConnection connection;
  final ReadKind kind;
  @override
  bool operator ==(Object other) =>
      other is DeviceRead &&
      other.connection == connection &&
      other.kind == kind;
  @override
  int get hashCode => Object.hash(connection, kind);
  @override
  String toString() => 'DeviceRead(${kind.name}, ${connection.deviceId})';
}

class ApiFailure implements Exception {
  const ApiFailure(this.message);
  final String message;
  @override
  String toString() => message;
}

bool validEndpoint(String value) {
  final uri = Uri.tryParse(value);
  if (uri == null ||
      uri.host.isEmpty ||
      uri.userInfo.isNotEmpty ||
      uri.hasQuery ||
      uri.hasFragment ||
      (uri.path.isNotEmpty && uri.path != '/')) {
    return false;
  }
  return uri.scheme == 'https' ||
      (localLab &&
          uri.scheme == 'http' &&
          uri.host == '127.0.0.1' &&
          uri.port == 3000);
}

final deviceReadProvider = FutureProvider.autoDispose
    .family<Map<String, dynamic>, DeviceRead>((ref, read) async {
      final config = read.connection;
      if (!validEndpoint(config.endpoint)) {
        throw const ApiFailure('استخدم عنوان خادم HTTPS صالحًا.');
      }
      final client = createTransport();
      ref.onDispose(client.close);
      final uri = Uri.parse(config.endpoint).replace(
        pathSegments: ['v1', 'devices', config.deviceId, read.kind.path],
      );
      final request = http.Request('GET', uri)
        ..followRedirects = false
        ..headers['Authorization'] = 'Bearer ${config.token}';
      if (config.workspaceId != null) {
        request.headers['X-Workspace-Id'] = config.workspaceId!;
      }
      final stream = await client
          .send(request)
          .timeout(const Duration(seconds: 12));
      final response = await http.Response.fromStream(
        stream,
      ).timeout(const Duration(seconds: 12));
      if (response.statusCode == 401 && config.workspaceId != null) {
        SessionExpiry.report(config.endpoint, config.token);
      }
      if (response.statusCode != 200) {
        throw ApiFailure(switch (response.statusCode) {
          401 => 'رمز الوصول غير صالح. راجع إعداد الاتصال.',
          404 => 'الجهاز غير متاح لهذا الحساب. راجع المعرّف والصلاحيات.',
          _ => 'تعذرت قراءة هذا القسم من الراوتر. تحقق من الاتصال ودعم الخدمة.',
        });
      }
      final data = jsonDecode(response.body);
      if (data is! Map<String, dynamic> ||
          data['deviceId'] != config.deviceId ||
          data['status'] != 'observed' ||
          data['observedAt'] is! String ||
          DateTime.tryParse(data['observedAt'] as String) == null) {
        throw const ApiFailure('استجابة الجهاز غير مكتملة. أعد القراءة.');
      }
      if (read.kind == ReadKind.health) {
        final health = data['health'];
        if (health is! Map<String, dynamic> ||
            health['version'] is! String ||
            health['uptime'] is! String ||
            health['cpuLoad'] is! num ||
            health['freeMemory'] is! num ||
            health['totalMemory'] is! num ||
            (health['totalMemory'] as num) <= 0) {
          throw const ApiFailure('بيانات الموارد غير صالحة.');
        }
      } else if (data['items'] is! List ||
          (data['items'] as List).any(
            (item) => item is! Map<String, dynamic>,
          )) {
        throw const ApiFailure('قائمة الجهاز غير صالحة.');
      }
      return data;
    });
