import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:http/io_client.dart';

Uint8List? _labCa;
void setLabTrust(Uint8List? certificate) {
  if (!kDebugMode && certificate != null) {
    throw StateError('Private lab trust is available in debug builds only.');
  }
  _labCa = certificate;
}

http.Client createTransport() {
  final context = SecurityContext(withTrustedRoots: true);
  if (kDebugMode && _labCa != null) {
    context.setTrustedCertificatesBytes(_labCa!);
  }
  // Hostname, certificate chain and validity checks remain enabled. Redirects are disabled by each request.
  return IOClient(
    HttpClient(context: context)
      ..connectionTimeout = const Duration(seconds: 10),
  );
}
