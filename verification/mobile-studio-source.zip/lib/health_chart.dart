import 'dart:math' as math;
import 'package:flutter/material.dart';

String formatBitRate(num? value) {
  if (value == null) return 'غير متاح';
  if (value >= 1000000000) {
    return '${(value / 1000000000).toStringAsFixed(2)} Gbps';
  }
  if (value >= 1000000) return '${(value / 1000000).toStringAsFixed(2)} Mbps';
  if (value >= 1000) return '${(value / 1000).toStringAsFixed(1)} Kbps';
  return '${value.toStringAsFixed(0)} bps';
}

class HealthTrafficChart extends StatelessWidget {
  const HealthTrafficChart({
    super.key,
    required this.samples,
    required this.interfaceName,
  });
  final List<Map<String, dynamic>> samples;
  final String interfaceName;
  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    if (samples.isEmpty ||
        !samples.any((v) => v['rxBps'] != null || v['txBps'] != null)) {
      return const SizedBox(
        height: 180,
        child: Center(child: Text('لم تتوفر عينتان صالحتان لرسم معدل النقل.')),
      );
    }
    return Semantics(
      image: true,
      label:
          'قياسات معدل النقل للواجهة $interfaceName. القيم الرقمية موضحة بجوار الرسم.',
      child: ExcludeSemantics(
        child: SizedBox(
          height: 190,
          child: CustomPaint(painter: _TrafficPainter(samples, scheme)),
        ),
      ),
    );
  }
}

class _TrafficPainter extends CustomPainter {
  _TrafficPainter(this.samples, this.scheme);
  final List<Map<String, dynamic>> samples;
  final ColorScheme scheme;
  @override
  void paint(Canvas canvas, Size size) {
    final area = Rect.fromLTWH(
      8,
      10,
      math.max(1, size.width - 90),
      size.height - 42,
    );
    final values = [
      for (final row in samples)
        for (final key in ['rxBps', 'txBps'])
          if (row[key] is num) (row[key] as num).toDouble(),
    ];
    final maximum = math.max(1000.0, values.fold<double>(0, math.max) * 1.12);
    void label(String text, Offset at) {
      final painter = TextPainter(
        text: TextSpan(
          text: text,
          style: TextStyle(
            color: scheme.onSurfaceVariant,
            fontFamily: 'JetBrainsMono',
            fontSize: 10,
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      painter.paint(canvas, at);
    }

    for (var i = 0; i <= 3; i++) {
      final y = area.top + area.height * i / 3;
      canvas.drawLine(
        Offset(area.left, y),
        Offset(area.right, y),
        Paint()
          ..color = scheme.outlineVariant
          ..strokeWidth = 1,
      );
      label(
        formatBitRate(maximum * (1 - i / 3)),
        Offset(area.right + 8, y - 7),
      );
    }
    final start = (samples.first['elapsedMs'] as num).toInt();
    final end = (samples.last['elapsedMs'] as num).toInt();
    final duration = math.max(1, end - start);
    for (final entry in [
      ('rxBps', scheme.primary),
      ('txBps', scheme.secondary),
    ]) {
      Offset? previous;
      for (final row in samples) {
        final value = row[entry.$1] as num?;
        if (value == null) {
          previous = null;
          continue;
        }
        final tick = (row['elapsedMs'] as num).toInt();
        final point = Offset(
          area.left + (tick - start) / duration * area.width,
          area.bottom - value / maximum * area.height,
        );
        if (previous != null) {
          canvas.drawLine(
            previous,
            point,
            Paint()
              ..color = entry.$2
              ..strokeWidth = 2.8
              ..strokeCap = StrokeCap.round,
          );
        }
        canvas.drawCircle(point, 3.4, Paint()..color = entry.$2);
        previous = point;
      }
    }
    label('0s', Offset(area.left, area.bottom + 12));
    label(
      '${((end - start) / 1000).toStringAsFixed(1)}s',
      Offset(math.max(area.left, area.right - 38), area.bottom + 12),
    );
  }

  @override
  bool shouldRepaint(covariant _TrafficPainter oldDelegate) =>
      oldDelegate.samples != samples || oldDelegate.scheme != scheme;
}
