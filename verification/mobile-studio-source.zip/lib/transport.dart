import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'transport_web.dart'
    if (dart.library.io) 'transport_io.dart'
    as platform;

void setLabTrust(Uint8List? certificate) => platform.setLabTrust(certificate);
http.Client createTransport() => platform.createTransport();
