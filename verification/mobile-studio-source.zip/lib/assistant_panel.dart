import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'api.dart';
import 'chat_api.dart';
import 'chat_session.dart';
import 'markdown_view.dart';
import 'ui.dart';

class AssistantPanel extends ConsumerStatefulWidget {
  const AssistantPanel({super.key, required this.connection});
  final LabConnection connection;

  @override
  ConsumerState<AssistantPanel> createState() => _AssistantPanelState();
}

class _AssistantPanelState extends ConsumerState<AssistantPanel> {
  final _draft = TextEditingController();
  final _scroll = ScrollController();
  final _focus = FocusNode();
  late ChatSession _session;

  @override
  void initState() {
    super.initState();
    _startSession();
    _draft.addListener(_draftChanged);
  }

  void _startSession() {
    _session = ChatSession(
      ref.read(chatGatewayFactoryProvider)(widget.connection),
    );
    _session.addListener(_sessionChanged);
  }

  void _draftChanged() {
    if (mounted) {
      setState(() {});
    }
  }

  void _sessionChanged() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && _scroll.hasClients) {
        _scroll.animateTo(
          _scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  void didUpdateWidget(covariant AssistantPanel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.connection != widget.connection) {
      _session.removeListener(_sessionChanged);
      _session.dispose();
      _draft.clear();
      _startSession();
    }
  }

  @override
  void dispose() {
    _session.removeListener(_sessionChanged);
    _session.dispose();
    _draft.removeListener(_draftChanged);
    _draft.dispose();
    _scroll.dispose();
    _focus.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final current = _session;
    final success = await current.send(_draft.text);
    if (mounted && identical(current, _session) && success) {
      _draft.clear();
      _focus.requestFocus();
    }
  }

  void _suggest(String question) {
    _draft.text = question;
    _draft.selection = TextSelection.collapsed(offset: question.length);
    _focus.requestFocus();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxHeight < 500;
        final narrow = constraints.maxWidth < 650;
        final padding = narrow ? 16.0 : 28.0;
        return ListenableBuilder(
          listenable: _session,
          builder: (context, child) => Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Padding(
                padding: EdgeInsets.fromLTRB(
                  padding,
                  compact ? 8 : 20,
                  padding,
                  12,
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: scheme.primary.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(
                        Icons.auto_awesome_outlined,
                        color: scheme.primary,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'المساعد الذكي',
                            style: theme.textTheme.titleLarge,
                          ),
                          if (!compact)
                            Text(
                              'فهم أوضح للشبكات، خطوة بخطوة',
                              style: theme.textTheme.bodySmall?.copyWith(
                                color: scheme.onSurfaceVariant,
                              ),
                            ),
                        ],
                      ),
                    ),
                    if (narrow)
                      IconButton(
                        key: const Key('chat-new'),
                        tooltip: 'محادثة جديدة',
                        onPressed: _session.busy
                            ? null
                            : () {
                                _session.clear();
                                _draft.clear();
                              },
                        icon: const Icon(Icons.edit_square),
                      )
                    else
                      OutlinedButton.icon(
                        key: const Key('chat-new'),
                        onPressed: _session.busy
                            ? null
                            : () {
                                _session.clear();
                                _draft.clear();
                              },
                        icon: const Icon(Icons.add, size: 18),
                        label: const Text('محادثة جديدة'),
                      ),
                  ],
                ),
              ),
              if (!compact)
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: padding),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 10,
                    ),
                    decoration: BoxDecoration(
                      color: scheme.primary.withValues(alpha: 0.055),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(
                          Icons.info_outline,
                          size: 17,
                          color: scheme.primary,
                        ),
                        const SizedBox(width: 9),
                        Expanded(
                          child: Text(
                            'تُرسل أسئلتك إلى Google. المساعد استشاري، ولا تُرفق قراءات الراوتر تلقائيًا.',
                            style: theme.textTheme.bodySmall,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              Expanded(
                child: ListView(
                  key: const Key('chat-timeline'),
                  controller: _scroll,
                  padding: EdgeInsets.all(padding),
                  children: [
                    if (_session.exchanges.isEmpty && _session.pending == null)
                      _AssistantWelcome(onSelect: _suggest),
                    for (final exchange in _session.exchanges) ...[
                      _MessageBubble(text: exchange.question, assistant: false),
                      _MessageBubble(
                        text: exchange.reply.text,
                        assistant: true,
                        truncated: exchange.reply.truncated,
                      ),
                    ],
                    if (_session.pending != null) ...[
                      _MessageBubble(text: _session.pending!, assistant: false),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 16,
                        ),
                        child: Row(
                          children: [
                            SizedBox(
                              width: 17,
                              height: 17,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: scheme.primary,
                              ),
                            ),
                            const SizedBox(width: 12),
                            const Text('جارٍ إعداد الرد…'),
                          ],
                        ),
                      ),
                    ],
                    if (_session.error != null)
                      _ChatNotice(
                        text: _session.error!,
                        icon: Icons.error_outline,
                        error: true,
                      ),
                    if (_session.notice != null)
                      _ChatNotice(
                        text: _session.notice!,
                        icon: Icons.pause_circle_outline,
                      ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(padding, 0, padding, 12),
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        CallbackShortcuts(
                          bindings: {
                            const SingleActivator(
                              LogicalKeyboardKey.enter,
                              control: true,
                            ): () {
                              if (!_session.busy) {
                                _send();
                              }
                            },
                            const SingleActivator(
                              LogicalKeyboardKey.enter,
                              meta: true,
                            ): () {
                              if (!_session.busy) {
                                _send();
                              }
                            },
                          },
                          child: TextField(
                            key: const Key('chat-input'),
                            controller: _draft,
                            focusNode: _focus,
                            enabled: !_session.busy,
                            minLines: 1,
                            maxLines: compact ? 2 : 4,
                            maxLength: 2000,
                            textInputAction: TextInputAction.newline,
                            decoration: const InputDecoration(
                              hintText: 'اكتب سؤالك عن الشبكات…',
                              counterText: '',
                              filled: false,
                              border: InputBorder.none,
                              enabledBorder: InputBorder.none,
                              focusedBorder: InputBorder.none,
                              contentPadding: EdgeInsets.fromLTRB(6, 6, 6, 12),
                            ),
                          ),
                        ),
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                compact
                                    ? 'محادثة مؤقتة'
                                    : 'محادثة مؤقتة بسياق محدود من آخر الرسائل',
                                style: theme.textTheme.bodySmall?.copyWith(
                                  color: scheme.onSurfaceVariant,
                                  fontSize: 11,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              '${_draft.text.length}/2000',
                              textDirection: TextDirection.ltr,
                              style: theme.textTheme.bodySmall?.copyWith(
                                color: scheme.onSurfaceVariant,
                                fontSize: 11,
                              ),
                            ),
                            const SizedBox(width: 12),
                            if (_session.busy)
                              OutlinedButton.icon(
                                key: const Key('chat-stop'),
                                onPressed: _session.cancel,
                                style: OutlinedButton.styleFrom(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 14,
                                    vertical: 12,
                                  ),
                                ),
                                icon: const Icon(
                                  Icons.stop_circle_outlined,
                                  size: 18,
                                ),
                                label: const Text('إيقاف'),
                              )
                            else
                              FilledButton.icon(
                                key: const Key('chat-send'),
                                onPressed: _draft.text.trim().isEmpty
                                    ? null
                                    : _send,
                                style: FilledButton.styleFrom(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 16,
                                    vertical: 12,
                                  ),
                                ),
                                icon: const Icon(Icons.arrow_upward, size: 18),
                                label: const Text('إرسال'),
                              ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _AssistantWelcome extends StatelessWidget {
  const _AssistantWelcome({required this.onSelect});
  final ValueChanged<String> onSelect;

  static const suggestions = [
    (
      Icons.wifi_tethering,
      'الهوتسبوت وإدارة المستخدمين',
      'اشرح الفرق بين Hotspot وUser Manager باختصار.',
    ),
    (
      Icons.hub_outlined,
      'فهم عدادات الواجهات',
      'ما الفرق بين عدادات RX وTX التراكمية ومعدل النقل اللحظي؟',
    ),
    (
      Icons.fact_check_outlined,
      'تشخيص منظم',
      'اقترح خطوات فحص أولية للقراءة فقط عندما يشتكي عميل من بطء الاتصال.',
    ),
    (
      Icons.school_outlined,
      'تعلّم MikroTik',
      'اشرح الفرق بين DHCP وDNS بمثال بسيط من شبكة محلية.',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 22),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: scheme.primary.withValues(alpha: 0.08),
            ),
            child: Icon(
              Icons.auto_awesome_outlined,
              size: 34,
              color: scheme.primary,
            ),
          ),
          const SizedBox(height: 18),
          Text(
            'بماذا أساعدك اليوم؟',
            textAlign: TextAlign.center,
            style: theme.textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'ابدأ بسؤال، أو اختر فكرة وعدّلها قبل الإرسال.',
            textAlign: TextAlign.center,
            style: theme.textTheme.bodyMedium?.copyWith(
              color: scheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 26),
          LayoutBuilder(
            builder: (context, constraints) {
              final columns = constraints.maxWidth >= 650 ? 2 : 1;
              final width =
                  (constraints.maxWidth - 12 * (columns - 1)) / columns;
              return Wrap(
                spacing: 12,
                runSpacing: 12,
                children: [
                  for (final suggestion in suggestions)
                    SizedBox(
                      width: width,
                      child: Card(
                        clipBehavior: Clip.antiAlias,
                        child: InkWell(
                          onTap: () => onSelect(suggestion.$3),
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Row(
                              children: [
                                Icon(
                                  suggestion.$1,
                                  color: scheme.primary,
                                  size: 22,
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Text(
                                    suggestion.$2,
                                    style: theme.textTheme.bodyMedium?.copyWith(
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                                Icon(
                                  Icons.north_west,
                                  color: scheme.onSurfaceVariant,
                                  size: 15,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  const _MessageBubble({
    required this.text,
    required this.assistant,
    this.truncated = false,
  });
  final String text;
  final bool assistant;
  final bool truncated;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    return Align(
      alignment: assistant
          ? AlignmentDirectional.centerEnd
          : AlignmentDirectional.centerStart,
      child: Container(
        constraints: BoxConstraints(maxWidth: assistant ? 980 : 760),
        margin: const EdgeInsets.only(bottom: 18),
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: assistant
              ? scheme.surface
              : scheme.primary.withValues(alpha: 0.075),
          borderRadius: BorderRadius.circular(15),
          border: Border.all(
            color: assistant
                ? scheme.outlineVariant
                : scheme.primary.withValues(alpha: 0.16),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Icon(
                  assistant
                      ? Icons.auto_awesome_outlined
                      : Icons.person_outline,
                  size: 17,
                  color: assistant ? scheme.primary : scheme.onSurfaceVariant,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    assistant ? 'المساعد' : 'أنت',
                    style: theme.textTheme.bodySmall?.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                if (assistant)
                  IconButton(
                    tooltip: 'نسخ الرد',
                    visualDensity: VisualDensity.compact,
                    iconSize: 17,
                    onPressed: () => copyText(context, text),
                    icon: const Icon(Icons.copy_outlined),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            if (assistant)
              MarkdownView(text: text)
            else
              SelectableText(text, style: theme.textTheme.bodyLarge),
            if (truncated) ...[
              const Divider(),
              const SizedBox(height: 10),
              Text(
                'وصل الرد إلى حد الإخراج. يمكنك طلب تفاصيل محددة للمتابعة.',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: scheme.onSurfaceVariant,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _ChatNotice extends StatelessWidget {
  const _ChatNotice({
    required this.text,
    required this.icon,
    this.error = false,
  });
  final String text;
  final IconData icon;
  final bool error;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final color = error ? scheme.error : scheme.onSurfaceVariant;
    return Container(
      margin: const EdgeInsets.only(top: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: (error ? scheme.error : scheme.primary).withValues(alpha: 0.06),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withValues(alpha: 0.2)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 20, color: color),
          const SizedBox(width: 10),
          Expanded(child: Text(text)),
        ],
      ),
    );
  }
}
