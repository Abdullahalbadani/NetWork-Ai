import 'package:flutter/material.dart';

enum SignalTone { success, warning, high, critical, info, unknown }

Color signalColor(BuildContext context, SignalTone tone) {
  final dark = Theme.of(context).brightness == Brightness.dark;
  return switch (tone) {
    SignalTone.success => Color(dark ? 0xFF34D399 : 0xFF047857),
    SignalTone.warning => Color(dark ? 0xFFFBBF24 : 0xFF92400E),
    SignalTone.high => Color(dark ? 0xFFFDBA74 : 0xFFC2410C),
    SignalTone.critical => Color(dark ? 0xFFFCA5A5 : 0xFFB91C1C),
    SignalTone.info => Color(dark ? 0xFF7DD3FC : 0xFF075985),
    SignalTone.unknown => Color(dark ? 0xFF94A3B8 : 0xFF475569),
  };
}

class StatusPill extends StatelessWidget {
  const StatusPill({super.key, required this.tone, required this.label});
  final SignalTone tone;
  final String label;
  @override
  Widget build(BuildContext context) {
    final color = signalColor(context, tone);
    final icon = switch (tone) {
      SignalTone.success => Icons.check_circle_outline,
      SignalTone.warning || SignalTone.high => Icons.warning_amber_rounded,
      SignalTone.critical => Icons.error_outline,
      SignalTone.info => Icons.info_outline,
      SignalTone.unknown => Icons.help_outline,
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .09),
        borderRadius: BorderRadius.circular(9),
        border: Border.all(color: color.withValues(alpha: .32)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: color),
          const SizedBox(width: 7),
          Flexible(
            child: Text(
              label,
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.w700,
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
