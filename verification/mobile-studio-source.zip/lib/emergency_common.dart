import 'package:flutter/material.dart';
import 'account_api.dart';
import 'account_views.dart';
import 'emergency_api.dart';

Color emergencyColor(BuildContext context, String state) {
  final dark = Theme.of(context).brightness == Brightness.dark;
  return switch (state) {
    'critical' || 'high' || 'alarm' => Theme.of(context).colorScheme.error,
    'warning' || 'unknown' || 'restore_unknown' => dark ? const Color(0xFFFCD34D) : const Color(0xFF92400E),
    'resolved' || 'verified' || 'restored' => dark ? const Color(0xFF5EEAD4) : const Color(0xFF0F766E),
    _ => Theme.of(context).colorScheme.primary,
  };
}
class EmergencyBadge extends StatelessWidget {
  const EmergencyBadge(this.label, {super.key, required this.state});
  final String label, state;
  @override
  Widget build(BuildContext context) {
    final color = emergencyColor(context, state);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(color: color.withValues(alpha: 0.10), borderRadius: BorderRadius.circular(10)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(state == 'resolved' || state == 'verified' || state == 'restored' ? Icons.check_circle_outline : state == 'unknown' || state == 'restore_unknown' ? Icons.help_outline : Icons.warning_amber_rounded, color: color, size: 18),
        const SizedBox(width: 6), Flexible(child: Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w700))),
      ]),
    );
  }
}
Widget emergencyCard({required Widget child}) => Card(child: Padding(padding: const EdgeInsets.all(20), child: child));
Widget emergencyMessage(BuildContext context, String message, {VoidCallback? retry, bool error = false}) => emergencyCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
  Icon(error ? Icons.cloud_off_outlined : Icons.info_outline, color: error ? Theme.of(context).colorScheme.error : Theme.of(context).colorScheme.primary),
  const SizedBox(height: 10), Text(message), if (retry != null) Padding(padding: const EdgeInsets.only(top: 12), child: OutlinedButton.icon(onPressed: retry, icon: const Icon(Icons.refresh), label: const Text('إعادة المحاولة'))),
]));

Future<T> emergencyMutation<T>(BuildContext context, AccountController account, Future<T> Function() action) async {
  try { return await action(); } on AccountFailure catch (e) {
    if (e.code != 'step_up_required') rethrow;
    if (!context.mounted) rethrow;
    final accepted = await showDialog<bool>(context: context, builder: (_) => _EmergencyMfa(account));
    if (accepted != true) throw const AccountFailure('operation_cancelled', 0);
    return action();
  }
}
class _EmergencyMfa extends StatefulWidget {
  const _EmergencyMfa(this.account);
  final AccountController account;
  @override
  State<_EmergencyMfa> createState() => _EmergencyMfaState();
}
class _EmergencyMfaState extends State<_EmergencyMfa> {
  final code = TextEditingController(); bool busy = false; String? error;
  @override
  void dispose() { code.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('تأكيد هويتك لاعتماد المعالجة'),
    content: SizedBox(width: 360, child: Column(mainAxisSize: MainAxisSize.min, children: [
      const Text('أدخل رمز تطبيق المصادقة الحالي. لا يُحفظ الرمز في سجل المعالجة.'),
      const SizedBox(height: 16), TextField(controller: code, enabled: !busy, keyboardType: TextInputType.number, maxLength: 6, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'رمز المصادقة', counterText: '')),
      if (error != null) Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
    ])),
    actions: [TextButton(onPressed: busy ? null : () => Navigator.pop(context, false), child: const Text('عودة')),
      FilledButton(onPressed: busy ? null : () async {
        if (!RegExp(r'^\d{6}$').hasMatch(code.text.trim())) { setState(() => error = 'أدخل ستة أرقام.'); return; }
        setState(() { busy = true; error = null; });
        try { await widget.account.stepUp(code.text.trim()); if (context.mounted) Navigator.pop(context, true); }
        catch (e) { if (mounted) setState(() => error = accountError(e)); }
        finally { if (mounted) setState(() => busy = false); }
      }, child: Text(busy ? 'جارٍ التحقق…' : 'تأكيد الهوية'))],
  );
}
class EmergencyEvents extends StatelessWidget {
  const EmergencyEvents({super.key, required this.events}); final List<Map<String, dynamic>> events;
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text('سجل المتابعة والمعالجة', style: Theme.of(context).textTheme.titleLarge), const SizedBox(height: 12),
    if (events.isEmpty) const Text('لا توجد عمليات مسجلة لهذا العطل.'),
    for (final event in events) Padding(padding: const EdgeInsets.symmetric(vertical: 10), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(Icons.history, size: 19, color: Theme.of(context).colorScheme.primary), const SizedBox(width: 10),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(emergencyEventNames[event['kind']] ?? 'عملية معالجة مسجلة'), Text(emergencyTime(event['createdAt']), style: Theme.of(context).textTheme.bodySmall)])),
    ])),
  ]);
}

/// A pushed route must stop showing its previous workspace when the account
/// changes, even while a request or another route is still above it.
class EmergencyScopeGuard extends StatefulWidget {
  const EmergencyScopeGuard({super.key, required this.account, required this.child});
  final AccountController account;
  final Widget child;
  @override
  State<EmergencyScopeGuard> createState() => _EmergencyScopeGuardState();
}
class _EmergencyScopeGuardState extends State<EmergencyScopeGuard> {
  late final String original;
  bool changed = false;
  String get signature => '${widget.account.endpoint}|${widget.account.workspaceId}|${emergencyMap(widget.account.profile?['user'])['id']}|${widget.account.role}';
  @override
  void initState() { super.initState(); original = signature; widget.account.addListener(_accountChanged); }
  void _accountChanged() { if (mounted && !changed && signature != original) setState(() => changed = true); }
  @override
  void didUpdateWidget(EmergencyScopeGuard oldWidget) { super.didUpdateWidget(oldWidget); if (oldWidget.account != widget.account) { oldWidget.account.removeListener(_accountChanged); widget.account.addListener(_accountChanged); _accountChanged(); } }
  @override
  void dispose() { widget.account.removeListener(_accountChanged); super.dispose(); }
  @override
  Widget build(BuildContext context) => !changed ? widget.child : Scaffold(body: SafeArea(child: Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
    const Icon(Icons.lock_outline, size: 40), const SizedBox(height: 16), const Text('تغيرت الجلسة أو مساحة العمل. افتح البيانات من المساحة الحالية.'), const SizedBox(height: 18),
    FilledButton(onPressed: () => Navigator.of(context).popUntil((route) => route.isFirst), child: const Text('العودة إلى المساحة الحالية')),
  ])))));
}
