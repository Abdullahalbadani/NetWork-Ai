import 'dart:convert';
import 'dart:math';
import 'account_api.dart';

const findingStates = ['pass', 'warning', 'high', 'critical', 'unknown'];
const healthRuleIds = [
  'management.tls',
  'resources.cpu',
  'resources.memory',
  'resources.storage',
  'interfaces.expected',
  'management.services',
  'interfaces.rates',
  'connectivity.internet',
];

String newScanRequestId() {
  final random = Random.secure(),
      bytes = List.generate(16, (_) => random.nextInt(256));
  bytes[6] = (bytes[6] & 15) | 64;
  bytes[8] = (bytes[8] & 63) | 128;
  final hex = bytes.map((v) => v.toRadixString(16).padLeft(2, '0')).join();
  return '${hex.substring(0, 8)}-${hex.substring(8, 12)}-${hex.substring(12, 16)}-${hex.substring(16, 20)}-${hex.substring(20)}';
}

class HealthScan {
  HealthScan._(
    this.id,
    this.status,
    this.stage,
    this.progress,
    this.createdAt,
    this.report,
    this.coverage,
    this.requestId,
    this.reason,
  );
  final String id, status, stage;
  final String? requestId, reason;
  String get failureMessage => status == 'cancelled'
      ? 'أُلغي الفحص. تبقى التقارير السابقة محفوظة.'
      : switch (reason) {
          'context_changed' =>
            'تغير سجل الراوتر أو إعدادات الفحص أثناء التنفيذ. أعد الفحص بالإعدادات الحالية.',
          'permission_changed' =>
            'تغيرت صلاحية الوصول أثناء الفحص. راجع صلاحيات حسابك.',
          'collection_timeout' =>
            'استغرق جمع القراءات وقتًا أطول من المهلة. راجع اتصال الراوتر ثم أعد الفحص.',
          'report_too_large' =>
            'تجاوز التقرير حد الحجم لهذا الإصدار. راجع عدد الواجهات وإعدادات الفحص.',
          'worker_unavailable' =>
            'توقف عامل الفحص قبل اكتماله. يمكنك بدء فحص جديد.',
          'user_cancelled' => 'أُلغي الفحص بطلب المستخدم.',
          _ =>
            'تعذر إكمال الفحص. أعد المحاولة وراجع سجل الإدارة إذا استمر الخطأ.',
        };
  final int progress;
  final DateTime createdAt;
  final Map<String, dynamic>? report, coverage;
  bool get running => status == 'running';
  bool get completed => status == 'completed' && report != null;
  List<Map<String, dynamic>> get findings =>
      (report?['findings'] as List? ?? []).cast<Map<String, dynamic>>();
  List<Map<String, dynamic>> get interfaces =>
      (report?['interfaces'] as List? ?? []).cast<Map<String, dynamic>>();
  List<Map<String, dynamic>> get traffic =>
      (report?['traffic'] as List? ?? []).cast<Map<String, dynamic>>();
  factory HealthScan.parse(Map<String, dynamic> value) {
    final date = DateTime.tryParse('${value['createdAt']}');
    final status = value['status'], report = value['report'];
    if (value['id'] is! String ||
        ![
          'running',
          'completed',
          'cancelled',
          'interrupted',
        ].contains(status) ||
        date == null ||
        value['progress'] is! int ||
        (value['progress'] as int) < 0 ||
        (value['progress'] as int) > 100) {
      throw const AccountFailure('invalid_response', 502);
    }
    if (report != null) {
      if (report is! Map<String, dynamic> ||
          report['rulesVersion'] != 1 ||
          report['findings'] is! List ||
          (report['findings'] as List).length != 8 ||
          report['interfaces'] is! List ||
          (report['interfaces'] as List).length > 64 ||
          report['traffic'] is! List ||
          (report['traffic'] as List).length > 192 ||
          DateTime.tryParse('${report['completedAt']}') == null) {
        throw const AccountFailure('invalid_response', 502);
      }
      final resources = report['resources'], profile = report['profile'];
      if (profile is! Map<String, dynamic> ||
          profile['version'] is! int ||
          profile['links'] is! List ||
          (resources != null &&
              (resources is! Map<String, dynamic> ||
                  ['cpuLoad', 'freeMemory', 'totalMemory'].any(
                    (key) =>
                        resources[key] is! num ||
                        !(resources[key] as num).isFinite ||
                        (resources[key] as num) < 0,
                  )))) {
        throw const AccountFailure('invalid_response', 502);
      }
      final ids = <String>{};
      for (final row in report['findings'] as List) {
        if (row is! Map<String, dynamic> ||
            !healthRuleIds.contains(row['id']) ||
            !ids.add(row['id'] as String) ||
            !findingStates.contains(row['state']) ||
            [
              'title',
              'summary',
              'recommendation',
              'source',
            ].any((key) => row[key] is! String) ||
            row['evidence'] is! List ||
            (row['evidence'] as List).length > 64 ||
            (row['evidence'] as List).any(
              (v) =>
                  v is! Map<String, dynamic> ||
                  v['label'] is! String ||
                  v['value'] is! String,
            )) {
          throw const AccountFailure('invalid_response', 502);
        }
      }
      for (final row in report['interfaces'] as List) {
        if (row is! Map<String, dynamic> ||
            row['id'] is! String ||
            row['name'] is! String ||
            ['rxBps', 'txBps'].any(
              (key) =>
                  row[key] != null &&
                  (row[key] is! num ||
                      !(row[key] as num).isFinite ||
                      (row[key] as num) < 0),
            )) {
          throw const AccountFailure('invalid_response', 502);
        }
      }
      for (final row in report['traffic'] as List) {
        if (row is! Map<String, dynamic> ||
            row['interfaceId'] is! String ||
            row['elapsedMs'] is! num ||
            !(row['elapsedMs'] as num).isFinite ||
            (row['elapsedMs'] as num) < 0 ||
            (row['elapsedMs'] as num) > 40000 ||
            DateTime.tryParse('${row['at']}') == null ||
            ['rxBps', 'txBps'].any(
              (key) =>
                  row[key] != null &&
                  (row[key] is! num ||
                      !(row[key] as num).isFinite ||
                      (row[key] as num) < 0),
            )) {
          throw const AccountFailure('invalid_response', 502);
        }
      }
    }
    final coverage = report?['coverage'] ?? value['coverage'];
    if (report != null && coverage == null) {
      throw const AccountFailure('invalid_response', 502);
    }
    if (coverage != null &&
        (coverage is! Map<String, dynamic> ||
            ['total', 'measured', 'passed', 'warnings', 'unknown'].any(
              (key) =>
                  coverage[key] is! int ||
                  (coverage[key] as int) < 0 ||
                  (coverage[key] as int) > 8,
            ) ||
            coverage['total'] != 8 ||
            coverage['measured'] + coverage['unknown'] != 8 ||
            coverage['passed'] + coverage['warnings'] !=
                coverage['measured'])) {
      throw const AccountFailure('invalid_response', 502);
    }
    return HealthScan._(
      value['id'],
      status,
      '${value['stage']}',
      value['progress'],
      date,
      report as Map<String, dynamic>?,
      coverage as Map<String, dynamic>?,
      value['requestId'] as String?,
      value['reason'] as String?,
    );
  }
}

class HealthApi {
  HealthApi(this.account, String deviceId)
    : path = '/v1/devices/${Uri.encodeComponent(deviceId)}';
  final AccountController account;
  final String path;
  Future<Map<String, dynamic>> profile() =>
      account.request('GET', '$path/health-profile');
  Future<Map<String, dynamic>> history() =>
      account.request('GET', '$path/health-scans');
  Future<HealthScan> scan(String id) async => HealthScan.parse(
    (await account.request('GET', '$path/health-scans/$id'))['scan']
        as Map<String, dynamic>,
  );
  Future<HealthScan> start(String requestId) async => HealthScan.parse(
    (await account.request(
          'POST',
          '$path/health-scans',
          body: {'requestId': requestId},
        ))['scan']
        as Map<String, dynamic>,
  );
  Future<void> cancel(String id) async {
    await account.request('POST', '$path/health-scans/$id/cancel', body: {});
  }

  Future<Map<String, dynamic>> saveProfile(Map<String, dynamic> profile) =>
      account.request('PATCH', '$path/health-profile', body: profile);
}

/// Only fixed rule identifiers, states and numeric measurements leave the report.
/// Device/interface names, addresses, certificates and account data are excluded.
String explanationPrompt(HealthScan scan, Set<String> selected) {
  final raw = scan.report?['resources'] as Map<String, dynamic>?;
  final resources = <String, num>{};
  for (final key in [
    'cpuLoad',
    'freeMemory',
    'totalMemory',
    'freeHddSpace',
    'totalHddSpace',
  ]) {
    if (raw?[key] is num && (raw![key] as num).isFinite) {
      resources[key] = raw[key] as num;
    }
  }
  final payload = {
    'rulesVersion': 1,
    'findings': [
      for (final row in scan.findings)
        if (selected.contains(row['id']))
          {'id': row['id'], 'state': row['state']},
    ],
    'resources': resources,
  };
  return 'اشرح باختصار نتائج الفحص التالية بالعربية، مع السبب المحتمل والخطوة المناسبة للتحقق. '
      'هذه لقطات محدودة وليست إثباتًا لسلامة الشبكة كلها. unknown يعني غير معروف، '
      'ولا يثبت تفعيل خدمة أنها مكشوفة للإنترنت. لا تدّع تنفيذ إصلاح أو قياس إنترنت؛ لا تقترح أوامر تغيّر الراوتر. '
      'معرفات الموارد: cpu حمل المعالج، memory الذاكرة، storage التخزين؛ management.tls اتصال HTTPS، '
      'management.services خدمات غير مشفرة، interfaces.expected روابط محددة مطلوبة، interfaces.rates قياس RX/TX.\n${jsonEncode(payload)}';
}
