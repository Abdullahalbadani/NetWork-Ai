import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'account_api.dart';
import 'account_views.dart';
import 'emergency_api.dart';
import 'emergency_common.dart';
import 'emergency_incident.dart';
import 'emergency_settings.dart';
import 'command_center.dart';
import 'workspace_profile_dialog.dart';
import 'command_timeline.dart';

class EmergencyHome extends StatefulWidget {
  const EmergencyHome({super.key, required this.account, required this.onDevice, required this.onDevices});
  final AccountController account;
  final void Function(String, String) onDevice;
  final VoidCallback onDevices;
  @override
  State<EmergencyHome> createState() => _EmergencyHomeState();
}
class _EmergencyHomeState extends State<EmergencyHome> with WidgetsBindingObserver {
  late final api = EmergencyApi(widget.account);
  final search = TextEditingController();
  Timer? timer, debounce;
  List<Map<String, dynamic>> devices = [], incidents = [];
  Map<String, dynamic> summary = {}, worker = {};
  final statisticsKey = GlobalKey(), activationsKey = GlobalKey();
  bool loading = false, busy = false, foreground = true, childOpen = false, ready = false;
  String? site, device, severity, error, notice;
  String state = 'active'; int offset = 0, total = 0, epoch = 0;
  @override
  void initState() { super.initState(); WidgetsBinding.instance.addObserver(this); _load(); timer = Timer.periodic(const Duration(seconds: 8), (_) { if (foreground && !loading && !busy && !childOpen) _load(); }); }
  @override
  void dispose() { epoch++; timer?.cancel(); debounce?.cancel(); search.dispose(); WidgetsBinding.instance.removeObserver(this); super.dispose(); }
  @override
  void didChangeAppLifecycleState(AppLifecycleState value) { foreground = value == AppLifecycleState.resumed; if (foreground && !busy && !childOpen) _load(); }
  Future<void> _load() async {
    final current = ++epoch; setState(() => loading = true);
    try {
      final data = await Future.wait([api.get('devices'), api.get('incidents', query: {'state':state,'offset':'$offset','limit':'20','q':search.text.trim(),'siteId': ?site, 'deviceId': ?device, 'severity': ?severity})]);
      if (!mounted || current != epoch) return;
      setState(() { devices = emergencyRows(data[0]['items']); worker = emergencyMap(data[0]['worker']); incidents = emergencyRows(data[1]['items']); total = data[1]['total'] as int? ?? 0; summary = emergencyMap(data[1]['summary']); error = null; ready = true; loading = false; });
    } catch (e) { if (mounted && current == epoch) setState(() { error = accountError(e); loading = false; if (e is AccountFailure && [401,403,404].contains(e.status)) { devices = []; incidents = []; summary = {}; total = 0; ready = false; site = null; device = null; } }); }
  }
  void _filter(VoidCallback action) { setState(() { action(); offset = 0; }); _load(); }
  Future<void> _act(Future<void> Function() task) async {
    if (busy) return; setState(() { busy = true; notice = null; });
    try { await task(); await _load(); } catch (e) { if (mounted) setState(() => error = accountError(e)); }
    finally { if (mounted) setState(() => busy = false); }
  }
  Future<void> _page(Widget page) async { childOpen = true; try { await Navigator.push(context,MaterialPageRoute<void>(builder: (_) => EmergencyScopeGuard(account: widget.account, child: page))); } finally { childOpen = false; if (mounted) await _load(); } }
  Future<void> _scan(Map<String, dynamic> d) => _act(() async { await api.post('devices/${d['id']}/scan', {'requestId':emergencyRequestId()}); if (mounted) setState(() => notice = 'أُرسل طلب القياس إلى الخادم. ستظهر النتيجة عند اكتمال القراءة.'); });
  Future<void> _batch(List<Map<String,dynamic>> selected) => _act(() async {
    final result = await api.post('scan-batch', {'items': [for (final d in selected.take(20)) {'deviceId':d['id'], 'requestId':emergencyRequestId()}]});
    final rows = emergencyRows(result['items']), accepted = rows.where((v) => v['accepted'] == true).length;
    if (mounted) setState(() => notice = 'قُبل $accepted من ${rows.length} طلبًا. ${rows.length > accepted ? 'بعض الأجهزة مشغولة أو غير متاحة؛ راجع حالتها أدناه.' : 'يقرأ الخادم جهازين كحد أقصى في الوقت نفسه.'}${selected.length > 20 ? ' حد الدفعة 20 جهازًا؛ اختر موقعًا أو جهازًا لبقية الشبكة.' : ''}');
  });
  bool _pending(Map<String,dynamic> d) => d['requestId'] != null && d['requestId'] != d['lastRequestId'];
  bool _stale(Map<String,dynamic> d) { final last = DateTime.tryParse('${d['lastRunAt']}'), now = DateTime.now(); return last == null || last.isAfter(now.add(const Duration(seconds: 5))) || now.difference(last).inSeconds > (emergencyMap(d['policy'])['intervalSeconds'] as int? ?? 120) * 2 + 60; }
  Future<void> _chooseDevice({bool settings = false}) async {
    final options = devices.where((d) => d['enabled'] == true && (site == null || d['siteId'] == site) && (device == null || d['id'] == device)).toList();
    if (options.isEmpty) { setState(() => notice = 'لا يوجد جهاز مفعّل في النطاق الحالي. راجع الأجهزة أو غيّر التصفية.'); return; }
    Map<String, dynamic>? selected;
    if (options.length == 1) { selected = options.first; }
    else {
      childOpen = true;
      try { selected = await showModalBottomSheet<Map<String, dynamic>>(context: context, builder: (ctx) => EmergencyScopeGuard(account: widget.account, child: SafeArea(child: ListView(shrinkWrap: true, children: [
        const Padding(padding: EdgeInsets.all(20), child: Text('اختر الراوتر', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
        for (final d in options) ListTile(leading: const Icon(Icons.router_outlined), title: Text('${d['name']}'), subtitle: Text('${d['siteName']}'), onTap: () => Navigator.pop(ctx, d)),
      ])))); } finally { childOpen = false; }
    }
    if (!mounted || selected == null) return;
    await _page(settings ? EmergencySettings(account: widget.account, device: selected) : CommandDevicePage(account: widget.account, id: '${selected['id']}'));
  }
  void _scrollTo(GlobalKey key) { final target = key.currentContext; if (target != null) Scrollable.ensureVisible(target, duration: MediaQuery.disableAnimationsOf(context) ? Duration.zero : const Duration(milliseconds: 250)); }
  Future<void> _renameNetwork() async {
    childOpen = true;
    try {
      await widget.account.loadProfile();
      if (!mounted || widget.account.role != 'owner') return;
      final current = widget.account.workspaces.where((w) => w['id'] == widget.account.workspaceId).firstOrNull;
      if (current == null || current['version'] is! int) throw const AccountFailure('version_conflict', 409);
      await showDialog<bool>(context: context, builder: (_) => EmergencyScopeGuard(account: widget.account, child: WorkspaceProfileDialog(account: widget.account, name: '${current['name']}', version: current['version'] as int)));
    } catch (e) { if (mounted) setState(() => error = accountError(e)); }
    finally { childOpen = false; }
  }
  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final sites = {for (final d in devices) '${d['siteId']}':'${d['siteName']}'};
    final selected = devices.where((d) => (site == null || d['siteId'] == site) && (device == null || d['id'] == device)).toList();
    final unavailable = selected.where((d) => _stale(d) || emergencyMap(d['coverage'])['unknown'] != 0 || d['lastError'] != null).length;
    return RefreshIndicator(onRefresh: _load, child: SingleChildScrollView(physics: const AlwaysScrollableScrollPhysics(), padding: const EdgeInsets.all(18), child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 1280), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Container(padding: const EdgeInsets.all(24), decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), gradient: const LinearGradient(colors:[Color(0xFF0C1C37),Color(0xFF073D5A)],begin:Alignment.topRight,end:Alignment.bottomLeft)), child: LayoutBuilder(builder: (context, box) => Wrap(spacing: 24, runSpacing: 18, crossAxisAlignment: WrapCrossAlignment.center, children: [
        Semantics(label:'رادار الطوارئ، ${summary['active'] ?? 0} عطل نشط', child: CustomPaint(size: const Size(105,105), painter:_RadarPainter(active:summary['active'] as int? ?? 0))),
        SizedBox(width: math.max(0.0,box.maxWidth - (box.maxWidth > 500 ? 155 : 0)), child: Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Text('رادار الطوارئ',style:TextStyle(color:Colors.white,fontSize:28,fontWeight:FontWeight.w700)),
          const SizedBox(height:8), const Text('العطل، دليله، ثم مسار معالجته.',style:TextStyle(color:Color(0xFFBAE6FD),fontSize:17)),
          const SizedBox(height:12), Text(ready ? '${selected.length} جهاز ضمن النطاق · ${selected.where((d)=>d['monitoring']==true).length} تحت المراقبة' : 'جارٍ تحميل حالة الشبكة…',style:const TextStyle(color:Colors.white)),
        ])),
      ]))),
      const SizedBox(height:18), Wrap(spacing:10,runSpacing:10,children:[
        EmergencyBadge('${summary['active'] ?? 0} يحتاج متابعة',state:(summary['active'] as int? ?? 0)>0?'high':'acknowledged'),
        EmergencyBadge('${summary['critical'] ?? 0} حرج',state:(summary['critical'] as int? ?? 0)>0?'critical':'acknowledged'),
        EmergencyBadge('$unavailable جهاز بقياسات غير مكتملة أو قديمة',state:'unknown'),
      ]),
      const SizedBox(height: 14), Wrap(spacing: 12, runSpacing: 8, crossAxisAlignment: WrapCrossAlignment.center, children: [Text('${widget.account.workspaces.where((w) => w['id'] == widget.account.workspaceId).firstOrNull?['name'] ?? 'مساحة الشبكة'}', style: Theme.of(context).textTheme.titleMedium), if (widget.account.role == 'owner') TextButton.icon(onPressed: _renameNetwork, icon: const Icon(Icons.edit_outlined), label: const Text('تعديل اسم الشبكة'))]),
      const SizedBox(height: 12), Wrap(spacing: 10, runSpacing: 10, children: [
        OutlinedButton.icon(onPressed: () => _scrollTo(statisticsKey), icon: const Icon(Icons.bar_chart_outlined), label: const Text('إحصائيات الشبكة')),
        OutlinedButton.icon(onPressed: () => _chooseDevice(), icon: const Icon(Icons.dashboard_outlined), label: const Text('قراءات مركز التحكم')),
        OutlinedButton.icon(onPressed: () => _page(CommandTimelinePage(account: widget.account, onDevice: widget.onDevice, siteId: site, deviceId: device)), icon: const Icon(Icons.history), label: const Text('سجل الشبكة والتنبيهات')),
        if (widget.account.canManage) OutlinedButton.icon(onPressed: () => _chooseDevice(settings: true), icon: const Icon(Icons.tune), label: const Text('إعدادات الرادار')),
        if (widget.account.canManage) OutlinedButton.icon(onPressed: () => _scrollTo(activationsKey), icon: const Icon(Icons.payments_outlined), label: const Text('الدخول وقيمة التفعيل')),
      ]),
      const SizedBox(height:18),
      if (loading) const Padding(padding:EdgeInsets.only(bottom:14),child:LinearProgressIndicator()),
      if (error != null) ...[emergencyMessage(context,error!,error:true,retry:_load),const SizedBox(height:16)],
      if (notice != null) ...[emergencyMessage(context,notice!),const SizedBox(height:16)],
      emergencyCard(child: Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        TextField(controller:search,decoration:const InputDecoration(labelText:'ابحث عن عطل أو جهاز أو موقع',prefixIcon:Icon(Icons.search)),onChanged:(_){debounce?.cancel();debounce=Timer(const Duration(milliseconds:400),()=>_filter((){}));}),
        const SizedBox(height:14), LayoutBuilder(builder:(context,box)=>Wrap(spacing:12,runSpacing:12,children:[
          SizedBox(width:box.maxWidth>650?(box.maxWidth-24)/3:box.maxWidth,child:DropdownButtonFormField<String>(key:ValueKey('site:${sites.keys.join(',')}:$site'),initialValue:site ?? '',isExpanded:true,decoration:const InputDecoration(labelText:'الموقع'),items:[const DropdownMenuItem(value:'',child:Text('كل المواقع')),for(final e in sites.entries)DropdownMenuItem(value:e.key,child:Text(e.value,overflow:TextOverflow.ellipsis))],onChanged:(v)=>_filter((){site=v==''?null:v;device=null;}))),
          SizedBox(width:box.maxWidth>650?(box.maxWidth-24)/3:box.maxWidth,child:DropdownButtonFormField<String>(key:ValueKey('device:${devices.map((d)=>d['id']).join(',')}:$site:$device'),initialValue:device ?? '',isExpanded:true,decoration:const InputDecoration(labelText:'الجهاز'),items:[const DropdownMenuItem(value:'',child:Text('كل الأجهزة')),for(final d in devices.where((d)=>site==null||d['siteId']==site))DropdownMenuItem(value:'${d['id']}',child:Text('${d['name']}',overflow:TextOverflow.ellipsis))],onChanged:(v)=>_filter(()=>device=v==''?null:v))),
          SizedBox(width:box.maxWidth>650?(box.maxWidth-24)/3:box.maxWidth,child:DropdownButtonFormField<String>(initialValue:severity ?? '',isExpanded:true,decoration:const InputDecoration(labelText:'الأولوية'),items:const[DropdownMenuItem(value:'',child:Text('كل الأولويات')),DropdownMenuItem(value:'critical',child:Text('حرج')),DropdownMenuItem(value:'high',child:Text('مرتفع')),DropdownMenuItem(value:'warning',child:Text('تحذير'))],onChanged:(v)=>_filter(()=>severity=v==''?null:v))),
        ])),
        const SizedBox(height:14),Wrap(spacing:8,runSpacing:8,children:[for(final entry in {'active':'تحتاج متابعة','resolved':'عولجت وتأكد زوالها','all':'كل السجل'}.entries)ChoiceChip(label:Text(entry.value),selected:state==entry.key,onSelected:(_)=>_filter(()=>state=entry.key))]),
      ])),
      const SizedBox(height:20),Text('المشكلات والإجراءات',style:Theme.of(context).textTheme.titleLarge),const SizedBox(height:12),
      if (ready && incidents.isEmpty) emergencyMessage(context,devices.isEmpty?'أضف راوترًا من الأجهزة لبدء القياس.':'لا توجد أعطال مطابقة في السجل. راجع وقت القياس وتغطية المصادر أدناه؛ غياب البلاغ لا يثبت سلامة مصدر غير مقروء.'),
      for(final item in incidents)...[
        Card(child:Container(decoration:BoxDecoration(border:BorderDirectional(start:BorderSide(width:4,color:emergencyColor(context,item['state']=='resolved'?'resolved':'${item['severity']}'))),borderRadius:BorderRadius.circular(16)),padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
          Wrap(spacing:10,runSpacing:10,children:[EmergencyBadge(item['state']=='resolved'?'زوال العطل مؤكد':item['severity']=='critical'?'حرج':item['severity']=='high'?'مرتفع':'تحذير',state:item['state']=='resolved'?'resolved':'${item['severity']}'),if(item['observation']=='unknown')const EmergencyBadge('القراءة الحالية غير متاحة',state:'unknown'),if(item['state']=='acknowledged')const EmergencyBadge('قيد المتابعة',state:'acknowledged')]),
          const SizedBox(height:12),Text('${emergencyMap(item['finding'])['title']}',style:Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight:FontWeight.w700)),const SizedBox(height:8),
          Text('${item['siteName']} · ${item['deviceName']}'),const SizedBox(height:8),Text('${emergencyMap(item['finding'])['summary']}'),const SizedBox(height:8),Text('آخر رصد: ${emergencyTime(item['lastSeenAt'])}',style:Theme.of(context).textTheme.bodySmall),
          const SizedBox(height:14),FilledButton.icon(key:Key('emergency-remedy-${item['id']}'),onPressed:()=>_page(EmergencyIncidentPage(account:widget.account,id:'${item['id']}',onDevice:widget.onDevice)),icon:const Icon(Icons.build_outlined),label:Text('${emergencyMap(item['finding'])['action']}')),
        ]))),const SizedBox(height:12),
      ],
      if(total>20)Wrap(alignment:WrapAlignment.center,spacing:16,crossAxisAlignment:WrapCrossAlignment.center,children:[OutlinedButton(onPressed:offset==0||loading?null:()=>_filterPage(offset-20),child:const Text('السابق')),Text('${total==0?0:offset+1} — ${math.min(offset+20,total)} من $total'),OutlinedButton(onPressed:offset+20>=total||loading?null:()=>_filterPage(offset+20),child:const Text('التالي'))]),
      const SizedBox(height: 24), CommandOverview(key: statisticsKey, devices: selected, worker: worker, onDetails: (d) => _page(CommandDevicePage(account: widget.account, id: '${d['id']}'))),
      if (widget.account.canManage) CommandActivationSummary(key: activationsKey, account: widget.account, siteId: site, deviceId: device),
      const SizedBox(height:20),Wrap(alignment:WrapAlignment.spaceBetween,runSpacing:10,spacing:10,crossAxisAlignment:WrapCrossAlignment.center,children:[Text('الأجهزة وتغطية القياس',style:Theme.of(context).textTheme.titleLarge),if(widget.account.role!='viewer'&&selected.any((d)=>d['enabled']==true))OutlinedButton.icon(onPressed:busy?null:()=>_batch(selected.where((d)=>d['enabled']==true).toList()),icon:const Icon(Icons.radar),label:const Text('قياس أجهزة هذا النطاق'))]),
      const SizedBox(height:12),
      if (ready && devices.isEmpty) OutlinedButton.icon(onPressed:widget.onDevices,icon:const Icon(Icons.add),label:const Text('فتح الأجهزة وإضافة راوتر')),
      for(final d in selected)...[
        emergencyCard(child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
          Text('${d['name']} · ${d['siteName']}',style:Theme.of(context).textTheme.titleMedium),const SizedBox(height:10),
          Wrap(spacing:8,runSpacing:8,children:[EmergencyBadge(d['monitoring']==true?'المراقبة مفعّلة':'قياس عند الطلب',state:'acknowledged'),if(d['enabled']!=true)const EmergencyBadge('الجهاز معطّل في التطبيق',state:'unknown'),if(_stale(d))const EmergencyBadge('لا توجد قراءة حديثة',state:'unknown'),if(_pending(d))const EmergencyBadge('القياس مجدول أو جارٍ',state:'acknowledged')]),
          const SizedBox(height:10),Text('آخر قياس: ${emergencyTime(d['lastRunAt'])}'),
          if (d['lastError'] != null) Text(d['lastError']=='action_cancelled'?'أُلغي طلب القياس.':'لم يكتمل القياس الأخير. راجع الاتصال والصلاحيات.',style:TextStyle(color:scheme.error)),
          if(d['coverage']!=null)Text('${emergencyMap(d['coverage'])['measured']} فحص مقاس من ${emergencyMap(d['coverage'])['total']} · ${emergencyMap(d['coverage'])['unknown']} غير متاح'),
          ExpansionTile(tilePadding:EdgeInsets.zero,title:const Text('المصادر غير المتاحة وأسبابها'),children:[for(final row in emergencyRows(emergencyMap(d['coverage'])['unavailable']))ListTile(contentPadding:EdgeInsets.zero,title:Text('${row['title']}'),subtitle:Text('${row['reason']}')),if(d['coverage']==null)const ListTile(contentPadding:EdgeInsets.zero,title:Text('لم يُنفّذ قياس محفوظ لهذا الجهاز.'))]),
          Wrap(spacing:8,runSpacing:8,children:[
            if(widget.account.role!='viewer'&&d['enabled']==true)OutlinedButton.icon(onPressed:busy||_pending(d)?null:()=>_scan(d),icon:const Icon(Icons.radar),label:const Text('قياس الآن')),
            if(widget.account.role!='viewer'&&_pending(d))OutlinedButton(onPressed:busy?null:()=>_act(()async{await api.post('devices/${d['id']}/cancel-scan',{'requestId':d['requestId']});}),child:const Text('إلغاء القياس')),
            if(widget.account.canManage&&d['enabled']==true)OutlinedButton.icon(onPressed:busy?null:()=>_page(EmergencySettings(account:widget.account,device:d)),icon:const Icon(Icons.tune),label:const Text('إعداد الرادار والمعالجة')),
            TextButton(onPressed:()=>widget.onDevice('${d['id']}','${d['name']}'),child:const Text('فحص الجهاز والسجل')),
            TextButton.icon(onPressed: () => _page(CommandDevicePage(account: widget.account, id: '${d['id']}')), icon: const Icon(Icons.dashboard_outlined), label: const Text('قراءات مركز التحكم')),
          ]),
        ])),const SizedBox(height:12),
      ],
      const SizedBox(height:12),Text('الرصد يعتمد على ما يدعمه الراوتر وما يسمح به حساب القراءة. تغييرات الراوتر تظهر في معاينة مستقلة، ولا ينفذها الذكاء الاصطناعي مباشرة.',style:Theme.of(context).textTheme.bodySmall),
    ])))));
  }
  void _filterPage(int page) { setState(()=>offset=page);_load(); }
}
class _RadarPainter extends CustomPainter {
  const _RadarPainter({required this.active}); final int active;
  @override
  void paint(Canvas canvas,Size size) {
    final center=Offset(size.width/2,size.height/2),radius=size.shortestSide/2-3;
    final grid=Paint()..color=const Color(0xFF38BDF8).withValues(alpha:0.35)..style=PaintingStyle.stroke..strokeWidth=1;
    for(final factor in [1.0,0.67,0.34]) { canvas.drawCircle(center,radius*factor,grid); }
    canvas.drawLine(Offset(center.dx,3),Offset(center.dx,size.height-3),grid);canvas.drawLine(Offset(3,center.dy),Offset(size.width-3,center.dy),grid);
    canvas.drawLine(center,Offset(size.width-12,18),Paint()..color=const Color(0xFF67E8F9)..strokeWidth=2);
    canvas.drawCircle(Offset(center.dx+20,center.dy-20),5,Paint()..color=active>0?const Color(0xFFFDA4AF):const Color(0xFF38BDF8));
    canvas.drawCircle(center,3,Paint()..color=Colors.white);
  }
  @override
  bool shouldRepaint(_RadarPainter oldDelegate)=>oldDelegate.active!=active;
}
