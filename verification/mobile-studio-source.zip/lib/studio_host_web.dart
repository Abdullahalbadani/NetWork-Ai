import 'dart:js_interop';
import 'dart:js_interop_unsafe';
import 'dart:ui_web' as ui_web;
import 'package:flutter/material.dart';
@JS('document.createElement')
external JSObject _createElement(String tag);
@JS('window')
external JSObject get _window;
Widget studioHost(String html, String nonce, Future<Map<String, dynamic>> Function(Map<String, dynamic>) handler) => _WebStudio(html: html, nonce: nonce, handler: handler);
class _WebStudio extends StatefulWidget {
  const _WebStudio({required this.html, required this.nonce, required this.handler});
  final String html, nonce;
  final Future<Map<String, dynamic>> Function(Map<String, dynamic>) handler;
  @override
  State<_WebStudio> createState() => _WebStudioState();
}
class _WebStudioState extends State<_WebStudio> {
  late final JSObject _frame;
  late final JSFunction _listener;
  late final String _viewType;
  @override
  void initState() {
    super.initState();
    _viewType = 'copilot-card-studio-${widget.nonce}';
    _frame = _createElement('iframe');
    _frame.setProperty('title'.toJS, 'استوديو الكروت'.toJS);
    _frame.setProperty('sandbox'.toJS, 'allow-scripts allow-downloads allow-modals allow-popups allow-popups-to-escape-sandbox'.toJS);
    _frame.setProperty('allow'.toJS, 'web-share *'.toJS);
    _frame.setProperty('srcdoc'.toJS, widget.html.toJS);
    final style = _frame.getProperty<JSObject>('style'.toJS);
    style.setProperty('width'.toJS, '100%'.toJS);
    style.setProperty('height'.toJS, '100%'.toJS);
    style.setProperty('border'.toJS, '0'.toJS);
    _listener = ((JSObject event) {
      final source = event.getProperty<JSAny?>('source'.toJS);
      if (source != _frame.getProperty<JSAny?>('contentWindow'.toJS)) { return; }
      final data = event.getProperty<JSAny?>('data'.toJS)?.dartify();
      if (data is! Map || data['nonce'] != widget.nonce || data['kind'] != 'ncp-studio') { return; }
      widget.handler(data.cast<String, dynamic>()).then((reply) {
        if (!mounted) { return; }
        final window = _frame.getProperty<JSObject?>('contentWindow'.toJS);
        window?.callMethod<JSAny?>('postMessage'.toJS, {...reply, 'kind': 'ncp-studio-reply'}.jsify(), '*'.toJS);
      });
    }).toJS;
    _window.callMethod<JSAny?>('addEventListener'.toJS, 'message'.toJS, _listener);
    ui_web.platformViewRegistry.registerViewFactory(_viewType, (_) => _frame);
  }
  @override
  void dispose() {
    _window.callMethod<JSAny?>('removeEventListener'.toJS, 'message'.toJS, _listener);
    super.dispose();
  }
  @override
  Widget build(BuildContext context) => HtmlElementView(viewType: _viewType);
}
