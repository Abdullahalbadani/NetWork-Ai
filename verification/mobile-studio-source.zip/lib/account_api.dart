import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/legacy.dart' show ChangeNotifierProvider;
import 'package:http/http.dart' as http;
import 'api.dart';
import 'session_store.dart';
import 'transport.dart';
import 'session_expiry.dart';

class AccountFailure implements Exception {
  const AccountFailure(this.code, this.status);
  final String code;
  final int status;
  String get message => switch (code) {
    'action_cancelled' => 'أُلغي الطلب. راجع حالة العملية إن كان التنفيذ قد بدأ.',
    'operation_cancelled' => 'تغيرت الجلسة؛ أعد العملية من الحساب الحالي.',
    'authentication_failed' => 'لم ينجح التحقق. راجع البيانات أو رمز المصادقة.',
    'unauthorized' => 'انتهت الجلسة. سجّل الدخول مجددًا.',
    'forbidden' => 'لا يملك حسابك صلاحية هذا الإجراء.',
    'not_found' =>
      'لم يعد السجل متاحًا، أو لا تملك صلاحية الوصول إليه. حدّث القائمة.',
    'workspace_not_found' => 'مساحة العمل غير متاحة لهذا الحساب.',
    'step_up_required' => 'أكد هويتك برمز المصادقة لإكمال الإجراء.',
    'mfa_required' => 'أكمل تفعيل تطبيق المصادقة أولًا.',
    'password_change_required' => 'غيّر كلمة المرور الأولية أولًا.',
    'rate_limited' => 'بلغت حد المحاولات. انتظر قليلًا ثم حاول مجددًا.',
    'scan_busy' => 'هناك فحوص أخرى قيد التنفيذ. انتظر قليلًا ثم أعد المحاولة.',
    'scan_running' => 'يوجد فحص جارٍ لهذا الراوتر. حدّث النتائج لمتابعته.',
    'health_profile_limit' =>
      'يمكن تحديد أدوار وتوقعات لـ64 واجهة في إعدادات هذا الفحص.',
    'health_profile_too_large' =>
      'حجم إعدادات الفحص كبير جدًا. قلل عدد الواجهات المحددة.',
    'ai_not_configured' => 'خدمة الذكاء الاصطناعي غير مهيأة في الخادم.',
    'ai_rate_limited' => 'بلغت حد طلبات الشرح. انتظر دقيقة ثم حاول مجددًا.',
    'ai_timeout' =>
      'انتهت مهلة الشرح. تقرير الفحص محفوظ ويمكنك إعادة المحاولة.',
    'ai_unavailable' => 'تعذرت خدمة الشرح الآن. تقرير الفحص ما زال متاحًا.',
    'ai_context_too_large' => 'حجم أدلة العطل أكبر من الحد المتاح للشرح.',
    'tariff_limit' => 'بلغ هذا الجهاز حد 100 قاعدة سعر. عدّل قاعدة محفوظة بدل إضافة أخرى.',
    'version_conflict' => 'تغير السجل منذ فتحه. حدّث القائمة ثم أعد التعديل.',
    'site_range_overlaps' => 'يتداخل النطاق مع موقع آخر على مسار الاتصال نفسه.',
    'connector_range_not_granted' ||
    'router_origin_not_granted' ||
    'router_outside_site' =>
      'عنوان الجهاز أو الموقع خارج نطاق الاتصال المعتمد في الخادم.',
    'invalid_ca_certificate' => 'اختر شهادة CA عامة سارية، دون مفتاح خاص.',
    'device_unavailable' =>
      'لم ينجح التحقق من الراوتر. راجع HTTPS والشهادة وبيانات القراءة.',
    'already_exists' ||
    'account_unavailable' => 'يوجد سجل مماثل أو أن الحساب غير متاح للإضافة.',
    'separate_write_credential_required' => 'استخدم حساب كتابة مستقلًا عن حساب القراءة الحالي.',
    'write_grant_required' => 'لم يُفعّل حساب كتابة مستقل لهذا الراوتر.',
    'write_grant_changed' => 'تغير حساب الكتابة أو أُوقف؛ راجع الدفعة وأعد اعتمادها.',
    'router_profile_missing' => 'اسم ملف Hotspot في الباقة غير موجود في الراوتر.',
    'router_write_unavailable' => 'تعذر التحقق الآمن من الراوتر. راجع الشهادة وصلاحيات حساب الكتابة.',
    'router_outcome_unknown' => 'لم تتأكد نتيجة الراوتر. استخدم التحقق من الحالة قبل إعادة أي تنفيذ.',
    'router_user_conflict' => 'يوجد مستخدم مختلف بالاسم نفسه على الراوتر؛ لم نعدله.',
    'approval_required' => 'احفظ المعاينة واعتمد النسخة الحالية قبل المتابعة.',
    'device_busy' => 'توجد عملية جارية على هذا الراوتر. انتظر اكتمالها ثم حدّث الحالة.',
    'worker_busy' => 'بلغ الخادم حد العمليات المتزامنة؛ انتظر قليلًا ثم حدّث الحالة.',
    'device_disabled' => 'عُطل الجهاز في التطبيق؛ توقفت الكتابة التالية.',
    'no_active_cards' => 'لا توجد كروت تأكد إنشاؤها على الراوتر للطباعة.',
    'idempotency_conflict' => 'وصل الطلب نفسه ببيانات مختلفة. حدّث قائمة الدفعات قبل إنشاء طلب آخر.',
    'invalid_plan' => 'الباقة غير متاحة أو تتبع موقعًا آخر.',
    'invalid_reseller' => 'نقطة البيع غير متاحة في هذا الموقع.',
    'operations_limit' => 'بلغت حد السجلات أو الكروت في مساحة العمل.',
    'portal_catalog_too_large' => 'يعرض التصميم حتى 100 باقة و100 نقطة بيع؛ أرشف غير المستخدم.',
    'invalid_request' => 'راجع الحقول المطلوبة وصيغة البيانات.',
    'invalid_cidr' ||
    'invalid_ipv4' ||
    'cidr_requires_network_address' => 'راجع الحقول المطلوبة ونطاق الشبكة.',
    'repair_settings_incomplete' => 'حدد مسار إدارة محميًا وإجراءات مسموحة وحساب معالجة مستقلًا بكلمة مرور لا تقل عن 14 حرفًا.',
    'separate_repair_account_required' => 'استخدم حساب معالجة مستقلًا عن حساب القراءة وعن admin.',
    'repair_account_unavailable' => 'تعذر التحقق من حساب المعالجة عبر HTTPS. راجع الشهادة وصلاحيات الحساب وإصدار RouterOS 7.',
    'repair_grant_required' => 'فعّل حساب المعالجة وصلاحياته من إعداد الرادار لهذا الجهاز.',
    'repair_not_allowed' || 'protected_repair_target' => 'هذا التغيير خارج الصلاحية أو يستهدف منفذًا محميًا. راجع سياسة المعالجة.',
    'invalid_repair_target' => 'لم تتأكد هوية العنصر المقروء على الراوتر. أعد القياس والمعاينة.',
    'management_path_required' => 'يلزم منفذ Ethernet إدارة مستقل ومقروء يعمل الآن، ومحمي من المعالجة. تحقق من مسار الإدارة أولًا.',
    'radio_policy_required' => 'اعتمد قناة لهذا الراديو وتحقق من البلد ومسار إدارة مستقل قبل المعالجة.',
    'fresh_observation_required' => 'أعد قياس العطل للحصول على دليل حديث قبل إنشاء معاينة جديدة.',
    'repair_approval_required' => 'انتهت المعاينة أو تغيرت الصلاحية؛ أنشئ معاينة حديثة واعتمدها.',
    'router_state_changed' => 'تغيرت قيم الراوتر بعد المعاينة. لم ننفذ التغيير؛ راجع الحالة وأعد المعاينة.',
    'repair_already_applied' => 'القيمة المستهدفة موجودة بالفعل؛ أعد قياس الرادار.',
    'context_changed' => 'تغير الجهاز أو الصلاحيات أثناء العملية؛ حدّث الحالة قبل المتابعة.',
    'restore_not_available' || 'reconcile_not_available' => 'حالة العملية الحالية لا تسمح بهذا الإجراء. حدّث النتيجة.',
    'monitor_limit' || 'emergency_history_limit' || 'emergency_sample_limit' => 'بلغت حد الأجهزة المراقبة أو السجلات المسموح بها؛ راجع الإعداد قبل المتابعة.',
    'network_error' =>
      'تعذر الاتصال الآمن بالخادم. راجع عنوانه وشهادة المختبر وتشغيل الخدمة.',
    'secure_storage_failed' =>
      'تعذر الوصول إلى مخزن الجلسة الآمن. لم تُحفظ الجلسة في ملف عادي.',
    _ => 'تعذر إكمال العملية. حدّث البيانات ثم حاول مجددًا.',
  };
  @override
  String toString() => message;
}

final accountProvider = ChangeNotifierProvider<AccountController>((ref) {
  final controller = AccountController();
  return controller;
});

class AccountController extends ChangeNotifier {
  AccountController({
    SessionStore? store,
    http.Client Function()? clientFactory,
  }) : _store = store ?? createSessionStore(),
       _clientFactory = clientFactory ?? createTransport {
    _expiry = SessionExpiry.notices.listen((notice) {
      if (notice.endpoint == endpoint && notice.token == _token) {
        unawaited(_expire());
      }
    });
  }
  late final StreamSubscription<SessionExpiryNotice> _expiry;
  Future<void> _expire() async {
    try {
      await forget();
    } catch (_) {
      restoreError = const AccountFailure('secure_storage_failed', 0).message;
      _changed();
    }
  }

  final SessionStore _store;
  final http.Client Function() _clientFactory;
  final Set<http.Client> _active = {};
  String endpoint = 'https://127.0.0.1:3443';
  String? _token, workspaceId, _certificate;
  Map<String, dynamic>? profile;
  Timer? _refresh;
  bool restoring = true, _disposed = false;
  String? restoreError;
  int _generation = 0, _restoreJob = 0;
  Future<void> _storageTail = Future<void>.value();
  Future<T> _serialStorage<T>(Future<T> Function() action) {
    final next = _storageTail.then((_) => action());
    _storageTail = next.then<void>(
      (_) {},
      onError: (Object _, StackTrace _) {},
    );
    return next;
  }

  void _closeRequests() {
    for (final client in _active.toList()) {
      client.close();
    }
    _active.clear();
  }

  bool get signedIn => _token != null && profile != null;
  String get role =>
      workspaces.where((w) => w['id'] == workspaceId).firstOrNull?['role']
          as String? ??
      '';
  bool get canManage => role == 'owner' || role == 'admin';
  bool get canChat => role != 'viewer';
  bool get mfaRequired => profile?['mfaRequired'] == true;
  bool get passwordChangeRequired => profile?['passwordChangeRequired'] == true;
  List<Map<String, dynamic>> get workspaces =>
      (profile?['workspaces'] as List? ?? []).cast<Map<String, dynamic>>();
  String? get certificate => _certificate;
  void _changed() {
    if (!_disposed) notifyListeners();
  }

  void setEndpoint(String value) {
    if (_token != null) {
      throw StateError('Sign out before changing the server.');
    }
    if (!validEndpoint(value) || Uri.parse(value).scheme != 'https') {
      throw const AccountFailure('invalid_request', 400);
    }
    final next = value.replaceFirst(RegExp(r'/$'), '');
    if (next != endpoint) {
      setLabTrust(null);
      _certificate = null;
    }
    endpoint = next;
  }

  void setCertificate(String? value) {
    if (_token != null) throw StateError('Sign out before changing trust.');
    if (value != null &&
        (!kDebugMode ||
            kIsWeb ||
            value.length > 12000 ||
            !value.trim().startsWith('-----BEGIN CERTIFICATE-----') ||
            value.contains('PRIVATE KEY'))) {
      throw const AccountFailure('invalid_ca_certificate', 400);
    }
    setLabTrust(value == null ? null : Uint8List.fromList(utf8.encode(value)));
    _certificate = value;
  }

  Future<void> restore() async {
    final generation = ++_generation, job = ++_restoreJob;
    _closeRequests();
    _refresh?.cancel();
    restoring = true;
    restoreError = null;
    _token = null;
    profile = null;
    workspaceId = null;
    _changed();
    try {
      final value = await _serialStorage(_store.read);
      if (generation != _generation || _disposed) return;
      if (value != null) {
        final saved = jsonDecode(value) as Map<String, dynamic>;
        setEndpoint(saved['endpoint'] as String);
        setCertificate(saved['certificate'] as String?);
        _token = saved['token'] as String;
        await loadProfile();
      }
    } on AccountFailure catch (error) {
      if (generation == _generation && !_disposed) {
        if (error.code == 'network_error') {
          restoreError = error.message;
        } else {
          await forget();
        }
      }
    } catch (_) {
      if (generation == _generation && !_disposed) {
        _token = null;
        profile = null;
        workspaceId = null;
        try {
          await _serialStorage(_store.clear);
        } catch (_) {
          restoreError = const AccountFailure(
            'secure_storage_failed',
            0,
          ).message;
        }
      }
    } finally {
      if (job == _restoreJob && !_disposed) {
        restoring = false;
        _changed();
      }
    }
  }

  Future<Map<String, dynamic>> request(
    String method,
    String path, {
    Map<String, dynamic>? body,
    bool auth = true,
    Map<String, String>? query,
  }) async {
    if (_disposed ||
        !validEndpoint(endpoint) ||
        Uri.parse(endpoint).scheme != 'https') {
      throw const AccountFailure('invalid_request', 400);
    }
    final generation = _generation,
        requestToken = _token,
        client = _clientFactory();
    _active.add(client);
    try {
      final req = http.Request(method, Uri.parse(endpoint).replace(path: path, queryParameters: query))
        ..followRedirects = false;
      if (body != null) req.headers['Content-Type'] = 'application/json';
      if (auth) {
        if (_token == null) throw const AccountFailure('unauthorized', 401);
        req.headers['Authorization'] = 'Bearer $_token';
        if (workspaceId != null) req.headers['X-Workspace-Id'] = workspaceId!;
      }
      if (body != null) req.body = jsonEncode(body);
      final result = await (() async {
        final response = await client.send(req);
        final bytes = BytesBuilder(copy: false);
        await for (final chunk in response.stream) {
          if (bytes.length + chunk.length > 2 * 1024 * 1024) {
            throw const AccountFailure('invalid_response', 502);
          }
          bytes.add(chunk);
        }
        final value = jsonDecode(utf8.decode(bytes.takeBytes()));
        if (value is! Map<String, dynamic>) {
          throw const AccountFailure('invalid_response', 502);
        }
        if (response.statusCode < 200 || response.statusCode >= 300) {
          throw AccountFailure(
            value['error'] is String
                ? value['error'] as String
                : 'request_failed',
            response.statusCode,
          );
        }
        return value;
      })().timeout(const Duration(seconds: 25));
      if (generation != _generation || _disposed) {
        throw const AccountFailure('operation_cancelled', 0);
      }
      return result;
    } on AccountFailure catch (e) {
      if (generation != _generation || _disposed) {
        throw const AccountFailure('operation_cancelled', 0);
      }
      if (auth && e.code == 'unauthorized' && requestToken == _token) {
        await forget();
      }
      rethrow;
    } catch (_) {
      if (generation != _generation || _disposed) {
        throw const AccountFailure('operation_cancelled', 0);
      }
      throw const AccountFailure('network_error', 0);
    } finally {
      _active.remove(client);
      client.close();
    }
  }

  Future<void> _persist() async {
    final generation = _generation, sessionToken = _token;
    if (sessionToken == null) return;
    final value = jsonEncode({
      'endpoint': endpoint,
      'token': sessionToken,
      'certificate': _certificate,
    });
    try {
      await _serialStorage(() async {
        if (generation == _generation && !_disposed && sessionToken == _token) {
          await _store.write(value);
        }
      });
    } catch (_) {
      if (generation == _generation && sessionToken == _token && !_disposed) {
        await forget();
      }
      throw const AccountFailure('secure_storage_failed', 0);
    }
  }

  Future<void> accept(Map<String, dynamic> value) async {
    if (value['token'] is! String || (value['token'] as String).isEmpty) {
      throw const AccountFailure('invalid_response', 502);
    }
    final next = value['token'] as String;
    if (next != _token) {
      _generation++;
      _closeRequests();
    }
    final generation = _generation;
    _token = next;
    await loadProfile();
    if (generation != _generation || _disposed) {
      throw const AccountFailure('operation_cancelled', 0);
    }
    await _persist();
    if (generation != _generation || _disposed) {
      throw const AccountFailure('operation_cancelled', 0);
    }
  }

  Future<void> loadProfile() async {
    final generation = _generation, sessionToken = _token;
    final value = await request('GET', '/v1/me');
    if (generation != _generation || sessionToken != _token || _disposed) {
      throw const AccountFailure('operation_cancelled', 0);
    }
    if (value['user'] is! Map ||
        value['workspaces'] is! List ||
        value['mfaRequired'] is! bool ||
        value['passwordChangeRequired'] is! bool) {
      throw const AccountFailure('invalid_response', 502);
    }
    final user = value['user'] as Map;
    final memberships = value['workspaces'] as List;
    if (user['id'] is! String ||
        user['name'] is! String ||
        user['email'] is! String ||
        value['expiresAt'] is! String ||
        DateTime.tryParse(value['expiresAt'] as String) == null ||
        memberships.any(
          (w) =>
              w is! Map<String, dynamic> ||
              w['id'] is! String ||
              w['name'] is! String ||
              !['owner', 'admin', 'technician', 'viewer'].contains(w['role']),
        )) {
      throw const AccountFailure('invalid_response', 502);
    }
    if (memberships.isEmpty) {
      await forget();
      throw const AccountFailure('workspace_not_found', 403);
    }
    profile = value;
    if (!workspaces.any((w) => w['id'] == workspaceId)) {
      workspaceId = workspaces.firstOrNull?['id'] as String?;
    }
    _refresh?.cancel();
    _refresh = Timer.periodic(const Duration(minutes: 10), (_) {
      unawaited(refresh());
    });
    _changed();
  }

  Future<Map<String, dynamic>> login(String email, String password) async {
    final result = await request(
      'POST',
      '/v1/auth/login',
      auth: false,
      body: {'email': email, 'password': password},
    );
    if (result['token'] is String) await accept(result);
    return result;
  }

  Future<void> verify(String challenge, String code, bool backup) async {
    await accept(
      await request(
        'POST',
        '/v1/auth/verify',
        auth: false,
        body: {'challengeId': challenge, 'code': code, 'backup': backup},
      ),
    );
  }

  void suspend() {
    _refresh?.cancel();
    _refresh = null;
  }

  void resume() {
    if (signedIn) {
      unawaited(refresh());
    }
  }

  Future<void> refresh() async {
    if (_token == null || _disposed) return;
    try {
      await request('POST', '/v1/auth/refresh', body: {});
      await loadProfile();
    } on AccountFailure {
      // request() revokes only the matching session; stale responses cannot clear a newer login.
    }
  }

  Future<void> changePassword(String old, String next) async {
    await accept(
      await request(
        'POST',
        '/v1/auth/password',
        body: {'currentPassword': old, 'newPassword': next},
      ),
    );
  }

  Future<void> confirmEnrollment(String code) async {
    await accept(
      await request('POST', '/v1/auth/mfa/confirm', body: {'code': code}),
    );
  }

  Future<void> stepUp(String code) async {
    await accept(
      await request('POST', '/v1/auth/step-up', body: {'code': code}),
    );
  }

  void selectWorkspace(String id) {
    if (!workspaces.any((w) => w['id'] == id)) {
      throw const AccountFailure('workspace_not_found', 403);
    }
    if (workspaceId == id) return;
    _generation++;
    _closeRequests();
    workspaceId = id;
    _changed();
  }

  LabConnection connection(String deviceId) => LabConnection(
    endpoint: endpoint,
    token: _token!,
    deviceId: deviceId,
    workspaceId: workspaceId,
  );
  Future<void> logout() async {
    final generation = _generation, sessionToken = _token;
    // A late logout response belongs only to the session that requested it.
    try {
      await request('POST', '/v1/auth/logout', body: {});
    } finally {
      if (generation == _generation && sessionToken == _token && !_disposed) {
        await forget();
      }
    }
  }

  Future<void> forget() async {
    _generation++;
    _refresh?.cancel();
    _refresh = null;
    for (final c in _active.toList()) {
      c.close();
    }
    _active.clear();
    _token = null;
    profile = null;
    workspaceId = null;
    restoreError = null;
    try {
      await _serialStorage(_store.clear);
    } finally {
      _changed();
    }
  }

  @override
  void dispose() {
    _disposed = true;
    _generation++;
    _restoreJob++;
    unawaited(_expiry.cancel());
    _refresh?.cancel();
    for (final c in _active) {
      c.close();
    }
    _active.clear();
    _token = null;
    profile = null;
    super.dispose();
  }
}
