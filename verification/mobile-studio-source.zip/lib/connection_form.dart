import 'package:flutter/material.dart';

import 'api.dart';
import 'ui.dart';

class ConnectionForm extends StatefulWidget {
  const ConnectionForm({super.key, this.initial, required this.onConnect});
  final LabConnection? initial;
  final ValueChanged<LabConnection> onConnect;

  @override
  State<ConnectionForm> createState() => _ConnectionFormState();
}

class _ConnectionFormState extends State<ConnectionForm> {
  final _form = GlobalKey<FormState>();
  late final _endpoint = TextEditingController(
    text: widget.initial?.endpoint ?? (localLab ? 'http://127.0.0.1:3000' : ''),
  );
  late final _token = TextEditingController(text: widget.initial?.token ?? '');
  late final _device = TextEditingController(
    text: widget.initial?.deviceId ?? (localLab ? 'chr-lab' : ''),
  );
  bool _obscure = true;

  @override
  void dispose() {
    _endpoint.dispose();
    _token.dispose();
    _device.dispose();
    super.dispose();
  }

  void _submit() {
    if (_form.currentState!.validate()) {
      widget.onConnect(
        LabConnection(
          endpoint: _endpoint.text.trim(),
          token: _token.text.trim(),
          deviceId: _device.text.trim(),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    return Form(
      key: _form,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          const InfoBadge(
            label: 'مساحة عمل مختبرية',
            icon: Icons.science_outlined,
          ),
          const SizedBox(height: 18),
          Text(
            widget.initial == null ? 'اتصل بمساحة عملك' : 'إعداد الاتصال',
            style: theme.textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'استخدم عنوان خادمك ورمز التطبيق لقراءة جهاز مسجّل لديك.',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: scheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 28),
          TextFormField(
            key: const Key('server-url'),
            controller: _endpoint,
            textDirection: TextDirection.ltr,
            keyboardType: TextInputType.url,
            textInputAction: TextInputAction.next,
            autocorrect: false,
            decoration: const InputDecoration(
              labelText: 'عنوان خادم الإدارة',
              prefixIcon: Icon(Icons.dns_outlined),
              hintText: 'https://server.example.com',
            ),
            validator: (value) => validEndpoint(value?.trim() ?? '')
                ? null
                : 'أدخل عنوان HTTPS صالحًا أو عنوان المختبر المحلي.',
          ),
          const SizedBox(height: 18),
          TextFormField(
            key: const Key('access-token'),
            controller: _token,
            obscureText: _obscure,
            enableSuggestions: false,
            enableIMEPersonalizedLearning: false,
            autocorrect: false,
            textDirection: TextDirection.ltr,
            textInputAction: TextInputAction.next,
            decoration: InputDecoration(
              labelText: 'رمز وصول التطبيق',
              prefixIcon: const Icon(Icons.key_outlined),
              suffixIcon: IconButton(
                tooltip: _obscure ? 'إظهار رمز الوصول' : 'إخفاء رمز الوصول',
                onPressed: () => setState(() => _obscure = !_obscure),
                icon: Icon(
                  _obscure
                      ? Icons.visibility_outlined
                      : Icons.visibility_off_outlined,
                  size: 21,
                ),
              ),
            ),
            validator: (value) => value == null || value.trim().isEmpty
                ? 'أدخل رمز وصول التطبيق.'
                : null,
          ),
          const SizedBox(height: 18),
          TextFormField(
            key: const Key('device-id'),
            controller: _device,
            textDirection: TextDirection.ltr,
            textInputAction: TextInputAction.done,
            onFieldSubmitted: (_) => _submit(),
            decoration: const InputDecoration(
              labelText: 'معرّف الجهاز',
              prefixIcon: Icon(Icons.router_outlined),
              hintText: 'chr-lab',
            ),
            validator: (value) => value == null || value.trim().isEmpty
                ? 'أدخل معرّف الجهاز المسجّل في الخادم.'
                : null,
          ),
          const SizedBox(height: 26),
          FilledButton.icon(
            key: const Key('connect'),
            onPressed: _submit,
            icon: const Icon(Icons.arrow_back, size: 20),
            label: Text(
              widget.initial == null ? 'دخول مساحة العمل' : 'حفظ الاتصال',
            ),
          ),
          const SizedBox(height: 16),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(
                Icons.lock_outline,
                size: 16,
                color: scheme.onSurfaceVariant,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'تبقى بيانات دخول الراوتر ومفتاح Gemini في خادمك. الاتصال هنا مؤقت لهذه الجلسة.',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key, required this.onConnect});
  final ValueChanged<LabConnection> onConnect;

  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, constraints) {
      final wide = constraints.maxWidth >= 1000;
      return SingleChildScrollView(
        child: ConstrainedBox(
          constraints: BoxConstraints(minHeight: constraints.maxHeight),
          child: Center(
            child: Padding(
              padding: EdgeInsets.all(wide ? 48 : 20),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 1180),
                child: wide
                    ? Row(
                        children: [
                          const Expanded(child: _WelcomeHero()),
                          const SizedBox(width: 56),
                          SizedBox(width: 460, child: _formCard(context)),
                        ],
                      )
                    : Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              BrandMark(size: 38),
                              SizedBox(width: 12),
                              Text(
                                'مساعد الشبكة',
                                style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 24),
                          ConstrainedBox(
                            constraints: const BoxConstraints(maxWidth: 520),
                            child: _formCard(context),
                          ),
                        ],
                      ),
              ),
            ),
          ),
        ),
      );
    },
  );

  Widget _formCard(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(26),
      child: ConnectionForm(onConnect: onConnect),
    ),
  );
}

class _WelcomeHero extends StatelessWidget {
  const _WelcomeHero();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        const Row(
          children: [
            BrandMark(size: 52),
            SizedBox(width: 14),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'مساعد الشبكة',
                  style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700),
                ),
                Text(
                  'NETWORK COPILOT',
                  style: TextStyle(fontSize: 11, letterSpacing: 2),
                ),
              ],
            ),
          ],
        ),
        const SizedBox(height: 48),
        Text(
          'صورة أوضح لشبكتك.\nوخطوة أذكى بعدها.',
          style: theme.textTheme.displaySmall?.copyWith(
            fontWeight: FontWeight.w700,
            height: 1.55,
            fontSize: 38,
          ),
        ),
        const SizedBox(height: 18),
        Text(
          'تابع موارد جهازك، وافهم واجهاته وجلساته، واسأل مساعدك من مساحة عمل واحدة.',
          style: theme.textTheme.bodyLarge?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        const SizedBox(height: 32),
        const Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            InfoBadge(label: 'موارد الجهاز', icon: Icons.speed_outlined),
            InfoBadge(label: 'واجهات وجلسات', icon: Icons.hub_outlined),
            InfoBadge(label: 'مساعد ذكي', icon: Icons.auto_awesome_outlined),
          ],
        ),
        const SizedBox(height: 36),
        TextButton.icon(
          onPressed: () => showLicensePage(
            context: context,
            applicationName: 'مساعد الشبكة',
              applicationVersion: '0.5.0',
          ),
          icon: const Icon(Icons.info_outline, size: 17),
          label: const Text('تراخيص التطبيق'),
        ),
      ],
    );
  }
}
