import 'package:flutter/material.dart';
import 'account_api.dart';
import 'account_views.dart';
import 'emergency_api.dart';
import 'emergency_common.dart';

class CommandTariffsPage extends StatefulWidget {
  const CommandTariffsPage({super.key, required this.account, required this.deviceId});
  final AccountController account;
  final String deviceId;
  @override
  State<CommandTariffsPage> createState() => _CommandTariffsPageState();
}
class _CommandTariffsPageState extends State<CommandTariffsPage> {
  final name = TextEditingController(), profile = TextEditingController(), quota = TextEditingController(), minutes = TextEditingController(), price = TextEditingController();
  final form = GlobalKey<FormState>();
  List<Map<String, dynamic>> rows = [];
  String id = emergencyRequestId();
  int version = 0;
  bool loading = false, busy = false, archived = false;
  String? error;
  @override
  void initState() { super.initState(); load(); }
  @override
  void dispose() { name.dispose(); profile.dispose(); quota.dispose(); minutes.dispose(); price.dispose(); super.dispose(); }
  Future<void> load() async {
    setState(() { loading = true; error = null; });
    try { final data = await EmergencyApi(widget.account).get('devices/${widget.deviceId}/tariffs'); if (mounted) setState(() => rows = emergencyRows(data['items'])); }
    catch (e) { if (mounted) setState(() { error = accountError(e); if (e is AccountFailure && [401, 403, 404].contains(e.status)) rows = []; }); }
    finally { if (mounted) setState(() => loading = false); }
  }
  void edit(Map<String, dynamic>? row) { setState(() {
    id = row?['id'] as String? ?? emergencyRequestId(); version = row?['version'] as int? ?? 0; archived = row?['archived'] == true;
    name.text = row?['name'] as String? ?? ''; profile.text = row?['profile'] as String? ?? '';
    quota.text = row == null ? '' : '${row['quotaMiB']}'; minutes.text = row == null ? '' : '${row['uptimeMinutes']}'; price.text = row == null ? '' : '${row['price']}'; error = null;
  }); }
  Future<void> save() async {
    if (busy || !form.currentState!.validate()) return;
    setState(() { busy = true; error = null; });
    try {
      await emergencyMutation(context, widget.account, () => EmergencyApi(widget.account).post('devices/${widget.deviceId}/tariffs', {'id': id, 'version': version, 'name': name.text.trim(), 'profile': profile.text.trim(), 'quotaMiB': int.parse(quota.text.trim()), 'uptimeMinutes': int.parse(minutes.text.trim()), 'price': int.parse(price.text.trim()), 'archived': archived}));
      if (mounted) { edit(null); await load(); if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('حُفظت قاعدة السعر للاستخدامات القادمة.'))); }
    } catch (e) { if (mounted) setState(() => error = accountError(e)); }
    finally { if (mounted) setState(() => busy = false); }
  }
  Widget numberField(TextEditingController control, String label, int maximum) => TextFormField(controller: control, enabled: !busy, keyboardType: TextInputType.number, textDirection: TextDirection.ltr, decoration: InputDecoration(labelText: label), validator: (value) {
    final n = int.tryParse(value?.trim() ?? ''); return n == null || n < 0 || n > maximum ? 'أدخل عددًا صحيحًا من 0 إلى $maximum.' : null;
  });
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('أسعار فئات الكروت · ريال يمني'), actions: [IconButton(tooltip: 'تحديث قواعد الأسعار', onPressed: busy || loading ? null : load, icon: const Icon(Icons.refresh))]), body: SingleChildScrollView(padding: const EdgeInsets.all(18), child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 850), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    const Text('للكروت المنشأة خارج التطبيق: حدّد سعرًا معتمدًا يطابق اسم ملف Hotspot والحصة والمدة بالضبط. كروت التطبيق تستخدم سعر باقتها المحفوظ وقت إصدارها.'),
    const SizedBox(height: 12), const Text('هذه قواعد إحصائية داخل التطبيق؛ لا تغيّر سعرًا أو إعدادًا في الراوتر، ولا تعيد تسعير تفعيل سابق. 0 للحصة أو المدة يعني غير محدود، و0 للسعر يعني كرتًا مجانيًا. سعر جديد داخل فترة رصد مبهمة يبقى غير محسوم.'),
    const SizedBox(height: 16), if (loading) const LinearProgressIndicator(),
    if (error != null) emergencyMessage(context, error!, error: true),
    Form(key: form, child: emergencyCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Text(version == 0 ? 'إضافة فئة معتمدة' : 'تعديل الفئة للاستخدام القادم', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 16), TextFormField(controller: name, enabled: !busy, maxLength: 100, decoration: const InputDecoration(labelText: 'اسم الفئة'), validator: (v) => v == null || v.trim().isEmpty ? 'أدخل اسم الفئة.' : null),
      const SizedBox(height: 12), TextFormField(controller: profile, enabled: !busy, maxLength: 100, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'اسم ملف Hotspot كما هو على الراوتر'), validator: (v) => v == null || v.trim().isEmpty ? 'أدخل اسم الملف الفعلي.' : null),
      const SizedBox(height: 12), numberField(quota, 'الحصة MiB', 1000000),
      const SizedBox(height: 16), numberField(minutes, 'المدة بالدقائق', 525600),
      const SizedBox(height: 16), numberField(price, 'السعر بالريال اليمني', 100000000),
      const SizedBox(height: 12), SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('أرشفة القاعدة وإيقاف استخدامها مستقبلًا'), value: archived, onChanged: busy ? null : (v) => setState(() => archived = v)),
      const SizedBox(height: 12), Wrap(spacing: 12, runSpacing: 10, children: [FilledButton.icon(onPressed: busy ? null : save, icon: const Icon(Icons.save_outlined), label: Text(busy ? 'جارٍ الحفظ…' : 'حفظ قاعدة السعر')), TextButton(onPressed: busy ? null : () => edit(null), child: const Text('فئة جديدة'))]),
    ]))),
    const SizedBox(height: 20), Text('قواعد الأسعار المحفوظة', style: Theme.of(context).textTheme.titleLarge),
    if (rows.isEmpty && !loading) const Padding(padding: EdgeInsets.only(top: 12), child: Text('لا توجد قواعد؛ تبقى أسعار الكروت الخارجية غير معروفة حتى اعتماد فئاتها.')),
    for (final row in rows) Card(child: ListTile(title: Text('${row['name']} · ${row['price']} ر.ي'), subtitle: Text('${row['profile']} · ${row['quotaMiB']} MiB · ${row['uptimeMinutes']} دقيقة${row['archived'] == true ? ' · مؤرشفة' : ''}'), trailing: IconButton(tooltip: 'تعديل قاعدة السعر', onPressed: busy ? null : () => edit(row), icon: const Icon(Icons.edit_outlined)))),
  ])))));
}
