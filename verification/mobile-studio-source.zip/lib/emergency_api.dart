import 'dart:math';
import 'account_api.dart';

String emergencyRequestId() {
  final random = Random.secure();
  final bytes = List.generate(16, (_) => random.nextInt(256));
  bytes[6] = (bytes[6] & 15) | 64;
  bytes[8] = (bytes[8] & 63) | 128;
  final hex = bytes.map((v) => v.toRadixString(16).padLeft(2, '0')).join();
  return '${hex.substring(0, 8)}-${hex.substring(8, 12)}-${hex.substring(12, 16)}-${hex.substring(16, 20)}-${hex.substring(20)}';
}
Map<String, dynamic> emergencyMap(dynamic value) => value is Map<String, dynamic> ? value : <String, dynamic>{};
List<Map<String, dynamic>> emergencyRows(dynamic value) => value is List ? value.map(emergencyMap).toList() : <Map<String, dynamic>>[];
String emergencyTime(dynamic value) {
  final date = DateTime.tryParse(value?.toString() ?? '')?.toLocal();
  if (date == null) return 'لم يُقَس بعد';
  String pad(int n) => n.toString().padLeft(2, '0');
  return '${date.year}/${pad(date.month)}/${pad(date.day)} ${pad(date.hour)}:${pad(date.minute)}:${pad(date.second)}';
}
const emergencyRepairNames = {
  'service.disable_plain': 'تعطيل خدمة الإدارة غير المشفرة',
  'interface.enable': 'تفعيل المنفذ المصرح به',
  'interface.isolate': 'عزل منفذ العملاء المصرح به',
  'dns.set_servers': 'تعيين خوادم DNS المعتمدة',
  'wireless.set_frequency': 'تغيير القناة اللاسلكية المعتمدة',
};
const emergencyStatusNames = {
  'open': 'يحتاج معالجة', 'acknowledged': 'قيد المتابعة', 'resolved': 'زوال العطل مؤكد',
  'alarm': 'العطل مرصود', 'pass': 'قياس التعافي جارٍ', 'unknown': 'النتيجة غير محسومة',
  'preview': 'بانتظار اعتمادك', 'running': 'جارٍ التنفيذ والتحقق', 'verified': 'تأكد تطبيق التغيير',
  'failed': 'القيم السابقة موجودة الآن', 'cancelled': 'أُلغيت المعاينة', 'restoring': 'جارٍ استرجاع القيم',
  'restored': 'تأكدت استعادة القيم', 'restore_unknown': 'الاستعادة غير محسومة',
};
const emergencySourceNames = {
  'resource': 'موارد الراوتر', 'interfaces': 'المنافذ', 'services': 'خدمات الإدارة',
  'ethernet': 'حماية القفلة', 'routes': 'المسار الافتراضي', 'dns': 'إعداد DNS',
  'health': 'الحساسات', 'wireless': 'اللاسلكي التقليدي', 'wifi': 'WiFi',
  'dhcpAlerts': 'بلاغات DHCP', 'arp': 'سجل العناوين', 'clock': 'ساعة الراوتر',
  'logs': 'الأحداث الأمنية', 'probe1': 'اختبار الاتصال الأول', 'probe2': 'اختبار الاتصال الثاني',
  'dnsProbe': 'اختبار اسم النطاق',
  'hotspotActive': 'جلسات Hotspot النشطة', 'hotspotHosts': 'مضيفو Hotspot', 'hotspotUsers': 'عدادات حسابات Hotspot',
};
const emergencyAvailabilityNames = {
  'ok': 'مقروء', 'unsupported': 'غير مدعوم', 'denied': 'الإذن غير متاح',
  'unreachable': 'تعذر الوصول', 'tls_failed': 'تعذر التحقق من الشهادة',
  'invalid': 'رد غير صالح', 'cancelled': 'أُلغي', 'disabled': 'غير مفعّل',
};
const emergencyEventNames = {
  'incident_opened': 'رُصد العطل', 'incident_resolved': 'تأكد زوال العطل بقياسين',
  'incident_acknowledged': 'استلام متابعة العطل', 'repair_previewed': 'حفظ معاينة المعالجة',
  'repair_started': 'اعتماد وبدء المعالجة', 'repair_verified': 'تأكد تطبيق التغيير',
  'repair_unknown': 'تعذر حسم نتيجة المعالجة', 'repair_restore_started': 'اعتماد استعادة القيم',
  'repair_restored': 'تأكدت استعادة القيم', 'repair_restore_unknown': 'تعذر حسم الاستعادة',
  'repair_cancel_requested': 'طلب إيقاف العملية', 'repair_reconciled': 'التحقق من الحالة دون إعادة الكتابة',
};

class EmergencyApi {
  EmergencyApi(this.account);
  final AccountController account;
  Future<Map<String, dynamic>> get(String path, {Map<String, String>? query}) => account.request('GET', '/v1/emergency/$path', query: query);
  Future<Map<String, dynamic>> post(String path, Map<String, dynamic> body) => account.request('POST', '/v1/emergency/$path', body: body);
}
