import 'dart:convert';
import 'dart:math';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'account_api.dart';
import 'account_views.dart';
import 'studio_host.dart';

class CardStudioScreen extends StatefulWidget {
  const CardStudioScreen({super.key, required this.account});
  final AccountController account;
  @override
  State<CardStudioScreen> createState() => _CardStudioScreenState();
}

class _CardStudioScreenState extends State<CardStudioScreen> {
  String? _html, _error;
  late final String _nonce = List.generate(24, (_) => Random.secure().nextInt(256).toRadixString(16).padLeft(2, '0')).join();
  Future<void>? _stepUp;
  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    setState(() { _error = null; });
    try {
      final result = await widget.account.request('GET', '/v1/studio/app');
      final html = result['html'];
      if (html is! String || html.length > 2000000) { throw const AccountFailure('invalid_response', 0); }
      if (mounted) { setState(() => _html = html.replaceAll('__NCP_BRIDGE_NONCE__', _nonce)); }
    } catch (e) { if (mounted) { setState(() => _error = accountError(e)); } }
  }
  Future<void> _confirmIdentity() async {
    final code = TextEditingController();
    try {
      final route = DialogRoute<bool>(context: context, barrierDismissible: false, builder: (ctx) => _StudioMfaDialog(account: widget.account, code: code));
      final ok = await Navigator.of(context, rootNavigator: true).push(route);
      await route.completed;
      if (ok != true) { throw const AccountFailure('action_cancelled', 0); }
    } finally { code.dispose(); }
  }
  Future<Map<String, dynamic>> _dispatch(Map<String, dynamic> message) async {
    final id = message['id'];
    if (message['nonce'] != _nonce || message['kind'] != 'ncp-studio' || id is! String || id.length > 20) { return {'nonce': _nonce, 'id': id, 'error': {'code': 'forbidden'}}; }
    try {
      final args = (message['args'] as Map).cast<String, dynamic>();
      dynamic result;
      switch (message['action']) {
        case 'rpc':
          final action = args['action'];
          if (action is! String || action.length > 60) { throw const AccountFailure('invalid_request', 0); }
          try { result = await widget.account.request('POST', '/v1/studio/rpc', body: args); }
          on AccountFailure catch (e) {
            if (e.code != 'step_up_required') { rethrow; }
            _stepUp ??= _confirmIdentity();
            try { await _stepUp; } finally { _stepUp = null; }
            result = await widget.account.request('POST', '/v1/studio/rpc', body: args);
          }
        case 'host.pickFile':
          final selected = await FilePicker.pickFiles(type: FileType.custom, allowedExtensions: args['accept'] == 'image/png,image/jpeg' ? const ['png', 'jpg', 'jpeg'] : const ['json', 'png', 'jpg', 'jpeg', 'svg'], withData: true);
          final file = selected?.files.single;
          if (file == null) { result = {'cancelled': true}; }
          else {
            if (file.size > 750000 || file.bytes == null) { throw const AccountFailure('invalid_request', 0); }
            result = {'name': file.name, 'base64': base64Encode(file.bytes!)};
          }
        case 'host.file':
          final filename = args['filename'], encoded = args['base64'], kind = args['kind'];
          if (filename is! String || !RegExp(r'^copilot-(?:cards-[a-f0-9-]{36}\.pdf|template\.json)$').hasMatch(filename) || encoded is! String || encoded.length > 34000000 || !['download', 'preview', 'print', 'share'].contains(kind)) { throw const AccountFailure('invalid_request', 0); }
          final bytes = base64Decode(encoded);
          if (filename.endsWith('.pdf') && (bytes.length < 5 || ascii.decode(bytes.sublist(0, 5), allowInvalid: true) != '%PDF-')) { throw const AccountFailure('invalid_response', 0); }
          if (kind == 'download') {
            final path = await FilePicker.saveFile(dialogTitle: 'حفظ الملف', fileName: filename, mimeType: filename.endsWith('.pdf') ? 'application/pdf' : 'application/json', bytes: bytes);
            result = {'saved': path != null};
          } else {
            result = await const MethodChannel('copilot/studio-files').invokeMethod<dynamic>('file', {'filename': filename, 'bytes': bytes, 'kind': kind});
          }
        default:
          throw const AccountFailure('forbidden', 0);
      }
      return {'nonce': _nonce, 'id': id, 'result': result};
    } catch (e) {
      return {'nonce': _nonce, 'id': id, 'error': {'code': e is AccountFailure ? e.code : 'connection_failed'}};
    }
  }
  @override
  Widget build(BuildContext context) {
    if (_error != null) { return Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [Text(_error!, textAlign: TextAlign.center), const SizedBox(height: 16), OutlinedButton(onPressed: _load, child: const Text('إعادة المحاولة'))]))); }
    if (_html == null) { return const Center(child: CircularProgressIndicator()); }
    return studioHost(_html!, _nonce, _dispatch);
  }
}

class _StudioMfaDialog extends StatefulWidget {
  const _StudioMfaDialog({required this.account, required this.code});
  final AccountController account;
  final TextEditingController code;
  @override
  State<_StudioMfaDialog> createState() => _StudioMfaDialogState();
}
class _StudioMfaDialogState extends State<_StudioMfaDialog> {
  bool _busy = false;
  String? _error;
  @override
  Widget build(BuildContext context) => AlertDialog(title: const Text('تأكيد هويتك'), content: Column(mainAxisSize: MainAxisSize.min, children: [if (_error != null) Text(_error!), TextField(controller: widget.code, enabled: !_busy, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'رمز تطبيق المصادقة'), autofocus: true)]), actions: [TextButton(onPressed: _busy ? null : () => Navigator.pop(context, false), child: const Text('إلغاء')), FilledButton(onPressed: _busy ? null : () async {
    setState(() { _busy = true; _error = null; });
    try { await widget.account.stepUp(widget.code.text.trim()); if (context.mounted) { Navigator.pop(context, true); } }
    catch (e) { if (mounted) { setState(() => _error = accountError(e)); } }
    finally { if (mounted) { setState(() => _busy = false); } }
  }, child: Text(_busy ? 'جارٍ التحقق…' : 'تأكيد'))]);
}
