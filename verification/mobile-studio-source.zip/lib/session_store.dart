import 'session_store_web.dart'
    if (dart.library.io) 'session_store_io.dart'
    as platform;

abstract interface class SessionStore {
  Future<String?> read();
  Future<void> write(String value);
  Future<void> clear();
}

SessionStore createSessionStore() => platform.PlatformSessionStore();
