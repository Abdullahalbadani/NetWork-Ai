import 'session_store.dart';

// Deliberately no localStorage, IndexedDB, cookies or plugin web crypto for bearer persistence.
class PlatformSessionStore implements SessionStore {
  String? _value;
  @override
  Future<String?> read() async => _value;
  @override
  Future<void> write(String value) async {
    _value = value;
  }

  @override
  Future<void> clear() async {
    _value = null;
  }
}
