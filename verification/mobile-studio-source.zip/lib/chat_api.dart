import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:http/http.dart' as http;

import 'api.dart';
import 'transport.dart';
import 'session_expiry.dart';

enum ChatRole { user, assistant }

class ChatMessage {
  const ChatMessage(this.role, this.text);
  final ChatRole role;
  final String text;

  Map<String, String> toJson() => {'role': role.name, 'text': text};

  @override
  String toString() => 'ChatMessage(${role.name})';
}

class ChatReply {
  const ChatReply({required this.text, required this.truncated});
  final String text;
  final bool truncated;
}

abstract interface class ChatGateway {
  Future<ChatReply> send(List<ChatMessage> messages);
  void cancel();
  void dispose();
}

final chatGatewayFactoryProvider =
    Provider<ChatGateway Function(LabConnection)>((ref) {
      return (connection) => ChatApi(connection);
    });

class ChatApi implements ChatGateway {
  ChatApi(
    this.connection, {
    http.Client Function()? clientFactory,
    this.timeout = const Duration(seconds: 25),
  }) : _clientFactory = clientFactory ?? createTransport;

  final LabConnection connection;
  final Duration timeout;
  final http.Client Function() _clientFactory;
  http.Client? _active;
  bool _disposed = false;

  @override
  Future<ChatReply> send(List<ChatMessage> messages) async {
    if (_disposed || _active != null) {
      throw const ApiFailure('انتظر اكتمال الطلب الحالي.');
    }
    if (!validEndpoint(connection.endpoint)) {
      throw const ApiFailure('راجع عنوان خادم الإدارة في إعداد الاتصال.');
    }
    final total = messages.fold<int>(0, (sum, item) => sum + item.text.length);
    if (messages.isEmpty ||
        messages.length > 7 ||
        messages.length.isEven ||
        total > 6000 ||
        messages.indexed.any(
          (entry) =>
              entry.$2.role !=
                  (entry.$1.isEven ? ChatRole.user : ChatRole.assistant) ||
              entry.$2.text.trim().isEmpty ||
              entry.$2.text.length > 2000,
        )) {
      throw const ApiFailure('السؤال أو سياق المحادثة يتجاوز الحد المسموح.');
    }
    final client = _clientFactory();
    _active = client;
    try {
      return await _request(client, messages).timeout(timeout);
    } on TimeoutException {
      throw const ApiFailure(
        'انتهت مهلة الرد. يمكنك المحاولة مجددًا؛ لم يُرسل طلب آخر تلقائيًا.',
      );
    } on ApiFailure {
      rethrow;
    } catch (_) {
      throw const ApiFailure('تعذر الاتصال بالخادم. تحقق من تشغيله واتصالك.');
    } finally {
      if (identical(_active, client)) {
        _active = null;
      }
      client.close();
    }
  }

  Future<ChatReply> _request(
    http.Client client,
    List<ChatMessage> messages,
  ) async {
    final uri = Uri.parse(
      connection.endpoint,
    ).replace(pathSegments: ['v1', 'chat']);
    final request = http.Request('POST', uri)
      ..followRedirects = false
      ..headers['Authorization'] = 'Bearer ${connection.token}'
      ..headers['Content-Type'] = 'application/json'
      ..body = jsonEncode({
        'messages': messages.map((message) => message.toJson()).toList(),
      });
    if (connection.workspaceId != null) {
      request.headers['X-Workspace-Id'] = connection.workspaceId!;
    }
    final response = await client.send(request);
    final bytes = BytesBuilder(copy: false);
    await for (final chunk in response.stream) {
      if (bytes.length + chunk.length > 128 * 1024) {
        throw const ApiFailure('حجم استجابة المحادثة أكبر من الحد المسموح.');
      }
      bytes.add(chunk);
    }
    Object? data;
    try {
      data = jsonDecode(utf8.decode(bytes.takeBytes()));
    } catch (_) {
      throw const ApiFailure('وصلت استجابة غير مكتملة من الخادم.');
    }
    if (response.statusCode != 200) {
      final code = data is Map<String, dynamic> ? data['error'] : null;
      if (response.statusCode == 401) {
        if (connection.workspaceId != null) {
          SessionExpiry.report(connection.endpoint, connection.token);
        }
        throw const ApiFailure('انتهت صلاحية رمز الوصول أو أنه غير صحيح.');
      }
      throw ApiFailure(switch (code) {
        'ai_not_configured' =>
          'المساعد غير مهيأ بعد. راجع إعداد Gemini في الخادم.',
        'ai_model_unavailable' =>
          'النموذج المحدد غير متاح للتوليد. راجع اسم النموذج في الخادم.',
        'ai_access_denied' =>
          'رفض Gemini صلاحية الوصول. راجع مفتاح الخادم وقيود مشروع Google.',
        'ai_invalid_request' =>
          'رفض Gemini إعداد الطلب. راجع إعدادات النموذج في الخادم.',
        'ai_rate_limited' =>
          'الخدمة مشغولة أو بلغت حد الطلبات أو الحصة. انتظر ثم أعد الإرسال.',
        'ai_timeout' =>
          'انتهت مهلة الخدمة. يمكنك إعادة المحاولة عندما تكون جاهزًا.',
        'ai_refused' => 'لم تقدم الخدمة إجابة قابلة للعرض. جرّب صياغة أخرى.',
        'invalid_messages' =>
          'تعذر إرسال هذا السياق. ابدأ محادثة جديدة أو اختصر السؤال.',
        _ => 'تعذر إكمال الرد الآن. حاول لاحقًا.',
      });
    }
    if (data is! Map<String, dynamic> ||
        data['source'] != 'gemini' ||
        data['deviceAccess'] != false ||
        data['text'] is! String ||
        (data['text'] as String).trim().isEmpty ||
        (data['text'] as String).length > 16000 ||
        data['truncated'] is! bool) {
      throw const ApiFailure('استجابة المساعد غير مكتملة أو غير صالحة.');
    }
    return ChatReply(
      text: data['text'] as String,
      truncated: data['truncated'] as bool,
    );
  }

  @override
  void cancel() {
    _active?.close();
    _active = null;
  }

  @override
  void dispose() {
    _disposed = true;
    cancel();
  }
}
