import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'account_api.dart';
import 'ui.dart';
import 'workspace.dart';
import 'network_startup.dart';

String accountError(Object error) => error is AccountFailure
    ? error.message
    : 'تعذر إكمال العملية. راجع الاتصال ثم حاول مجددًا.';
Future<String?> pickCertificate() async {
  final result = await FilePicker.pickFiles(
    type: FileType.custom,
    allowedExtensions: ['crt', 'pem', 'cer'],
  );
  if (result.isEmpty) return null;
  final length = await result.single.length();
  if (length == null || length > 12000) {
    throw const AccountFailure('invalid_ca_certificate', 400);
  }
  final bytes = await result.single.readAsBytes();
  if (bytes.length > 12000) {
    throw const AccountFailure('invalid_ca_certificate', 400);
  }
  final value = utf8.decode(bytes);
  if (!value.trim().startsWith('-----BEGIN CERTIFICATE-----') ||
      value.contains('PRIVATE KEY')) {
    throw const AccountFailure('invalid_ca_certificate', 400);
  }
  return value;
}

String certificateFingerprint(String value) {
  final base = value.replaceAll(
    RegExp(r'-----BEGIN CERTIFICATE-----|-----END CERTIFICATE-----|\s'),
    '',
  );
  final hex = sha256.convert(base64Decode(base)).toString().toUpperCase();
  return [
    for (var i = 0; i < hex.length; i += 2) hex.substring(i, i + 2),
  ].join(':');
}

Future<void> exitAccount(
  BuildContext context,
  AccountController account,
) async {
  final messenger = ScaffoldMessenger.maybeOf(context);
  try {
    await account.logout();
  } catch (error) {
    if (error is AccountFailure && error.code == 'operation_cancelled') return;
    if (messenger?.mounted ?? false) {
      messenger!.showSnackBar(
        const SnackBar(
          content: Text(
            'أُغلقت جلسة التطبيق. تعذر تأكيد الإلغاء في الخادم أو مسح التخزين الآمن.',
          ),
        ),
      );
    }
  }
}

class AccountGate extends ConsumerStatefulWidget {
  const AccountGate({
    super.key,
    required this.onTheme,
    required this.deviceBuilder,
  });
  final VoidCallback onTheme;
  final Widget Function(BuildContext, String, String, VoidCallback)
  deviceBuilder;
  @override
  ConsumerState<AccountGate> createState() => _AccountGateState();
}

class _AccountGateState extends ConsumerState<AccountGate>
    with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    Future.microtask(() => ref.read(accountProvider).restore());
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      ref.read(accountProvider).resume();
    } else if (state == AppLifecycleState.paused) {
      ref.read(accountProvider).suspend();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final account = ref.watch(accountProvider);
    if (account.restoring) {
      return const NetworkStartup();
    }
    if (account.restoreError != null) {
      return AccountFrame(
        title: 'تعذر التحقق من الجلسة',
        subtitle: account.restoreError!,
        child: Column(
          children: [
            FilledButton(
              onPressed: account.restore,
              child: const Text('إعادة المحاولة'),
            ),
            TextButton(
              onPressed: account.forget,
              child: const Text('مسح الجلسة والعودة للدخول'),
            ),
          ],
        ),
      );
    }
    if (!account.signedIn) {
      final navigator = Navigator.of(context);
      if (navigator.canPop()) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted && !account.signedIn) {
            navigator.popUntil((route) => route.isFirst);
          }
        });
      }
      return LoginView(account: account, onTheme: widget.onTheme);
    }
    if (account.passwordChangeRequired) {
      return PasswordView(account: account, initial: true);
    }
    if (account.mfaRequired) return EnrollmentView(account: account);
    return Workspace(
      key: ValueKey('${account.profile!['user']['id']}:${account.workspaceId}:${account.role}'),
      account: account,
      onTheme: widget.onTheme,
      deviceBuilder: widget.deviceBuilder,
    );
  }
}

class AccountFrame extends StatelessWidget {
  const AccountFrame({
    super.key,
    required this.title,
    required this.subtitle,
    required this.child,
    this.action,
    this.wideChild,
  });
  final String title, subtitle;
  final Widget child;
  final Widget? action, wideChild;
  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.sizeOf(context).width >= 1050,
        theme = Theme.of(context);
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: EdgeInsets.all(wide ? 40 : 20),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 1160),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.all(wide ? 36 : 22),
                      decoration: BoxDecoration(
                        color: theme.colorScheme.surface,
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(
                          color: theme.colorScheme.outlineVariant,
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Row(
                            children: [
                              const BrandMark(size: 44),
                              const SizedBox(width: 12),
                              const Expanded(
                                child: Text(
                                  'مساعد الشبكة',
                                  style: TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              ?action,
                            ],
                          ),
                          const SizedBox(height: 30),
                          Text(
                            title,
                            style: theme.textTheme.headlineSmall?.copyWith(
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            subtitle,
                            style: TextStyle(
                              color: theme.colorScheme.onSurfaceVariant,
                              height: 1.6,
                            ),
                          ),
                          const SizedBox(height: 26),
                          Material(
                            type: MaterialType.transparency,
                            child: child,
                          ),
                        ],
                      ),
                    ),
                  ),
                  if (wide && wideChild != null) ...[
                    const SizedBox(width: 64),
                    Expanded(child: wideChild!),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

Widget errorBox(String? message) => message == null
    ? const SizedBox.shrink()
    : Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Semantics(
          liveRegion: true,
          child: Text(
            message,
            style: const TextStyle(color: Color(0xffd56868), height: 1.5),
          ),
        ),
      );

class LoginView extends StatefulWidget {
  const LoginView({super.key, required this.account, required this.onTheme});
  final AccountController account;
  final VoidCallback onTheme;
  @override
  State<LoginView> createState() => _LoginViewState();
}

class _LoginViewState extends State<LoginView> {
  final _form = GlobalKey<FormState>();
  late final _endpoint = TextEditingController(text: widget.account.endpoint);
  final _email = TextEditingController(),
      _password = TextEditingController(),
      _code = TextEditingController();
  bool _busy = false, _backup = false, _visible = false;
  String? _error, _challenge, _fingerprint;
  Future<void> _run(Future<void> Function() action) async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await action();
    } catch (e) {
      if (mounted) setState(() => _error = accountError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    await _run(() async {
      if (_challenge != null) {
        await widget.account.verify(_challenge!, _code.text.trim(), _backup);
      } else {
        widget.account.setEndpoint(_endpoint.text.trim());
        final result = await widget.account.login(
          _email.text.trim(),
          _password.text,
        );
        if (mounted) {
          _password.clear();
          if (result['challengeId'] is String) {
            setState(() => _challenge = result['challengeId'] as String);
          }
        }
      }
    });
  }

  @override
  void dispose() {
    _endpoint.dispose();
    _email.dispose();
    _password.dispose();
    _code.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AccountFrame(
    title: _challenge == null ? 'أهلًا بعودتك' : 'تأكيد هويتك',
    subtitle: _challenge == null
        ? 'سجّل الدخول إلى مساحة عملك لإدارة المواقع والأجهزة ومتابعة القراءات.'
        : 'أدخل رمز تطبيق المصادقة. يمكنك استخدام أحد رموز الاستعادة المحفوظة لديك.',
    action: IconButton(
      onPressed: widget.onTheme,
      tooltip: 'تبديل المظهر',
      icon: const Icon(Icons.contrast),
    ),
    wideChild: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(
          Icons.account_tree_outlined,
          size: 76,
          color: Theme.of(context).colorScheme.primary,
        ),
        const SizedBox(height: 28),
        const Text(
          'كل موقع. كل جهاز.\nمساحة واضحة للعمل.',
          style: TextStyle(
            fontSize: 38,
            fontWeight: FontWeight.w700,
            height: 1.45,
          ),
        ),
        const SizedBox(height: 22),
        const Text(
          'قراءات موثقة بوقتها، وصول حسب مسؤوليتك، ومساعد يشرح لك ما تحتاجه.',
          style: TextStyle(fontSize: 17, height: 1.8),
        ),
        const SizedBox(height: 30),
        const Wrap(
          spacing: 12,
          runSpacing: 12,
          children: [
            Chip(label: Text('صلاحيات محددة')),
            Chip(label: Text('جلسات قابلة للإلغاء')),
            Chip(label: Text('قراءة الراوتر')),
          ],
        ),
      ],
    ),
    child: Form(
      key: _form,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          errorBox(_error),
          if (_challenge == null) ...[
            TextFormField(
              key: const Key('account-endpoint'),
              controller: _endpoint,
              enabled: !_busy,
              textDirection: TextDirection.ltr,
              keyboardType: TextInputType.url,
              decoration: const InputDecoration(
                labelText: 'عنوان الخادم',
                prefixIcon: Icon(Icons.dns_outlined),
              ),
              validator: (s) =>
                  s?.startsWith('https://') == true ? null : 'استخدم HTTPS.',
            ),
            const SizedBox(height: 18),
            TextFormField(
              key: const Key('account-email'),
              controller: _email,
              enabled: !_busy,
              textDirection: TextDirection.ltr,
              keyboardType: TextInputType.emailAddress,
              autofillHints: const [AutofillHints.username],
              decoration: const InputDecoration(
                labelText: 'الحساب',
                prefixIcon: Icon(Icons.person_outline),
              ),
              validator: (s) =>
                  s != null && s.contains('@') ? null : 'أدخل حسابك.',
            ),
            const SizedBox(height: 18),
            TextFormField(
              key: const Key('account-password'),
              controller: _password,
              enabled: !_busy,
              obscureText: !_visible,
              autocorrect: false,
              enableSuggestions: false,
              autofillHints: const [AutofillHints.password],
              decoration: InputDecoration(
                labelText: 'كلمة المرور',
                prefixIcon: const Icon(Icons.lock_outline),
                suffixIcon: IconButton(
                  tooltip: _visible ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور',
                  onPressed: () => setState(() => _visible = !_visible),
                  icon: Icon(
                    _visible
                        ? Icons.visibility_off_outlined
                        : Icons.visibility_outlined,
                  ),
                ),
              ),
              validator: (s) =>
                  s?.isNotEmpty == true ? null : 'أدخل كلمة المرور.',
            ),
            if (kDebugMode && !kIsWeb) ...[
              const SizedBox(height: 16),
              OutlinedButton.icon(
                onPressed: _busy
                    ? null
                    : () => _run(() async {
                        widget.account.setEndpoint(_endpoint.text.trim());
                        final cert = await pickCertificate();
                        if (cert == null) return;
                        widget.account.setCertificate(cert);
                        setState(
                          () => _fingerprint = certificateFingerprint(cert),
                        );
                      }),
                icon: const Icon(Icons.verified_user_outlined),
                label: Text(
                  widget.account.certificate == null
                      ? 'اختيار شهادة المختبر'
                      : 'تغيير شهادة المختبر',
                ),
              ),
              if (_fingerprint != null)
                SelectableText(
                  'SHA256: $_fingerprint',
                  textDirection: TextDirection.ltr,
                  style: const TextStyle(fontSize: 11),
                ),
            ],
          ] else ...[
            TextFormField(
              key: const Key('account-otp'),
              controller: _code,
              enabled: !_busy,
              textDirection: TextDirection.ltr,
              autocorrect: false,
              enableSuggestions: false,
              keyboardType: _backup ? TextInputType.text : TextInputType.number,
              autofillHints: const [AutofillHints.oneTimeCode],
              decoration: InputDecoration(
                labelText: _backup ? 'رمز استعادة' : 'رمز المصادقة',
                prefixIcon: const Icon(Icons.password),
              ),
              validator: (s) =>
                  s?.trim().isNotEmpty == true ? null : 'أدخل الرمز.',
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('استخدام رمز استعادة'),
              value: _backup,
              onChanged: _busy
                  ? null
                  : (v) => setState(() {
                      _backup = v;
                      _code.clear();
                    }),
            ),
          ],
          const SizedBox(height: 24),
          FilledButton.icon(
            key: const Key('account-submit'),
            onPressed: _busy ? null : _submit,
            icon: _busy
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.login),
            label: Text(_challenge == null ? 'تسجيل الدخول' : 'تحقق وتابع'),
          ),
          if (_challenge != null)
            TextButton(
              onPressed: _busy
                  ? null
                  : () => setState(() {
                      _challenge = null;
                      _code.clear();
                      _error = null;
                    }),
              child: const Text('العودة إلى تسجيل الدخول'),
            ),
          const SizedBox(height: 20),
          Text(
            kIsWeb
                ? 'جلسة المتصفح مؤقتة. لا يُحفظ رمز الدخول بعد إعادة تحميل الصفحة.'
                : 'تُحفظ الجلسة في مخزن النظام الآمن. لا تُحفظ كلمة مرورك.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
          const SizedBox(height: 10),
          const Text(
            'حسابات الوصول ينشئها مالك مساحة العمل.',
            style: TextStyle(fontSize: 12),
          ),
        ],
      ),
    ),
  );
}

class EnrollmentView extends StatefulWidget {
  const EnrollmentView({super.key, required this.account});
  final AccountController account;
  @override
  State<EnrollmentView> createState() => _EnrollmentViewState();
}

class _EnrollmentViewState extends State<EnrollmentView> {
  final _password = TextEditingController(), _code = TextEditingController();
  Map<String, dynamic>? _setup;
  String? _error;
  bool _busy = false, _saved = false;
  Future<void> _act(Future<void> Function() action) async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await action();
    } catch (e) {
      if (mounted) setState(() => _error = accountError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  void dispose() {
    _password.dispose();
    _code.dispose();
    _setup = null;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AccountFrame(
    title: 'حماية حسابك',
    subtitle:
        'اربط تطبيق مصادقة مثل Google Authenticator. احتفظ برموز الاستعادة في مكان خاص خارج هذا التطبيق.',
    action: IconButton(
      tooltip: 'خروج',
      onPressed: () => exitAccount(context, widget.account),
      icon: const Icon(Icons.logout),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        errorBox(_error),
        if (_setup == null) ...[
          TextField(
            key: const Key('enroll-password'),
            controller: _password,
            obscureText: true,
            autocorrect: false,
            enableSuggestions: false,
            decoration: const InputDecoration(
              labelText: 'أكد كلمة مرور الحساب',
            ),
          ),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: _busy
                ? null
                : () => _act(() async {
                    final result = await widget.account.request(
                      'POST',
                      '/v1/auth/mfa/enroll',
                      body: {'password': _password.text},
                    );
                    if (mounted) {
                      _password.clear();
                      setState(() => _setup = result);
                    }
                  }),
            child: Text(_busy ? 'جارٍ الإعداد…' : 'إعداد تطبيق المصادقة'),
          ),
        ] else ...[
          Center(
            child: Container(
              color: Colors.white,
              padding: const EdgeInsets.all(14),
              child: QrImageView(data: _setup!['totpURI'] as String, size: 200),
            ),
          ),
          const SizedBox(height: 14),
          const Text(
            'امسح الرمز، أو أدخل هذا المفتاح يدويًا في تطبيق المصادقة:',
          ),
          SelectableText(
            Uri.parse(_setup!['totpURI'] as String).queryParameters['secret'] ??
                '',
            textDirection: TextDirection.ltr,
            style: const TextStyle(fontFamily: 'JetBrainsMono', fontSize: 13),
          ),
          const SizedBox(height: 22),
          const Text(
            'رموز الاستعادة — كل رمز يُستخدم مرة واحدة',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          SelectableText(
            (_setup!['backupCodes'] as List).join('   '),
            textDirection: TextDirection.ltr,
            style: const TextStyle(fontFamily: 'JetBrainsMono', height: 2),
          ),
          CheckboxListTile(
            key: const Key('recovery-saved'),
            contentPadding: EdgeInsets.zero,
            value: _saved,
            onChanged: _busy
                ? null
                : (v) => setState(() => _saved = v ?? false),
            title: const Text('حفظت رموز الاستعادة في مكان خاص.'),
          ),
          TextField(
            key: const Key('enroll-code'),
            controller: _code,
            keyboardType: TextInputType.number,
            textDirection: TextDirection.ltr,
            autocorrect: false,
            enableSuggestions: false,
            decoration: const InputDecoration(
              labelText: 'رمز تطبيق المصادقة الآن',
            ),
          ),
          const SizedBox(height: 18),
          FilledButton(
            key: const Key('enroll-confirm'),
            onPressed: _busy || !_saved
                ? null
                : () => _act(
                    () => widget.account.confirmEnrollment(_code.text.trim()),
                  ),
            child: Text(_busy ? 'جارٍ التحقق…' : 'تفعيل والمتابعة'),
          ),
        ],
      ],
    ),
  );
}

class PasswordView extends StatefulWidget {
  const PasswordView({super.key, required this.account, this.initial = false});
  final AccountController account;
  final bool initial;
  @override
  State<PasswordView> createState() => _PasswordViewState();
}

class _PasswordViewState extends State<PasswordView> {
  final _form = GlobalKey<FormState>(),
      _old = TextEditingController(),
      _next = TextEditingController(),
      _confirm = TextEditingController();
  bool _busy = false;
  String? _error;
  @override
  void dispose() {
    _old.dispose();
    _next.dispose();
    _confirm.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AccountFrame(
    title: widget.initial ? 'كلمة مرورك الخاصة' : 'تغيير كلمة المرور',
    subtitle:
        'اختر كلمة مرور من 14 حرفًا أو أكثر. تُلغى الجلسات الأخرى بعد نجاح التغيير.',
    child: Form(
      key: _form,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          errorBox(_error),
          TextFormField(
            key: const Key('password-current'),
            controller: _old,
            obscureText: true,
            autocorrect: false,
            enableSuggestions: false,
            decoration: const InputDecoration(labelText: 'كلمة المرور الحالية'),
            validator: (s) =>
                s?.isNotEmpty == true ? null : 'أدخل كلمة المرور الحالية.',
          ),
          const SizedBox(height: 18),
          TextFormField(
            key: const Key('password-new'),
            controller: _next,
            obscureText: true,
            autocorrect: false,
            enableSuggestions: false,
            decoration: const InputDecoration(labelText: 'كلمة المرور الجديدة'),
            validator: (s) =>
                (s?.length ?? 0) >= 14 ? null : 'استخدم 14 حرفًا على الأقل.',
          ),
          const SizedBox(height: 18),
          TextFormField(
            controller: _confirm,
            obscureText: true,
            autocorrect: false,
            enableSuggestions: false,
            decoration: const InputDecoration(
              labelText: 'تأكيد كلمة المرور الجديدة',
            ),
            validator: (s) =>
                s == _next.text ? null : 'كلمتا المرور غير متطابقتين.',
          ),
          const SizedBox(height: 24),
          FilledButton(
            onPressed: _busy
                ? null
                : () async {
                    if (!_form.currentState!.validate()) return;
                    setState(() {
                      _busy = true;
                      _error = null;
                    });
                    try {
                      await widget.account.changePassword(
                        _old.text,
                        _next.text,
                      );
                      if (context.mounted && !widget.initial) {
                        Navigator.pop(context);
                      }
                    } catch (e) {
                      if (mounted) setState(() => _error = accountError(e));
                    } finally {
                      if (mounted) setState(() => _busy = false);
                    }
                  },
            child: Text(_busy ? 'جارٍ التغيير…' : 'حفظ كلمة المرور'),
          ),
          if (widget.initial)
            TextButton(
              onPressed: () => exitAccount(context, widget.account),
              child: const Text('تسجيل الخروج'),
            ),
        ],
      ),
    ),
  );
}
