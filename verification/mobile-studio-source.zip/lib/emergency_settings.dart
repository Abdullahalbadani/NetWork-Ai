import 'package:flutter/material.dart';
import 'account_api.dart';
import 'account_views.dart';
import 'emergency_api.dart';
import 'emergency_common.dart';

class EmergencySettings extends StatefulWidget {
  const EmergencySettings({super.key, required this.account, required this.device});
  final AccountController account;
  final Map<String, dynamic> device;
  @override
  State<EmergencySettings> createState() => _EmergencySettingsState();
}
class _EmergencySettingsState extends State<EmergencySettings> {
  late final api = EmergencyApi(widget.account);
  late Map<String, dynamic> policy = Map<String, dynamic>.from(emergencyMap(widget.device['policy']));
  late Map<String, dynamic> thresholds = Map<String, dynamic>.from(emergencyMap(policy['thresholds']));
  late bool enabled = widget.device['monitoring'] == true;
  late int monitorVersion = widget.device['version'] as int? ?? 0;
  bool busy = false, loading = true, grantEnabled = false;
  int grantVersion = 0, profileVersion = 0;
  String? error;
  List<Map<String, dynamic>> interfaces = [], links = [];
  final Set<String> protected = {}, repair = {}, management = {}, actions = {};
  final username = TextEditingController(), password = TextEditingController(), dns = TextEditingController(text: '1.1.1.1,9.9.9.9'), channels = TextEditingController();
  String? radio;
  final Map<String, List<int>> approvedChannels = {};
  final _form = GlobalKey<FormState>();
  @override
  void initState() { super.initState(); _load(); }
  @override
  void dispose() { username.dispose(); password.dispose(); dns.dispose(); channels.dispose(); super.dispose(); }
  Future<void> _load() async {
    setState(() { loading = true; error = null; });
    try {
      final data = await Future.wait([
        api.get('devices/${widget.device['id']}/write-grant'),
        widget.account.request('GET', '/v1/devices/${widget.device['id']}/health-profile'),
        widget.account.request('GET', '/v1/devices/${widget.device['id']}/interfaces'),
      ]);
      if (!mounted) return;
      final grant = emergencyMap(data[0]['grant']), p = emergencyMap(grant['policy']), profile = emergencyMap(data[1]['profile']);
      setState(() {
        interfaces = emergencyRows(data[2]['items']); links = emergencyRows(profile['links']); profileVersion = profile['version'] as int? ?? 0;
        management.clear(); protected.clear(); repair.clear(); actions.clear(); approvedChannels.clear();
        management.addAll(links.where((v) => v['role'] == 'management').map((v) => '${v['name']}'));
        protected.addAll((p['protectedInterfaces'] as List? ?? management.toList()).map((v) => '$v'));
        repair.addAll((p['repairInterfaces'] as List? ?? []).map((v) => '$v'));
        actions.addAll((p['allowedActions'] as List? ?? ['service.disable_plain']).map((v) => '$v'));
        for (final row in emergencyRows(p['radioChannels'])) { approvedChannels['${row['interface']}'] = (row['frequencies'] as List).cast<int>(); }
        username.text = grant['username'] as String? ?? ''; dns.text = (p['dnsServers'] as List? ?? ['1.1.1.1','9.9.9.9']).join(',');
        grantEnabled = grant['enabled'] == true; grantVersion = grant['version'] as int? ?? 0; loading = false;
      });
    } catch (e) { if (mounted) setState(() { error = accountError(e); loading = false; }); }
  }
  Future<void> _act(Future<void> Function() task) async {
    if (busy) return; setState(() { busy = true; error = null; });
    try { await task(); if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('حُفظت الإعدادات.'))); }
    catch (e) { if (mounted) setState(() => error = accountError(e)); }
    finally { if (mounted) setState(() => busy = false); }
  }
  Future<void> _saveMonitor() async {
    if (!_form.currentState!.validate()) return;
    await _act(() async {
    final result = await emergencyMutation(context, widget.account, () => api.post('devices/${widget.device['id']}/monitor', {'enabled': enabled, 'policy': {...policy, 'thresholds': thresholds}, 'version': monitorVersion}));
    if (mounted) setState(() => monitorVersion = result['version'] as int);
    });
  }
  Future<void> _saveGrant() => _act(() async {
    if (management.isEmpty || !management.every(protected.contains) || protected.intersection(repair).isNotEmpty || actions.isEmpty || username.text.trim().isEmpty || password.text.length < 14) {
      throw const AccountFailure('repair_settings_incomplete', 400);
    }
    final nextLinks = <Map<String, dynamic>>[for (final name in {...links.map((v) => '${v['name']}'), ...management}) {
      'name': name,
      'role': management.contains(name) ? 'management' : links.where((v) => v['name'] == name).firstOrNull?['role'] == 'management' ? 'other' : links.where((v) => v['name'] == name).firstOrNull?['role'] ?? 'other',
      'required': management.contains(name) || links.where((v) => v['name'] == name).firstOrNull?['required'] == true,
    }];
    final profile = await emergencyMutation(context, widget.account, () => widget.account.request('PATCH', '/v1/devices/${widget.device['id']}/health-profile', body: {'version': profileVersion, 'links': nextLinks}));
    if (!mounted) return; profileVersion = emergencyMap(profile['profile'])['version'] as int; links = nextLinks;
    final result = await emergencyMutation(context, widget.account, () => api.post('devices/${widget.device['id']}/write-grant', {
      'version': grantVersion, 'username': username.text.trim(), 'password': password.text,
      'policy': {'allowedActions': actions.toList(), 'protectedInterfaces': protected.toList(), 'repairInterfaces': repair.toList(), 'dnsServers': dns.text.split(',').map((v) => v.trim()).where((v) => v.isNotEmpty).toList(), 'radioChannels': [for (final item in approvedChannels.entries) {'interface': item.key, 'frequencies': item.value}]},
    }));
    if (mounted) setState(() { grantVersion = result['version'] as int; grantEnabled = true; password.clear(); });
  });
  Widget _threshold(String key, String label, {bool optional = false}) => Padding(padding: const EdgeInsets.only(bottom: 14), child: TextFormField(
    initialValue: thresholds[key]?.toString() ?? '', keyboardType: const TextInputType.numberWithOptions(decimal: true), textDirection: TextDirection.ltr, enabled: !busy,
    decoration: InputDecoration(labelText: label, helperText: optional ? 'اتركه فارغًا إن لم تعتمد حدًا لهذا الطراز.' : null),
    validator: (value) => optional && (value?.isEmpty ?? true) ? null : double.tryParse(value ?? '') == null ? 'أدخل رقمًا صالحًا.' : null,
    onChanged: (v) => thresholds[key] = v.isEmpty && optional ? null : num.tryParse(v),
  ));
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('إعداد الرادار · ${widget.device['name']}', maxLines: 1, overflow: TextOverflow.ellipsis)),
    body: loading ? const Center(child: CircularProgressIndicator()) : SingleChildScrollView(padding: const EdgeInsets.all(18), child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 850), child: Form(key: _form, child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      if (error != null) ...[emergencyMessage(context, error!, error: true, retry: _load), const SizedBox(height: 16)],
      emergencyCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text('المراقبة والكشف', style: Theme.of(context).textTheme.titleLarge),
        SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('مراقبة مستمرة من الخادم'), subtitle: const Text('تستمر عند إغلاق الهاتف ما دام الخادم ومسار الوصول للراوتر يعملان.'), value: enabled, onChanged: busy ? null : (v) => setState(() => enabled = v)),
        const SizedBox(height: 12), DropdownButtonFormField<int>(initialValue: policy['intervalSeconds'] as int? ?? 120, isExpanded: true, decoration: const InputDecoration(labelText: 'الفاصل بين القياسات'), items: {60,120,300,600,1800,policy['intervalSeconds'] as int? ?? 120}.map((v) => DropdownMenuItem(value: v, child: Text('$v ثانية'))).toList(), onChanged: busy ? null : (v) => policy['intervalSeconds'] = v),
        SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('اختبارات اتصال من الراوتر'), subtitle: const Text('ثلاث حزم لكل وجهة ثابتة. تحتاج إذن test، ولا تقيس سرعة الإنترنت.'), value: policy['probesEnabled'] == true, onChanged: busy ? null : (v) => setState(() => policy['probesEnabled'] = v)),
        SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('رصد أحداث الدخول الأمنية'), subtitle: const Text('نقرأ الأحداث الحديثة والساعة؛ لا نحفظ الرسائل الخام أو أسماء أصحابها.'), value: policy['securityLogsEnabled'] == true, onChanged: busy ? null : (v) => setState(() => policy['securityLogsEnabled'] = v)),
        SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('إحصائيات المتصلين وتفعيل الكروت'), subtitle: const Text('ثلاث قراءات Hotspot إضافية لكل دورة. تُحفظ معرفات الحسابات ببصمة سرية، وتُحسب قيمة أول استخدام المثبت بأسعار الكروت المعروفة بالريال اليمني؛ لا يُفترض تاريخ تفعيل قديم أو تحصيل ثمن.'), value: policy['clientsEnabled'] == true, onChanged: busy ? null : (v) => setState(() => policy['clientsEnabled'] = v)),
        const SizedBox(height: 12), ExpansionTile(title: const Text('حدود الإنذار حسب جهازك'), tilePadding: EdgeInsets.zero, children: [
          _threshold('cpuWarning','إنذار المعالج %'), _threshold('cpuHigh','حمل المعالج المرتفع %'),
          _threshold('freeMemoryWarning','إنذار الذاكرة المتاحة %'), _threshold('freeMemoryHigh','الحد الحرج للذاكرة المتاحة %'),
          _threshold('freeStorageWarning','إنذار التخزين المتاح %'), _threshold('freeStorageHigh','الحد الحرج للتخزين المتاح %'),
          _threshold('temperatureWarning','إنذار الحرارة °C'), _threshold('temperatureHigh','الحرارة الحرجة °C'), _threshold('minimumVoltage','أدنى جهد مقبول V',optional: true),
          _threshold('minimumSignal','حد الإشارة dBm'), _threshold('minimumCcq','حد CCQ %'),
        ]),
        const SizedBox(height: 16), FilledButton.icon(onPressed: busy ? null : _saveMonitor, icon: const Icon(Icons.radar), label: const Text('حفظ إعداد المراقبة')),
      ])),
      const SizedBox(height: 18), emergencyCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text('صلاحية المعالجة على الراوتر', style: Theme.of(context).textTheme.titleLarge), const SizedBox(height: 8),
        EmergencyBadge(grantEnabled ? 'حساب المعالجة مفعّل' : 'حساب المعالجة غير مفعّل', state: grantEnabled ? 'verified' : 'unknown'), const SizedBox(height: 12),
        const Text('حساب RouterOS مستقل عن حساب القراءة. كل تغيير يحتاج معاينة واعتمادًا منفصلًا. اختر مسار الإدارة السلكي واحمه قبل إتاحة تعديل المنافذ أو الراديو.'),
        const SizedBox(height: 16),
        if (interfaces.isEmpty) const Text('لم تظهر منافذ مقروءة. تحقق من اتصال الجهاز قبل اعتماد صلاحيات المعالجة.'),
        for (final i in interfaces) ...[
          Text('${i['name']}', style: const TextStyle(fontWeight: FontWeight.bold)),
          Wrap(spacing: 8, runSpacing: 6, children: [
            FilterChip(label: const Text('مسار إدارة'), selected: management.contains(i['name']), onSelected: busy ? null : (v) => setState(() { final name = '${i['name']}'; if (v) { management.add(name); protected.add(name); repair.remove(name); approvedChannels.remove(name); if (radio == name) radio = null; } else { management.remove(name); } })),
            FilterChip(label: const Text('محمي من التغيير'), selected: protected.contains(i['name']), onSelected: busy || management.contains(i['name']) ? null : (v) => setState(() { final name = '${i['name']}'; if (v) { protected.add(name); repair.remove(name); approvedChannels.remove(name); if (radio == name) radio = null; } else { protected.remove(name); } })),
            FilterChip(label: const Text('يمكن تفعيله أو عزله'), selected: repair.contains(i['name']), onSelected: busy || protected.contains(i['name']) ? null : (v) => setState(() => v ? repair.add('${i['name']}') : repair.remove('${i['name']}'))),
          ]), const Divider(height: 24),
        ],
        for (final entry in emergencyRepairNames.entries) CheckboxListTile(contentPadding: EdgeInsets.zero, title: Text(entry.value), value: actions.contains(entry.key), onChanged: busy ? null : (v) => setState(() => v == true ? actions.add(entry.key) : actions.remove(entry.key))),
        const SizedBox(height: 12), TextField(controller: dns, enabled: !busy, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'خوادم DNS المعتمدة، بفاصلة', helperText: 'عناوين IPv4 عامة. راجع اعتماد الشبكة على أسماء داخلية.')),
        const SizedBox(height: 16), ExpansionTile(tilePadding: EdgeInsets.zero, title: const Text('قنوات لاسلكية تعتمدها لهذا الموقع'), children: [
          const Text('اعتمد التردد المسموح حسب البلد والطراز. لا يفترض الرادار وجود مسح طيف أو قناة خالية من التشويش.'), const SizedBox(height: 12),
          DropdownButtonFormField<String>(initialValue: radio, isExpanded: true, decoration: const InputDecoration(labelText: 'اسم الراديو'), items: interfaces.where((i) => ['wlan','wifi'].contains(i['type']) && !protected.contains(i['name'])).map((i) => DropdownMenuItem(value: '${i['name']}', child: Text('${i['name']}'))).toList(), onChanged: busy ? null : (v) => setState(() { radio = v; channels.text = (approvedChannels[v] ?? []).join(','); })),
          const SizedBox(height: 12), TextField(controller: channels, enabled: !busy, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'ترددات MHz معتمدة بفاصلة')),
          TextButton.icon(onPressed: busy ? null : () { final values = channels.text.split(',').map((v) => int.tryParse(v.trim())).toList(); if (radio == null || values.any((v) => v == null || v < 2300 || v > 7125)) { setState(() => error = 'اختر راديو وترددات صحيحة.'); return; } setState(() { approvedChannels[radio!] = values.cast<int>().toSet().toList(); }); }, icon: const Icon(Icons.add), label: const Text('حفظ قائمة هذا الراديو')),
          for (final e in approvedChannels.entries) ListTile(contentPadding: EdgeInsets.zero, title: Text(e.key), subtitle: Text(e.value.join('، ')), trailing: IconButton(tooltip: 'حذف اعتماد القنوات', onPressed: busy ? null : () => setState(() => approvedChannels.remove(e.key)), icon: const Icon(Icons.delete_outline))),
        ]),
        const SizedBox(height: 16), TextField(controller: username, enabled: !busy, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'اسم حساب RouterOS للمعالجة')),
        const SizedBox(height: 16), TextField(controller: password, enabled: !busy, obscureText: true, enableSuggestions: false, autocorrect: false, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'كلمة مرور حساب المعالجة', helperText: '14 حرفًا على الأقل؛ تُشفّر في الخادم ولا تُعاد للواجهة.')),
        const SizedBox(height: 18), FilledButton.icon(onPressed: busy || interfaces.isEmpty ? null : _saveGrant, icon: const Icon(Icons.verified_user_outlined), label: const Text('التحقق من الحساب وحفظ الصلاحية')),
        if (grantEnabled) TextButton(onPressed: busy ? null : () => _act(() async { final r = await emergencyMutation(context, widget.account, () => api.post('devices/${widget.device['id']}/disable-write-grant', {'version': grantVersion})); if (mounted) setState(() { grantVersion = r['version'] as int; grantEnabled = false; }); }), child: const Text('إيقاف حساب المعالجة في التطبيق')),
        if (busy) const Padding(padding: EdgeInsets.all(12), child: LinearProgressIndicator()),
      ])),
    ]))))),
  );
}
