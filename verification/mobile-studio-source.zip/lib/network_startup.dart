import 'dart:math' as math;
import 'package:flutter/material.dart';

const startupBackground = Color(0xFF040812);

/// One continuous branded startup. Its lifetime is controlled by real restore work.
class NetworkStartup extends StatefulWidget {
  const NetworkStartup({super.key});
  @override
  State<NetworkStartup> createState() => _NetworkStartupState();
}

class _NetworkStartupState extends State<NetworkStartup>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late final AnimationController _motion = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 4),
  );
  bool _resumed = true;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  void _sync() {
    final reduce =
        MediaQuery.disableAnimationsOf(context) ||
        MediaQuery.accessibleNavigationOf(context);
    if (!reduce && _resumed && TickerMode.valuesOf(context).enabled) {
      if (!_motion.isAnimating) _motion.repeat();
    } else {
      _motion.stop();
      _motion.value = 0;
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _sync();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    _resumed = state == AppLifecycleState.resumed;
    if (mounted) _sync();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _motion.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: startupBackground,
    body: Semantics(
      label: 'جارٍ تهيئة مساعد الشبكة',
      child: LayoutBuilder(
        builder: (context, box) => Stack(
          fit: StackFit.expand,
          children: [
            RepaintBoundary(
              child: CustomPaint(painter: NetworkThreads(_motion)),
            ),
            const Center(
              child: SizedBox(
                width: 96,
                height: 96,
                child: CustomPaint(painter: StartupEmblem()),
              ),
            ),
            Positioned(
              top: box.maxHeight / 2 + 75,
              left: 24,
              right: 24,
              child: const Column(
                children: [
                  Text(
                    'مساعد الشبكة',
                    style: TextStyle(
                      color: Color(0xFFF1F5F9),
                      fontSize: 27,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  SizedBox(height: 9),
                  Text(
                    'NETWORK COPILOT',
                    textDirection: TextDirection.ltr,
                    style: TextStyle(
                      color: Color(0xFF7DD3FC),
                      fontSize: 10,
                      letterSpacing: 3,
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              bottom: 42 + MediaQuery.paddingOf(context).bottom,
              left: 24,
              right: 24,
              child: const Text(
                'جارٍ تهيئة مساحة العمل…',
                textAlign: TextAlign.center,
                style: TextStyle(color: Color(0xFFB5C3D8), fontSize: 14),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

class StartupEmblem extends CustomPainter {
  const StartupEmblem();
  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 96, size.height / 96);
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        const Rect.fromLTWH(0, 0, 96, 96),
        const Radius.circular(26),
      ),
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [Color(0xFF0EA5E9), Color(0xFF0369A1)],
        ).createShader(const Rect.fromLTWH(0, 0, 96, 96)),
    );
    final ink = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4
      ..strokeCap = StrokeCap.round;
    for (final radius in [29.0, 19.0, 9.0]) {
      canvas.drawArc(
        Rect.fromCircle(center: const Offset(48, 61), radius: radius),
        math.pi * 1.23,
        math.pi * .54,
        false,
        ink,
      );
    }
    canvas.drawCircle(const Offset(48, 65), 3.5, Paint()..color = Colors.white);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant StartupEmblem oldDelegate) => false;
}

class NetworkThreads extends CustomPainter {
  NetworkThreads(this.phase) : super(repaint: phase);
  final Animation<double> phase;
  static const points = [
    Offset(.06, .23),
    Offset(.22, .14),
    Offset(.36, .26),
    Offset(.12, .47),
    Offset(.29, .55),
    Offset(.08, .74),
    Offset(.26, .83),
    Offset(.41, .72),
    Offset(.64, .17),
    Offset(.83, .12),
    Offset(.94, .35),
    Offset(.74, .40),
    Offset(.91, .64),
    Offset(.69, .67),
    Offset(.79, .84),
    Offset(.53, .87),
  ];
  static const edges = [
    (0, 1),
    (1, 2),
    (0, 3),
    (2, 4),
    (3, 4),
    (3, 5),
    (4, 6),
    (5, 6),
    (6, 7),
    (8, 9),
    (8, 11),
    (9, 10),
    (10, 11),
    (11, 12),
    (11, 13),
    (12, 14),
    (13, 14),
    (13, 15),
    (14, 15),
  ];
  @override
  void paint(Canvas canvas, Size size) {
    Offset p(int i) =>
        Offset(points[i].dx * size.width, points[i].dy * size.height);
    final line = Paint()
      ..strokeWidth = 1
      ..color = const Color(0xFF0EA5E9).withValues(alpha: .16);
    for (final edge in edges) {
      canvas.drawLine(p(edge.$1), p(edge.$2), line);
    }
    for (var i = 0; i < points.length; i++) {
      canvas.drawCircle(
        p(i),
        i.isEven ? 3 : 2,
        Paint()..color = const Color(0xFF38BDF8).withValues(alpha: .5),
      );
    }
    for (var i = 0; i < edges.length; i += 3) {
      final edge = edges[i], t = (phase.value + i * .11) % 1;
      canvas.drawCircle(
        Offset.lerp(p(edge.$1), p(edge.$2), t)!,
        2.5,
        Paint()..color = const Color(0xFF7DD3FC).withValues(alpha: .7),
      );
    }
    final center = Offset(size.width / 2, size.height / 2);
    for (var i = 0; i < 3; i++) {
      final t = (phase.value + i / 3) % 1;
      canvas.drawCircle(
        center,
        73 + t * 80,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1
          ..color = const Color(0xFF38BDF8).withValues(alpha: (1 - t) * .16),
      );
    }
  }

  @override
  bool shouldRepaint(covariant NetworkThreads oldDelegate) =>
      oldDelegate.phase != phase;
}
