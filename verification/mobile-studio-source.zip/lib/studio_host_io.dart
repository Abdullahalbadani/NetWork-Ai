import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
Widget studioHost(String html, String nonce, Future<Map<String, dynamic>> Function(Map<String, dynamic>) handler) {
  if (defaultTargetPlatform != TargetPlatform.android) { return const Center(child: Text('افتح استوديو الكروت من Chrome، أو من تطبيق Android.')); }
  return _AndroidStudio(html: html, handler: handler);
}
class _AndroidStudio extends StatefulWidget {
  const _AndroidStudio({required this.html, required this.handler});
  final String html;
  final Future<Map<String, dynamic>> Function(Map<String, dynamic>) handler;
  @override
  State<_AndroidStudio> createState() => _AndroidStudioState();
}
class _AndroidStudioState extends State<_AndroidStudio> {
  MethodChannel? _channel;
  @override
  void dispose() { _channel?.setMethodCallHandler(null); super.dispose(); }
  @override
  Widget build(BuildContext context) => AndroidView(viewType: 'copilot/card-studio', creationParams: {'html': widget.html}, creationParamsCodec: const StandardMessageCodec(), onPlatformViewCreated: (id) async {
    final channel = MethodChannel('copilot/card-studio/$id');
    _channel = channel;
    channel.setMethodCallHandler((call) async {
      if (!mounted || call.method != 'request' || call.arguments is! String) { return null; }
      final raw = call.arguments as String;
      if (raw.length > 35000000) { return null; }
      final message = jsonDecode(raw);
      if (message is! Map) { return null; }
      return widget.handler(message.cast<String, dynamic>());
    });
    await channel.invokeMethod<void>('ready');
  });
}
