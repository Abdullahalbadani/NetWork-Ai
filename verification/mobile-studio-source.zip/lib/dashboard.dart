import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'api.dart';
import 'ui.dart';

class ReadPanel extends ConsumerWidget {
  const ReadPanel({
    super.key,
    required this.connection,
    required this.kind,
    required this.onRetry,
  });
  final LabConnection connection;
  final ReadKind kind;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final observation = ref.watch(
      deviceReadProvider(DeviceRead(connection, kind)),
    );
    final title = switch (kind) {
      ReadKind.health => 'نظرة عامة',
      ReadKind.interfaces => 'واجهات الراوتر',
      ReadKind.hotspotSessions => 'جلسات الهوتسبوت',
    };
    final subtitle = switch (kind) {
      ReadKind.health => 'الموارد الأساسية لجهازك في قراءة واحدة.',
      ReadKind.interfaces => 'حالة الروابط وعدادات البيانات التراكمية.',
      ReadKind.hotspotSessions => 'جلسات Hotspot المسجلة وقت آخر قراءة.',
    };
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(title, style: theme.textTheme.headlineMedium),
        const SizedBox(height: 4),
        Text(
          subtitle,
          style: theme.textTheme.bodyMedium?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        const SizedBox(height: 18),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            InfoBadge(
              label:
                  observation.asData?.value['deviceName'] as String? ??
                  connection.deviceId,
              icon: Icons.router_outlined,
            ),
            const InfoBadge(label: 'قراءة فقط', icon: Icons.lock_outline),
            const InfoBadge(
              label: 'تحديث يدوي',
              icon: Icons.touch_app_outlined,
            ),
          ],
        ),
        const SizedBox(height: 24),
        observation.when(
          skipLoadingOnRefresh: false,
          skipLoadingOnReload: false,
          loading: () => const _LoadingPanel(),
          error: (error, stack) => Card(
            child: Padding(
              padding: const EdgeInsets.all(26),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(
                    Icons.cloud_off_outlined,
                    color: theme.colorScheme.error,
                    size: 32,
                  ),
                  const SizedBox(height: 14),
                  Text('الحالة غير معروفة', style: theme.textTheme.titleLarge),
                  const SizedBox(height: 8),
                  Text(
                    error is ApiFailure
                        ? error.message
                        : 'تعذر الاتصال بخادم الإدارة. تحقق من تشغيله ثم أعد القراءة.',
                  ),
                  const SizedBox(height: 20),
                  FilledButton.icon(
                    onPressed: onRetry,
                    icon: const Icon(Icons.refresh, size: 18),
                    label: const Text('إعادة القراءة'),
                  ),
                ],
              ),
            ),
          ),
          data: (data) => Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 13,
                ),
                decoration: BoxDecoration(
                  color: theme.colorScheme.primary.withValues(alpha: 0.045),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Wrap(
                  spacing: 22,
                  runSpacing: 8,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.place_outlined,
                          color: theme.colorScheme.primary,
                          size: 17,
                        ),
                        const SizedBox(width: 7),
                        Text('الموقع: ${data['siteName'] ?? data['siteId']}'),
                      ],
                    ),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.schedule,
                          color: theme.colorScheme.onSurfaceVariant,
                          size: 16,
                        ),
                        const SizedBox(width: 7),
                        Flexible(
                          child: Text(
                            'آخر قراءة: ${localTimestamp(data['observedAt'] as String)}',
                            style: theme.textTheme.bodySmall,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 22),
              if (kind == ReadKind.health)
                ResourceCards(
                  health: data['health'] as Map<String, dynamic>,
                  deviceId:
                      data['deviceName'] as String? ?? connection.deviceId,
                )
              else
                SnapshotList(
                  key: ValueKey(kind),
                  kind: kind,
                  items: (data['items'] as List).cast<Map<String, dynamic>>(),
                ),
            ],
          ),
        ),
      ],
    );
  }
}

class _LoadingPanel extends StatelessWidget {
  const _LoadingPanel();

  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(32),
      child: Column(
        children: [
          SizedBox(
            width: 28,
            height: 28,
            child: CircularProgressIndicator(
              strokeWidth: 2.5,
              color: Theme.of(context).colorScheme.primary,
            ),
          ),
          const SizedBox(height: 18),
          const Text('جارٍ قراءة الجهاز…'),
        ],
      ),
    ),
  );
}

class ResourceCards extends StatelessWidget {
  const ResourceCards({
    super.key,
    required this.health,
    required this.deviceId,
  });
  final Map<String, dynamic> health;
  final String deviceId;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cpu = (health['cpuLoad'] as num).toDouble();
    final total = (health['totalMemory'] as num).toDouble();
    final free = (health['freeMemory'] as num).toDouble();
    final version = health['version'] as String;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        LayoutBuilder(
          builder: (context, constraints) {
            final columns = constraints.maxWidth >= 920
                ? 4
                : constraints.maxWidth >= 550
                ? 2
                : 1;
            final width = (constraints.maxWidth - (columns - 1) * 16) / columns;
            return Wrap(
              spacing: 16,
              runSpacing: 16,
              children: [
                SizedBox(
                  width: width,
                  child: _MetricCard(
                    title: 'حمل المعالج',
                    value: '${cpu.toStringAsFixed(0)}%',
                    icon: Icons.speed_outlined,
                    detail: 'القيمة المسجلة في آخر قراءة',
                    progress: cpu / 100,
                  ),
                ),
                SizedBox(
                  width: width,
                  child: _MetricCard(
                    title: 'الذاكرة الحرة',
                    value: '${(free / 1048576).toStringAsFixed(1)} MiB',
                    icon: Icons.memory_outlined,
                    detail:
                        'من ${(total / 1048576).toStringAsFixed(0)} MiB • الشريط للمستخدم',
                    progress: (total - free) / total,
                  ),
                ),
                SizedBox(
                  width: width,
                  child: _MetricCard(
                    title: 'إصدار RouterOS',
                    value: version.split(' ').first,
                    icon: Icons.layers_outlined,
                    detail: version,
                  ),
                ),
                SizedBox(
                  width: width,
                  child: _MetricCard(
                    title: 'مدة التشغيل',
                    value: health['uptime'] as String,
                    icon: Icons.timer_outlined,
                    detail: 'منذ آخر تشغيل للجهاز',
                  ),
                ),
              ],
            );
          },
        ),
        const SizedBox(height: 24),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(22),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.all(13),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.secondary.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    Icons.router_outlined,
                    size: 27,
                    color: theme.colorScheme.secondary,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        deviceId,
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        health['boardName'] as String? ?? 'نوع اللوحة غير متاح',
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        'هذه لقطة لموارد الجهاز. تقييم الإنترنت وخدمات الشبكة يحتاج فحوصًا إضافية.',
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({
    required this.title,
    required this.value,
    required this.icon,
    required this.detail,
    this.progress,
  });
  final String title;
  final String value;
  final IconData icon;
  final String detail;
  final double? progress;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    title,
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: scheme.onSurfaceVariant,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                Icon(icon, size: 21, color: scheme.primary),
              ],
            ),
            const SizedBox(height: 18),
            SizedBox(
              height: 42,
              child: Align(
                alignment: AlignmentDirectional.centerStart,
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    value,
                    textDirection: TextDirection.ltr,
                    style: theme.textTheme.headlineMedium?.copyWith(
                      fontSize: 29,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            if (progress != null)
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: progress!.clamp(0.0, 1.0).toDouble(),
                  minHeight: 4,
                  backgroundColor: scheme.primary.withValues(alpha: 0.08),
                ),
              )
            else
              const SizedBox(height: 4),
            const SizedBox(height: 12),
            Text(
              detail,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: theme.textTheme.bodySmall?.copyWith(
                color: scheme.onSurfaceVariant,
                fontSize: 11,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

String dataSize(Object? value) {
  final number = BigInt.tryParse(value?.toString() ?? '');
  if (number == null || number.isNegative) {
    return 'غير متاح';
  }
  var amount = number.toDouble();
  var unit = 0;
  const units = ['B', 'KiB', 'MiB', 'GiB', 'TiB', 'PiB', 'EiB'];
  while (amount >= 1024 && unit < units.length - 1) {
    amount /= 1024;
    unit++;
  }
  return '${amount.toStringAsFixed(unit == 0 ? 0 : 1)} ${units[unit]}';
}

String _linkState(Map<String, dynamic> row) => row['disabled'] == true
    ? 'معطلة إداريًا'
    : row['running'] == true
    ? 'رابط نشط'
    : row['running'] == false
    ? 'رابط غير نشط'
    : 'غير معروفة';

class SnapshotList extends StatefulWidget {
  const SnapshotList({super.key, required this.kind, required this.items});
  final ReadKind kind;
  final List<Map<String, dynamic>> items;

  @override
  State<SnapshotList> createState() => _SnapshotListState();
}

class _SnapshotListState extends State<SnapshotList> {
  final _search = TextEditingController();
  int _page = 0;
  static const _pageSize = 10;
  bool get _interfaces => widget.kind == ReadKind.interfaces;

  @override
  void initState() {
    super.initState();
    _search.addListener(_filterChanged);
  }

  void _filterChanged() {
    setState(() => _page = 0);
  }

  @override
  void didUpdateWidget(covariant SnapshotList oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (!identical(oldWidget.items, widget.items)) {
      _page = 0;
    }
  }

  @override
  void dispose() {
    _search.removeListener(_filterChanged);
    _search.dispose();
    super.dispose();
  }

  Widget _stateBadge(BuildContext context, Map<String, dynamic> row) {
    final scheme = Theme.of(context).colorScheme;
    final color = row['disabled'] == true
        ? (themeIsDark(context)
              ? const Color(0xFFF5BF74)
              : const Color(0xFF936013))
        : row['running'] == true
        ? scheme.primary
        : scheme.onSurfaceVariant;
    return InfoBadge(
      label: _linkState(row),
      icon: row['running'] == true && row['disabled'] != true
          ? Icons.link
          : Icons.link_off,
      color: color,
    );
  }

  bool themeIsDark(BuildContext context) =>
      Theme.of(context).brightness == Brightness.dark;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final query = _search.text.trim().toLowerCase();
    final fields = _interfaces ? ['name', 'type'] : ['address', 'macAddress'];
    final filtered = widget.items
        .where(
          (row) =>
              query.isEmpty ||
              fields.any(
                (field) => (row[field]?.toString() ?? '')
                    .toLowerCase()
                    .contains(query),
              ),
        )
        .toList();
    final start = math.min(_page * _pageSize, filtered.length);
    final end = math.min(start + _pageSize, filtered.length);
    final rows = filtered.sublist(start, end);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        LayoutBuilder(
          builder: (context, constraints) {
            final search = SizedBox(
              width: constraints.maxWidth < 620 ? constraints.maxWidth : 320,
              child: TextField(
                key: const Key('snapshot-search'),
                controller: _search,
                decoration: InputDecoration(
                  hintText: _interfaces
                      ? 'ابحث عن واجهة أو نوعها'
                      : 'ابحث بعنوان IP أو MAC',
                  prefixIcon: const Icon(Icons.search, size: 20),
                  suffixIcon: query.isEmpty
                      ? null
                      : IconButton(
                          tooltip: 'مسح البحث',
                          onPressed: _search.clear,
                          icon: const Icon(Icons.close, size: 18),
                        ),
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 14,
                  ),
                ),
              ),
            );
            final summary = Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'عدد السجلات: ${widget.items.length}',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
                ),
                if (!_interfaces)
                  Text(
                    'جلسات Hotspot فقط، دون بيانات دخول الكروت.',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
              ],
            );
            if (constraints.maxWidth < 620) {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [summary, const SizedBox(height: 16), search],
              );
            }
            return Row(
              children: [
                Expanded(child: summary),
                const SizedBox(width: 20),
                search,
              ],
            );
          },
        ),
        const SizedBox(height: 20),
        if (filtered.isEmpty)
          Card(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 24),
              child: Column(
                children: [
                  Icon(
                    query.isEmpty
                        ? (_interfaces
                              ? Icons.hub_outlined
                              : Icons.people_outline)
                        : Icons.search_off,
                    size: 38,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    query.isNotEmpty
                        ? 'لا توجد نتائج مطابقة للبحث.'
                        : _interfaces
                        ? 'لم تُرجع القراءة أي واجهات.'
                        : 'لا توجد جلسات هوتسبوت نشطة حسب آخر قراءة.',
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          )
        else
          LayoutBuilder(
            builder: (context, constraints) {
              if (constraints.maxWidth < 760) {
                return Column(
                  children: [
                    for (final row in rows)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: _mobileCard(context, row),
                      ),
                    _pagination(context, start, end, filtered.length),
                  ],
                );
              }
              return Card(
                clipBehavior: Clip.antiAlias,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: ConstrainedBox(
                        constraints: BoxConstraints(
                          minWidth: constraints.maxWidth,
                        ),
                        child: DataTable(
                          headingRowColor: WidgetStatePropertyAll(
                            theme.colorScheme.primary.withValues(alpha: 0.035),
                          ),
                          horizontalMargin: 20,
                          columnSpacing: 28,
                          dataRowMinHeight: 66,
                          dataRowMaxHeight: 80,
                          dividerThickness: 1,
                          columns:
                              (_interfaces
                                      ? [
                                          'الواجهة',
                                          'النوع',
                                          'حالة الرابط',
                                          'MTU',
                                          'استقبال إجمالي',
                                          'إرسال إجمالي',
                                        ]
                                      : [
                                          'عنوان IP',
                                          'عنوان MAC',
                                          'مدة الجلسة',
                                          'بيانات واردة',
                                          'بيانات صادرة',
                                        ])
                                  .map(
                                    (label) => DataColumn(
                                      label: Text(
                                        label,
                                        style: const TextStyle(
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                    ),
                                  )
                                  .toList(),
                          rows: rows.map((row) {
                            final values = _interfaces
                                ? [
                                    row['name'],
                                    row['type'],
                                    null,
                                    row['mtu'],
                                    dataSize(row['rxBytes']),
                                    dataSize(row['txBytes']),
                                  ]
                                : [
                                    row['address'],
                                    row['macAddress'],
                                    row['uptime'],
                                    dataSize(row['bytesIn']),
                                    dataSize(row['bytesOut']),
                                  ];
                            return DataRow(
                              cells: values.indexed.map((entry) {
                                if (_interfaces && entry.$1 == 2) {
                                  return DataCell(_stateBadge(context, row));
                                }
                                return DataCell(
                                  Text(
                                    entry.$2?.toString() ?? 'غير متاح',
                                    textDirection: TextDirection.ltr,
                                  ),
                                );
                              }).toList(),
                            );
                          }).toList(),
                        ),
                      ),
                    ),
                    const Divider(),
                    _pagination(context, start, end, filtered.length),
                  ],
                ),
              );
            },
          ),
      ],
    );
  }

  Widget _pagination(BuildContext context, int start, int end, int count) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          Expanded(
            child: Text(
              '${start + 1} إلى $end من $count',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ),
          IconButton(
            tooltip: 'الصفحة السابقة',
            onPressed: _page == 0 ? null : () => setState(() => _page--),
            icon: const Icon(Icons.chevron_right),
          ),
          IconButton(
            tooltip: 'الصفحة التالية',
            onPressed: end >= count ? null : () => setState(() => _page++),
            icon: const Icon(Icons.chevron_left),
          ),
        ],
      ),
    );
  }

  Widget _mobileCard(BuildContext context, Map<String, dynamic> row) {
    final theme = Theme.of(context);
    Widget value(String label, Object? content) => Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            content?.toString() ?? 'غير متاح',
            textDirection: TextDirection.ltr,
            style: theme.textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Icon(
                  _interfaces ? Icons.settings_ethernet : Icons.person_outline,
                  color: theme.colorScheme.primary,
                  size: 23,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    (row[_interfaces ? 'name' : 'address'] ?? 'غير متاح')
                        .toString(),
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
                    textDirection: TextDirection.ltr,
                  ),
                ),
                if (_interfaces) _stateBadge(context, row),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: _interfaces
                  ? [value('النوع', row['type']), value('MTU', row['mtu'])]
                  : [
                      value('عنوان MAC', row['macAddress']),
                      value('مدة الجلسة', row['uptime']),
                    ],
            ),
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 14),
              child: Divider(),
            ),
            Row(
              children: [
                value(
                  _interfaces ? 'استقبال إجمالي' : 'بيانات واردة',
                  dataSize(row[_interfaces ? 'rxBytes' : 'bytesIn']),
                ),
                value(
                  _interfaces ? 'إرسال إجمالي' : 'بيانات صادرة',
                  dataSize(row[_interfaces ? 'txBytes' : 'bytesOut']),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
