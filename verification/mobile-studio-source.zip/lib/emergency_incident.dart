import 'dart:async';
import 'dart:convert';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'account_api.dart';
import 'account_views.dart';
import 'emergency_api.dart';
import 'emergency_common.dart';
import 'emergency_repair.dart';
import 'emergency_ai.dart';

class EmergencyIncidentPage extends StatefulWidget {
  const EmergencyIncidentPage({super.key, required this.account, required this.id, required this.onDevice});
  final AccountController account; final String id; final void Function(String, String) onDevice;
  @override
  State<EmergencyIncidentPage> createState() => _EmergencyIncidentPageState();
}
class _EmergencyIncidentPageState extends State<EmergencyIncidentPage> with WidgetsBindingObserver {
  late final api = EmergencyApi(widget.account);
  Map<String, dynamic>? incident;
  Map<String, dynamic> options = {};
  List<Map<String, dynamic>> events = [], repairs = [];
  Timer? timer;
  bool busy = false, loading = false, foreground = true, childOpen = false;
  String? error, radioId;
  int? frequency;
  @override
  void initState() { super.initState(); WidgetsBinding.instance.addObserver(this); _load(); timer = Timer.periodic(const Duration(seconds: 8), (_) { if (foreground && !busy && !loading && !childOpen) _load(); }); }
  @override
  void dispose() { timer?.cancel(); WidgetsBinding.instance.removeObserver(this); super.dispose(); }
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) { foreground = state == AppLifecycleState.resumed; if (foreground && !loading && !busy && !childOpen) _load(); }
  Future<void> _load() async {
    if (loading) return; loading = true;
    try {
      final data = await Future.wait([api.get('incidents/${widget.id}'), api.get('incidents/${widget.id}/repairs'), if (widget.account.canManage) api.get('incidents/${widget.id}/repair-options')]);
      if (mounted) setState(() { incident = emergencyMap(data[0]['incident']); events = emergencyRows(data[0]['events']); repairs = emergencyRows(data[1]['items']); options = data.length > 2 ? data[2] : {}; final radios = emergencyRows(options['radios']); if (!radios.any((r) => r['id'] == radioId)) radioId = null; final frequencies = emergencyRows(emergencyMap(emergencyMap(options['grant'])['policy'])['radioChannels']).where((r) => r['interface'] == emergencyMap(emergencyMap(incident!['finding'])['metadata'])['interfaceName']).firstOrNull?['frequencies'] as List? ?? []; if (!frequencies.contains(frequency)) frequency = null; error = null; });
    } catch (e) { if (mounted) setState(() { error = accountError(e); if (e is AccountFailure && [401,403,404].contains(e.status)) { incident = null; options = {}; events = []; repairs = []; } }); }
    finally { if (mounted) setState(() => loading = false); }
  }
  Future<void> _act(Future<void> Function() action) async {
    if (busy) return; setState(() { busy = true; error = null; });
    try { await emergencyMutation(context, widget.account, action); await _load(); }
    catch (e) { if (mounted) setState(() => error = accountError(e)); }
    finally { if (mounted) setState(() => busy = false); }
  }
  Future<void> _openRepair(String id) async {
    childOpen = true;
    try { await Navigator.push(context, MaterialPageRoute<void>(builder: (_) => EmergencyScopeGuard(account: widget.account, child: EmergencyRepairPage(account: widget.account, id: id)))); }
    finally { childOpen = false; if (mounted) await _load(); }
  }
  Future<void> _preview(String kind) async {
    final requestId = emergencyRequestId();
    await _act(() async {
      final result = await api.post('incidents/${widget.id}/repair-preview', {'requestId': requestId, 'kind': kind, if (kind == 'wireless.set_frequency') ...{'targetId': radioId, 'frequency': frequency}});
      if (mounted) await _openRepair('${emergencyMap(result['operation'])['id']}');
    });
  }
  Future<void> _analyze() async {
    childOpen = true;
    String? kind;
    try { kind = await showDialog<String>(context: context, builder: (_) => EmergencyScopeGuard(account: widget.account, child: EmergencyAiDialog(account: widget.account, incidentId: widget.id))); }
    finally { childOpen = false; if (mounted) await _load(); }
    if (!mounted || kind == null) return;
    if (kind == 'wireless.set_frequency' && (radioId == null || frequency == null)) { setState(() => error = 'اختر الراديو والتردد المعتمدين في مسار المعالجة قبل طلب معاينة تغيير القناة.'); return; }
    await _preview(kind);
  }
  Future<void> _export() async {
    if (incident == null) return;
    await _act(() async {
      final font = await rootBundle.load('assets/fonts/Tajawal-Regular.ttf');
      String esc(dynamic value) => const HtmlEscape().convert('$value');
      final f = emergencyMap(incident!['finding']);
      final document = '<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'; font-src data:; img-src data:; base-uri \'none\'; form-action \'none\'"><title>تقرير رادار الطوارئ</title><style>@font-face{font-family:t;src:url(data:font/ttf;base64,${base64Encode(font.buffer.asUint8List(font.offsetInBytes, font.lengthInBytes))})}body{font-family:t,sans-serif;max-width:900px;margin:40px auto;padding:20px;color:#0f172a;line-height:1.9}h1{color:#0369a1}section{border:1px solid #cbd5e1;padding:20px;margin:18px 0;border-radius:12px}td,th{padding:10px;text-align:right;vertical-align:top;border-bottom:1px solid #e2e8f0}table{width:100%;border-collapse:collapse}</style><h1>رادار الطوارئ · تقرير العطل</h1><section><h2>${esc(f['title'])}</h2><p>${esc(incident!['siteName'])} · ${esc(incident!['deviceName'])}</p><p>آخر رصد: ${esc(emergencyTime(incident!['lastSeenAt']))}</p><p>الحالة: ${esc(emergencyStatusNames[incident!['state']] ?? incident!['state'])} · ${esc(emergencyStatusNames[incident!['observation']] ?? incident!['observation'])}</p><p>${esc(f['summary'])}</p><table>${emergencyRows(f['evidence']).map((e) => '<tr><th>${esc(e['label'])}</th><td>${esc(e['value'])}</td></tr>').join()}</table></section><section><h2>${esc(f['action'])}</h2><ol>${(f['steps'] as List? ?? []).map((v) => '<li>${esc(v)}</li>').join()}</ol></section><section><h2>سجل المتابعة</h2>${events.map((e) => '<p>${esc(emergencyTime(e['createdAt']))} · ${esc(emergencyEventNames[e['kind']] ?? 'عملية مسجلة')}</p>').join()}</section><p>التقرير يعكس البيانات المقروءة وقت القياس؛ عدم توفر مصدر لا يثبت سلامته. معرف العطل: ${esc(widget.id)}</p></html>';
      await FilePicker.saveFile(dialogTitle: 'حفظ تقرير العطل', fileName: 'copilot-emergency-${widget.id}.html', mimeType: 'text/html', bytes: Uint8List.fromList(utf8.encode(document)));
    });
  }
  @override
  Widget build(BuildContext context) {
    final item = incident, finding = emergencyMap(item?['finding']);
    final grant = emergencyMap(options['grant']), p = emergencyMap(grant['policy']);
    final active = item != null && item['state'] != 'resolved';
    final last = DateTime.tryParse(item?['lastSeenAt']?.toString() ?? '');
    final fresh = last != null && DateTime.now().difference(last).inSeconds <= 300;
    final canPreview = active && fresh && item['observation'] == 'alarm' && grant['enabled'] == true && error == null;
    final radio = emergencyRows(options['radios']).where((v) => v['id'] != null).toList();
    final allowedChannels = emergencyRows(p['radioChannels']).where((v) => v['interface'] == emergencyMap(finding['metadata'])['interfaceName']).firstOrNull;
    return Scaffold(appBar: AppBar(title: const Text('تفاصيل العطل', maxLines: 1, overflow: TextOverflow.ellipsis), actions: [IconButton(tooltip: 'تحديث العطل', onPressed: busy || loading ? null : _load, icon: const Icon(Icons.refresh)), IconButton(tooltip: 'حفظ تقرير قابل للطباعة', onPressed: busy || item == null ? null : _export, icon: const Icon(Icons.ios_share_outlined))]), body: item == null && loading ? const Center(child: CircularProgressIndicator()) : SingleChildScrollView(padding: const EdgeInsets.all(18), child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 900), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      if (error != null) ...[emergencyMessage(context, error!, error: true, retry: _load), const SizedBox(height: 16)],
      if (item != null) ...[
        emergencyCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text('${finding['title']}', style: Theme.of(context).textTheme.headlineSmall), const SizedBox(height: 10), Text('${item['siteName']} · ${item['deviceName']}'), const SizedBox(height: 14),
          Wrap(spacing: 8, runSpacing: 8, children: [EmergencyBadge(emergencyStatusNames[item['state']] ?? 'حالة غير متاحة', state: item['state'] == 'resolved' ? 'resolved' : '${item['severity']}'), EmergencyBadge(emergencyStatusNames[item['observation']] ?? 'غير متاح', state: '${item['observation']}'), if (!fresh) const EmergencyBadge('القراءة تحتاج تحديثًا', state: 'unknown')]),
          const SizedBox(height: 16), Text('${finding['summary']}'), if (finding['currentAvailability'] != null) Text('${finding['currentAvailability']}'),
          const Divider(height: 28), Text('الدليل المقاس', style: Theme.of(context).textTheme.titleMedium),
          for (final e in emergencyRows(finding['evidence'])) Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Text('${e['label']}: ${e['value']}')),
          Text('المصدر: ${finding['source']}'), Text('أول رصد: ${emergencyTime(item['firstSeenAt'])}'), Text('آخر رصد: ${emergencyTime(item['lastSeenAt'])}'),
          const SizedBox(height: 16), Wrap(spacing: 8, runSpacing: 8, children: [
            if (item['state'] == 'open' && widget.account.role != 'viewer') OutlinedButton.icon(onPressed: busy ? null : () => _act(() async { await api.post('incidents/${widget.id}/acknowledge', {'version': item['version']}); }), icon: const Icon(Icons.assignment_ind_outlined), label: const Text('استلام متابعة العطل')),
            if (widget.account.role != 'viewer' && item['deviceEnabled'] == true) OutlinedButton.icon(onPressed: busy ? null : () => _act(() async { await api.post('devices/${item['deviceId']}/scan', {'requestId': emergencyRequestId()}); }), icon: const Icon(Icons.radar), label: const Text('إعادة قياس الرادار')),
            OutlinedButton.icon(onPressed: () { Navigator.pop(context); widget.onDevice('${item['deviceId']}', '${item['deviceName']}'); }, icon: const Icon(Icons.monitor_heart_outlined), label: const Text('فتح فحص الجهاز التفصيلي')),
          ]),
        ])),
        const SizedBox(height: 18), emergencyCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text('${finding['action']}', style: Theme.of(context).textTheme.titleLarge), const SizedBox(height: 14),
          for (final entry in (finding['steps'] as List? ?? []).asMap().entries) Padding(padding: const EdgeInsets.only(bottom: 12), child: Text('${entry.key + 1}. ${entry.value}')),
          if (widget.account.canChat) OutlinedButton.icon(onPressed: busy ? null : _analyze, icon: const Icon(Icons.auto_awesome_outlined), label: const Text('تحليل AI واقتراح المعالجة')),
          if (finding['rule'] == 'management.connection' && widget.account.canManage) OutlinedButton.icon(onPressed: busy ? null : () async { childOpen = true; await showDialog<bool>(context: context, builder: (_) => EmergencyScopeGuard(account: widget.account, child: _RouterTrustDialog(widget.account, '${item['deviceId']}'))); childOpen = false; if (mounted) await _load(); }, icon: const Icon(Icons.enhanced_encryption_outlined), label: const Text('التحقق من شهادة الراوتر وتحديثها')),
          if (widget.account.canManage && emergencyRows(options['actions']).isNotEmpty && active) ...[
            const Divider(height: 24), const Text('تغيير محكوم على الراوتر', style: TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 8),
            if (!canPreview) const Text('تحتاج المعاينة قراءة عطل حديثة وحساب معالجة مفعّلًا. افتح إعداد الرادار لتحديد الحساب والصلاحيات.'),
            for (final action in emergencyRows(options['actions'])) ...[
              const SizedBox(height: 14), Text('${action['impact']}'),
              if (action['kind'] == 'wireless.set_frequency') ...[
                const SizedBox(height: 12), DropdownButtonFormField<String>(initialValue: radioId, isExpanded: true, decoration: const InputDecoration(labelText: 'الراديو المقروء'), items: radio.map((r) => DropdownMenuItem(value: '${r['id']}', child: Text('${r['name']} · ${r['country']}'))).toList(), onChanged: busy ? null : (v) => setState(() => radioId = v)),
                const SizedBox(height: 12), DropdownButtonFormField<int>(initialValue: frequency, isExpanded: true, decoration: const InputDecoration(labelText: 'تردد معتمد MHz'), items: (allowedChannels?['frequencies'] as List? ?? []).map((v) => DropdownMenuItem(value: v as int, child: Text('$v MHz'))).toList(), onChanged: busy ? null : (v) => setState(() => frequency = v)),
              ],
              const SizedBox(height: 10), FilledButton.icon(onPressed: busy || !canPreview || !(p['allowedActions'] as List? ?? []).contains(action['kind']) || action['kind'] == 'wireless.set_frequency' && (radioId == null || frequency == null) ? null : () => _preview('${action['kind']}'), icon: const Icon(Icons.preview_outlined), label: Text('معاينة ${action['title']}')),
            ],
          ],
        ])),
        if (repairs.isNotEmpty) ...[const SizedBox(height: 18), emergencyCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [Text('عمليات هذا العطل', style: Theme.of(context).textTheme.titleLarge), for (final r in repairs) ListTile(contentPadding: EdgeInsets.zero, title: Text(emergencyRepairNames[r['kind']] ?? 'معالجة'), subtitle: Text('${emergencyStatusNames[r['status']] ?? 'غير متاح'} · ${emergencyTime(r['createdAt'])}'), trailing: const Icon(Icons.chevron_left), onTap: busy ? null : () => _openRepair('${r['id']}'))]))],
        const SizedBox(height: 18), emergencyCard(child: EmergencyEvents(events: events)),
        if (busy) const Padding(padding: EdgeInsets.all(12), child: LinearProgressIndicator()),
      ],
    ])))));
  }
}
class _RouterTrustDialog extends StatefulWidget {
  const _RouterTrustDialog(this.account, this.id); final AccountController account; final String id;
  @override
  State<_RouterTrustDialog> createState() => _RouterTrustDialogState();
}
class _RouterTrustDialogState extends State<_RouterTrustDialog> {
  String? ca, error; bool busy = false;
  @override
  Widget build(BuildContext context) => AlertDialog(title: const Text('شهادة اتصال الخادم بالراوتر'), content: SizedBox(width: 480, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    const Text('اختر شهادة CA العامة التي تثق بها لهذا الراوتر، وقارن البصمة بمصدرك الموثوق. سيتحقق الخادم من الاتصال بالشهادة الجديدة قبل حفظها. هذه شهادة الراوتر وليست شهادة دخول التطبيق.'),
    const SizedBox(height: 14), OutlinedButton.icon(onPressed: busy ? null : () async { try { final value = await pickCertificate(); if (mounted && value != null) setState(() { ca = value; error = null; }); } catch (e) { if (mounted) setState(() => error = accountError(e)); } }, icon: const Icon(Icons.upload_file_outlined), label: const Text('اختيار شهادة CA العامة')),
    if (ca != null) SelectableText('SHA256: ${certificateFingerprint(ca!)}', textDirection: TextDirection.ltr),
    if (error != null) Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
  ]))), actions: [TextButton(onPressed: busy ? null : () => Navigator.pop(context), child: const Text('عودة')), FilledButton(onPressed: busy || ca == null ? null : () async {
    setState(() { busy = true; error = null; });
    try { final devices = await widget.account.request('GET','/v1/devices'); final device = emergencyRows(devices['items']).where((d) => d['id'] == widget.id).first;
      if (!context.mounted) return; await emergencyMutation(context, widget.account, () => widget.account.request('POST','/v1/devices/${widget.id}/trust', body: {'ca':ca, 'version':device['version']}));
      if (context.mounted) Navigator.pop(context, true);
    } catch (e) { if (mounted) setState(() => error = accountError(e)); } finally { if (mounted) setState(() => busy = false); }
  }, child: Text(busy ? 'جارٍ التحقق…' : 'التحقق والحفظ'))]);
}
