import 'dart:typed_data';
import 'package:http/http.dart' as http;

// Browsers verify TLS using the user's trust store. No app-level certificate bypass exists.
void setLabTrust(Uint8List? certificate) {}
http.Client createTransport() => http.Client();
