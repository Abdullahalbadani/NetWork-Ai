import 'package:flutter/material.dart';
import 'account_api.dart';
import 'account_views.dart';
import 'command_center.dart';
import 'emergency_api.dart';
import 'emergency_common.dart';
import 'emergency_incident.dart';

class CommandTimelinePage extends StatefulWidget {
  const CommandTimelinePage({super.key, required this.account, required this.onDevice, this.siteId, this.deviceId});
  final AccountController account;
  final void Function(String, String) onDevice;
  final String? siteId, deviceId;
  @override
  State<CommandTimelinePage> createState() => _CommandTimelinePageState();
}
class _CommandTimelinePageState extends State<CommandTimelinePage> {
  Map<String, dynamic>? data;
  Map<String, String> cursor = {};
  final previous = <Map<String, String>>[];
  bool loading = false;
  String? error;
  int epoch = 0;
  @override
  void initState() { super.initState(); load(); }
  @override
  void dispose() { epoch++; super.dispose(); }
  Future<void> load() async {
    final current = ++epoch;
    setState(() { loading = true; error = null; });
    try { final result = await EmergencyApi(widget.account).get('timeline', query: {'siteId': ?widget.siteId, 'deviceId': ?widget.deviceId, 'limit': '30', ...cursor}); if (mounted && current == epoch) setState(() => data = result); }
    catch (e) { if (mounted && current == epoch) setState(() { error = accountError(e); if (e is AccountFailure && [401, 403, 404].contains(e.status)) data = null; }); }
    finally { if (mounted && current == epoch) setState(() => loading = false); }
  }
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('سجل الشبكة والتنبيهات'), actions: [IconButton(tooltip: 'تحديث آخر الأحداث', onPressed: loading ? null : () { cursor = {}; previous.clear(); load(); }, icon: const Icon(Icons.refresh))]), body: SingleChildScrollView(padding: const EdgeInsets.all(18), child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 1000), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    const Text('أحداث الحوادث والمعالجات والعينات المحفوظة، ضمن صلاحياتك والنطاق الذي اخترته. يُحتفظ بآخر 60 عينة قياس لكل جهاز؛ سجل الحوادث مستقل عنها.'),
    const SizedBox(height: 16), if (loading) const LinearProgressIndicator(),
    if (error != null) emergencyMessage(context, error!, error: true, retry: load),
    if (data != null && emergencyRows(data!['items']).isEmpty) emergencyMessage(context, 'لا توجد أحداث محفوظة في هذه الصفحة من السجل.'),
    for (final row in emergencyRows(data?['items'])) Card(child: ListTile(contentPadding: const EdgeInsets.all(16), leading: Icon(row['source'] == 'sample' ? Icons.radar : Icons.history), title: Text(row['kind'] == 'measurement_recorded' ? 'اكتملت قراءة محفوظة' : emergencyEventNames[row['kind']] ?? 'حدث مسجّل'), subtitle: Text('${row['siteName']} · ${row['deviceName']}\n${emergencyTime(row['createdAt'])}'), trailing: const Icon(Icons.chevron_left), onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => EmergencyScopeGuard(account: widget.account, child: row['incidentId'] != null ? EmergencyIncidentPage(account: widget.account, id: '${row['incidentId']}', onDevice: widget.onDevice) : CommandDevicePage(account: widget.account, id: '${row['deviceId']}', sampleId: row['source'] == 'sample' ? '${row['id']}' : null)))))),
    const SizedBox(height: 16), Wrap(alignment: WrapAlignment.center, spacing: 14, runSpacing: 10, children: [
      OutlinedButton(onPressed: loading || previous.isEmpty ? null : () { cursor = previous.removeLast(); load(); }, child: const Text('الأحدث')),
      OutlinedButton(onPressed: loading || data?['nextCursor'] == null ? null : () { previous.add(cursor); cursor = emergencyMap(data!['nextCursor']).map((key, value) => MapEntry(key, '$value')); load(); }, child: const Text('الأقدم')),
    ]),
  ])))));
}
