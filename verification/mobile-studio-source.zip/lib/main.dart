import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'api.dart';
import 'account_views.dart';
import 'account_api.dart';
import 'assistant_panel.dart';
import 'connection_form.dart';
import 'dashboard.dart';
import 'ui.dart';
import 'health_center.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  LicenseRegistry.addLicense(() async* {
    final license = await rootBundle.loadString('assets/fonts/OFL.txt');
    yield LicenseEntryWithLineBreaks(['Tajawal'], license);
    final codeLicense = await rootBundle.loadString(
      'assets/fonts/JetBrainsMono-OFL.txt',
    );
    yield LicenseEntryWithLineBreaks(['JetBrains Mono'], codeLicense);
  });
  runApp(
    ProviderScope(
      retry: (retryCount, error) => null,
      child: const CopilotApp(
        legacyLab: kDebugMode && bool.fromEnvironment('COPILOT_LEGACY_LAB'),
      ),
    ),
  );
}

class CopilotApp extends StatefulWidget {
  const CopilotApp({super.key, this.legacyLab = false});
  final bool legacyLab;

  @override
  State<CopilotApp> createState() => _CopilotAppState();
}

class _CopilotAppState extends State<CopilotApp> {
  ThemeMode _mode = ThemeMode.system;

  void _toggleTheme() {
    final dark =
        _mode == ThemeMode.dark ||
        (_mode == ThemeMode.system &&
            WidgetsBinding.instance.platformDispatcher.platformBrightness ==
                Brightness.dark);
    setState(() => _mode = dark ? ThemeMode.light : ThemeMode.dark);
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'مساعد الشبكة',
    debugShowCheckedModeBanner: false,
    locale: const Locale('ar'),
    supportedLocales: const [Locale('ar')],
    localizationsDelegates: GlobalMaterialLocalizations.delegates,
    theme: CopilotTheme.light(),
    darkTheme: CopilotTheme.dark(),
    themeMode: _mode,
    home: widget.legacyLab
        ? DeviceScreen(onTheme: _toggleTheme)
        : AccountGate(
            onTheme: _toggleTheme,
            deviceBuilder: (context, id, name, back) {
              final account = ProviderScope.containerOf(
                context,
              ).read(accountProvider);
              return DeviceScreen(
                key: ValueKey('${account.workspaceId}:$id'),
                onTheme: _toggleTheme,
                initialConnection: account.connection(id),
                accountMode: true,
                onBack: back,
                deviceName: name,
                canChat: account.canChat,
              );
            },
          ),
  );
}

class DeviceScreen extends ConsumerStatefulWidget {
  const DeviceScreen({
    super.key,
    required this.onTheme,
    this.initialConnection,
    this.accountMode = false,
    this.onBack,
    this.deviceName,
    this.canChat = true,
  });
  final VoidCallback onTheme;
  final LabConnection? initialConnection;
  final bool accountMode, canChat;
  final VoidCallback? onBack;
  final String? deviceName;

  @override
  ConsumerState<DeviceScreen> createState() => _DeviceScreenState();
}

class _DeviceScreenState extends ConsumerState<DeviceScreen> {
  LabConnection? _connection;
  int _tab = 0;

  @override
  void initState() {
    super.initState();
    _connection = widget.initialConnection;
    if (widget.accountMode) _tab = 3;
  }

  @override
  void didUpdateWidget(covariant DeviceScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (!widget.canChat && _tab == 4) _tab = 0;
    if (widget.accountMode &&
        widget.initialConnection != oldWidget.initialConnection) {
      _connect(widget.initialConnection!);
    }
  }

  static const titles = [
    'نظرة عامة',
    'واجهات الراوتر',
    'جلسات الهوتسبوت',
    'صحة الشبكة',
    'المساعد الذكي',
  ];
  static const mobileTitles = [
    'الموارد',
    'الواجهات',
    'الجلسات',
    'الصحة',
    'المساعد',
  ];
  static const icons = [
    Icons.dashboard_outlined,
    Icons.hub_outlined,
    Icons.people_outline,
    Icons.monitor_heart_outlined,
    Icons.auto_awesome_outlined,
  ];
  static const keys = [
    'nav-overview',
    'nav-interfaces',
    'nav-sessions',
    'nav-health',
    'nav-assistant',
  ];

  void _connect(LabConnection value) {
    ref.invalidate(deviceReadProvider(DeviceRead(value, ReadKind.health)));
    setState(() {
      _connection = value;
      _tab = widget.accountMode ? 3 : 0;
    });
  }

  void _select(int value) {
    FocusScope.of(context).unfocus();
    setState(() => _tab = value);
  }

  void _refresh() {
    final current = _connection;
    if (current != null && _tab < 3) {
      ref.invalidate(
        deviceReadProvider(DeviceRead(current, ReadKind.values[_tab])),
      );
    }
  }

  Future<void> _editConnection() async {
    final result = await showDialog<LabConnection>(
      context: context,
      builder: (context) => Dialog(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 540),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(26),
            child: ConnectionForm(
              initial: _connection,
              onConnect: (value) => Navigator.pop(context, value),
            ),
          ),
        ),
      ),
    );
    if (result != null && mounted) {
      _connect(result);
    }
  }

  @override
  Widget build(BuildContext context) {
    final config = _connection;
    final wide = MediaQuery.sizeOf(context).width >= 1000;
    final visible = [0, 1, 2, if (widget.accountMode) 3, if (widget.canChat) 4];
    return Scaffold(
      body: SafeArea(
        child: config == null
            ? WelcomeScreen(onConnect: _connect)
            : Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  if (wide)
                    _Sidebar(
                      selected: _tab,
                      onSelect: _select,
                      deviceId: widget.deviceName ?? config.deviceId,
                      canChat: widget.canChat,
                      canInspect: widget.accountMode,
                    ),
                  Expanded(
                    child: Column(
                      children: [
                        _topBar(context, wide),
                        Expanded(
                          child: Stack(
                            fit: StackFit.expand,
                            children: [
                              if (_tab < 3)
                                SingleChildScrollView(
                                  key: const Key('read-scroll'),
                                  padding: EdgeInsets.all(wide ? 30 : 20),
                                  child: Center(
                                    child: ConstrainedBox(
                                      constraints: const BoxConstraints(
                                        maxWidth: 1320,
                                      ),
                                      child: ReadPanel(
                                        connection: config,
                                        kind: ReadKind.values[_tab],
                                        onRetry: _refresh,
                                      ),
                                    ),
                                  ),
                                ),
                              if (widget.canChat)
                                Offstage(
                                  key: const ValueKey('assistant-container'),
                                  offstage: _tab != 4,
                                  child: TickerMode(
                                    enabled: _tab == 4,
                                    child: AssistantPanel(
                                      key: ValueKey(config),
                                      connection: config,
                                    ),
                                  ),
                                ),
                              if (_tab == 3 && widget.accountMode)
                                HealthCenter(
                                  key: ValueKey(
                                    'health:${config.workspaceId}:${config.deviceId}',
                                  ),
                                  account: ref.read(accountProvider),
                                  deviceId: config.deviceId,
                                  deviceName:
                                      widget.deviceName ?? config.deviceId,
                                ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
      ),
      bottomNavigationBar: config != null && !wide
          ? NavigationBar(
              selectedIndex: visible.indexOf(_tab),
              onDestinationSelected: (position) => _select(visible[position]),
              destinations: List.generate(
                visible.length,
                (position) => NavigationDestination(
                  key: Key(keys[visible[position]]),
                  icon: Icon(icons[visible[position]]),
                  label: mobileTitles[visible[position]],
                ),
              ),
            )
          : null,
    );
  }

  Widget _topBar(BuildContext context, bool wide) {
    final theme = Theme.of(context);
    return Container(
      padding: EdgeInsets.symmetric(horizontal: wide ? 28 : 16, vertical: 12),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(color: theme.colorScheme.outlineVariant),
        ),
      ),
      child: Row(
        children: [
          if (!wide) ...[const BrandMark(size: 32), const SizedBox(width: 10)],
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  wide ? 'مساحة العمل' : 'مساعد الشبكة',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                if (wide)
                  Text(
                    widget.deviceName ?? _connection!.deviceId,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
              ],
            ),
          ),
          if (_tab < 3)
            IconButton(
              key: const Key('refresh'),
              tooltip: 'تحديث القراءة',
              onPressed: _refresh,
              icon: const Icon(Icons.refresh, size: 22),
            ),
          IconButton(
            key: const Key('connection-settings'),
            tooltip: widget.accountMode ? 'إدارة الأجهزة' : 'إعداد الاتصال',
            onPressed: widget.accountMode ? widget.onBack : _editConnection,
            icon: Icon(
              widget.accountMode ? Icons.arrow_forward : Icons.tune,
              size: 22,
            ),
          ),
          IconButton(
            key: const Key('theme-toggle'),
            tooltip: 'تبديل المظهر',
            onPressed: widget.onTheme,
            icon: Icon(
              theme.brightness == Brightness.dark
                  ? Icons.light_mode_outlined
                  : Icons.dark_mode_outlined,
              size: 22,
            ),
          ),
        ],
      ),
    );
  }
}

class _Sidebar extends StatelessWidget {
  const _Sidebar({
    required this.selected,
    required this.onSelect,
    required this.deviceId,
    this.canChat = true,
    this.canInspect = false,
  });
  final bool canChat, canInspect;
  final int selected;
  final ValueChanged<int> onSelect;
  final String deviceId;

  static const descriptions = [
    'موارد الجهاز',
    'الروابط والعدادات',
    'الجلسات النشطة',
    'الفحص والأدلة والتقارير',
    'اسأل وافهم',
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    return Container(
      width: 246,
      padding: const EdgeInsets.fromLTRB(18, 28, 18, 20),
      decoration: BoxDecoration(
        color: scheme.surface,
        border: BorderDirectional(
          end: BorderSide(color: scheme.outlineVariant),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Row(
            children: [
              BrandMark(size: 42),
              SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'مساعد الشبكة',
                      style: TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    SizedBox(height: 2),
                    Text(
                      'NETWORK COPILOT',
                      style: TextStyle(fontSize: 9, letterSpacing: 1.4),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 36),
          Padding(
            padding: const EdgeInsetsDirectional.only(start: 12, bottom: 12),
            child: Text(
              'مساحة العمل',
              style: theme.textTheme.bodySmall?.copyWith(
                color: scheme.onSurfaceVariant,
              ),
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  for (final index in [
                    0,
                    1,
                    2,
                    if (canInspect) 3,
                    if (canChat) 4,
                  ])
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Material(
                        color: selected == index
                            ? scheme.primary.withValues(alpha: 0.09)
                            : Colors.transparent,
                        borderRadius: BorderRadius.circular(12),
                        child: InkWell(
                          key: Key(_DeviceScreenState.keys[index]),
                          borderRadius: BorderRadius.circular(12),
                          onTap: () => onSelect(index),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 13,
                              vertical: 13,
                            ),
                            child: Row(
                              children: [
                                Icon(
                                  _DeviceScreenState.icons[index],
                                  color: selected == index
                                      ? scheme.primary
                                      : scheme.onSurfaceVariant,
                                  size: 23,
                                ),
                                const SizedBox(width: 13),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        _DeviceScreenState.titles[index],
                                        style: theme.textTheme.bodyMedium
                                            ?.copyWith(
                                              fontWeight: selected == index
                                                  ? FontWeight.w700
                                                  : FontWeight.w500,
                                              color: selected == index
                                                  ? scheme.primary
                                                  : scheme.onSurface,
                                            ),
                                      ),
                                      const SizedBox(height: 2),
                                      Text(
                                        descriptions[index],
                                        style: theme.textTheme.bodySmall
                                            ?.copyWith(
                                              fontSize: 10,
                                              color: scheme.onSurfaceVariant,
                                            ),
                                      ),
                                    ],
                                  ),
                                ),
                                if (selected == index)
                                  Container(
                                    width: 5,
                                    height: 5,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: scheme.primary,
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(
              color: theme.scaffoldBackgroundColor,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: scheme.outlineVariant),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.router_outlined,
                      size: 17,
                      color: scheme.primary,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        deviceId,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: theme.textTheme.bodyMedium?.copyWith(
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                const InfoBadge(
                  label: 'قراءة واستشارة',
                  icon: Icons.lock_outline,
                ),
                const SizedBox(height: 10),
                Text(
                  'تُحدّث القراءات عند طلبك.',
                  style: theme.textTheme.bodySmall?.copyWith(
                    fontSize: 11,
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
