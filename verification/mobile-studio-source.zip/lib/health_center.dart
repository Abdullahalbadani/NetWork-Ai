import 'dart:async';
import 'package:flutter/material.dart';
import 'account_api.dart';
import 'account_views.dart' show accountError;
import 'health_api.dart';
import 'health_chart.dart';
import 'health_dialogs.dart';
import 'network_startup.dart';
import 'status_pill.dart';
import 'ui.dart';

class HealthCenter extends StatefulWidget {
  const HealthCenter({
    super.key,
    required this.account,
    required this.deviceId,
    required this.deviceName,
  });
  final AccountController account;
  final String deviceId, deviceName;
  @override
  State<HealthCenter> createState() => _HealthCenterState();
}

class _HealthCenterState extends State<HealthCenter>
    with WidgetsBindingObserver {
  late HealthApi _api;
  Timer? _pollTimer, _clock;
  int _epoch = 0, _tab = 0;
  bool _loading = true, _busy = false, _foreground = true, _available = false;
  String? _error, _requestId, _interfaceId, _notice;
  String _siteName = '', _severity = 'notes';
  Map<String, dynamic> _profile = {'version': 0, 'links': <dynamic>[]};
  List<HealthScan> _history = [];
  HealthScan? _selected, _active;
  final Set<String> _compare = {};
  bool get _canScan =>
      ['owner', 'admin', 'technician'].contains(widget.account.role);
  bool _current(int epoch) => mounted && epoch == _epoch;
  void _dropDeniedData(Object error) {
    if (error is AccountFailure && [401, 403, 404].contains(error.status)) {
      _selected = _active = null;
      _history = [];
      _compare.clear();
      _available = false;
      _profile = {'version': 0, 'links': <dynamic>[]};
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _api = HealthApi(widget.account, widget.deviceId);
    _startClock();
    unawaited(_reload());
  }

  void _startClock() {
    _clock?.cancel();
    _clock = Timer.periodic(const Duration(seconds: 30), (_) {
      if (mounted && _foreground) setState(() {});
    });
  }

  @override
  void didUpdateWidget(covariant HealthCenter oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.deviceId != widget.deviceId ||
        oldWidget.account != widget.account) {
      _epoch++;
      _pollTimer?.cancel();
      _history = [];
      _selected = _active = null;
      _requestId = null;
      _compare.clear();
      _api = HealthApi(widget.account, widget.deviceId);
      unawaited(_reload());
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    _foreground = state == AppLifecycleState.resumed;
    if (!_foreground) {
      _pollTimer?.cancel();
      _clock?.cancel();
    } else {
      _startClock();
      unawaited(_reload());
    }
  }

  @override
  void dispose() {
    _epoch++;
    _pollTimer?.cancel();
    _clock?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  List<HealthScan> _parseHistory(Map<String, dynamic> value) {
    if (value['items'] is! List || (value['items'] as List).length > 20) {
      throw const AccountFailure('invalid_response', 502);
    }
    return (value['items'] as List)
        .map((v) => HealthScan.parse(v as Map<String, dynamic>))
        .toList();
  }

  Future<void> _reload() async {
    final epoch = ++_epoch;
    _pollTimer?.cancel();
    setState(() {
      _loading = true;
      _busy = false;
      _error = null;
    });
    try {
      final values = await Future.wait([_api.profile(), _api.history()]);
      final history = _parseHistory(values[1]);
      final profile = values[0]['profile'];
      if (profile is! Map<String, dynamic> ||
          profile['version'] is! int ||
          profile['links'] is! List) {
        throw const AccountFailure('invalid_response', 502);
      }
      final running = history.where((v) => v.running).firstOrNull;
      final awaited = history
          .where(
            (v) =>
                v.id == _active?.id ||
                (_requestId != null && v.requestId == _requestId),
          )
          .firstOrNull;
      final chosenId = awaited?.status == 'completed'
          ? awaited!.id
          : history.any((v) => v.id == _selected?.id && v.status == 'completed')
          ? _selected!.id
          : history.where((v) => v.status == 'completed').firstOrNull?.id;
      final chosen = chosenId == null ? null : await _api.scan(chosenId);
      if (!_current(epoch)) return;
      setState(() {
        _profile = profile;
        _available = true;
        _history = history;
        if (awaited != null && !awaited.running) {
          _notice = awaited.status == 'completed'
              ? 'اكتمل الفحص وحُفظ تقريره.'
              : awaited.failureMessage;
        }
        if (_requestId != null &&
            history.any((v) => v.requestId == _requestId)) {
          _requestId = null;
        }
        _active = running;
        _selected = chosen;
        _siteName = '${values[0]['siteName'] ?? ''}';
        _loading = false;
        _compare.removeWhere(
          (id) => !history.any((v) => v.id == id && v.status == 'completed'),
        );
      });
      _schedule(epoch);
    } catch (e) {
      if (_current(epoch)) {
        setState(() {
          _error = accountError(e);
          _dropDeniedData(e);
          _loading = false;
        });
      }
    }
  }

  void _schedule(int epoch) {
    _pollTimer?.cancel();
    if (_active?.running == true && _foreground && _current(epoch)) {
      _pollTimer = Timer(
        const Duration(milliseconds: 1100),
        () => unawaited(_poll(epoch)),
      );
    }
  }

  Future<void> _poll(int epoch) async {
    final id = _active?.id;
    if (id == null || !_current(epoch)) return;
    try {
      final value = await _api.scan(id);
      if (!_current(epoch)) return;
      setState(() {
        _active = value.running ? value : null;
        if (value.completed) _selected = value;
        if (!value.running) {
          _notice = value.status == 'completed'
              ? 'اكتمل الفحص وحُفظ تقريره.'
              : value.status == 'cancelled'
              ? 'أُلغي الفحص. تبقى التقارير السابقة محفوظة.'
              : value.failureMessage;
        }
      });
      if (value.running) {
        _schedule(epoch);
      } else {
        await _reload();
      }
    } catch (e) {
      if (_current(epoch)) {
        setState(() {
          _error = 'تعذرت متابعة الفحص. ${accountError(e)}';
          _dropDeniedData(e);
        });
      }
    }
  }

  Future<void> _start() async {
    if (_busy || _active != null || !_available) return;
    final epoch = ++_epoch;
    _pollTimer?.cancel();
    _requestId ??= newScanRequestId();
    setState(() {
      _busy = true;
      _error = null;
      _notice = null;
    });
    try {
      final scan = await _api.start(_requestId!);
      if (!_current(epoch)) return;
      _requestId = null;
      if (scan.running) {
        setState(() => _active = scan);
        _schedule(epoch);
      } else {
        final detail = await _api.scan(scan.id);
        if (_current(epoch)) setState(() => _selected = detail);
        await _reload();
      }
    } catch (e) {
      if (_current(epoch)) setState(() => _error = accountError(e));
    } finally {
      if (_current(epoch)) setState(() => _busy = false);
    }
  }

  Future<void> _cancel() async {
    final id = _active?.id;
    if (id == null || _busy) return;
    final epoch = ++_epoch;
    _pollTimer?.cancel();
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await _api.cancel(id);
      final result = await _api.scan(id);
      if (_current(epoch)) {
        _notice = result.status == 'cancelled'
            ? 'أُلغي الفحص. تبقى التقارير السابقة محفوظة.'
            : result.status == 'completed'
            ? 'اكتمل الفحص قبل وصول الإلغاء؛ يمكنك مراجعة تقريره.'
            : result.failureMessage;
        await _reload();
      }
    } catch (e) {
      if (_current(epoch)) {
        setState(() => _error = 'لم يتأكد إلغاء الفحص. ${accountError(e)}');
        _schedule(epoch);
      }
    } finally {
      if (_current(epoch)) setState(() => _busy = false);
    }
  }

  Future<void> _open(String id) async {
    final epoch = ++_epoch;
    _pollTimer?.cancel();
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final value = await _api.scan(id);
      if (_current(epoch)) {
        setState(() {
          _selected = value;
          _tab = 0;
        });
      }
    } catch (e) {
      if (_current(epoch)) setState(() => _error = accountError(e));
    } finally {
      if (_current(epoch)) {
        setState(() => _busy = false);
        _schedule(epoch);
      }
    }
  }

  Future<void> _compareReports() async {
    if (_compare.length != 2 || _busy) return;
    final epoch = _epoch;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final values = await Future.wait(_compare.map(_api.scan));
      values.sort((a, b) => a.createdAt.compareTo(b.createdAt));
      if (mounted && epoch == _epoch) {
        await compareHealthReports(context, values[0], values[1]);
      }
    } catch (e) {
      if (_current(epoch)) setState(() => _error = accountError(e));
    } finally {
      if (_current(epoch)) setState(() => _busy = false);
    }
  }

  Future<void> _edit() async {
    if (_selected == null || _active != null) return;
    if (await editHealthProfile(
          context,
          _api,
          _profile,
          _selected!.interfaces,
        ) &&
        mounted) {
      await _reload();
    }
  }

  String get _age {
    final text = _selected?.report?['completedAt'] as String?;
    if (text == null) return 'لم يُجرَ فحص بعد';
    final seconds = DateTime.now().difference(DateTime.parse(text)).inSeconds;
    if (seconds < 0) return 'راجع وقت الجهاز والخادم';
    if (seconds < 60) return 'تقرير منذ أقل من دقيقة';
    if (seconds < 3600) return 'تقرير منذ ${seconds ~/ 60} دقيقة';
    if (seconds < 86400) return 'تقرير منذ ${seconds ~/ 3600} ساعة';
    return 'تقرير منذ ${seconds ~/ 86400} يوم';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context), scheme = theme.colorScheme;
    return SingleChildScrollView(
      key: const Key('health-scroll'),
      padding: EdgeInsets.all(
        MediaQuery.sizeOf(context).width >= 1000 ? 30 : 18,
      ),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1280),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Wrap(
                alignment: WrapAlignment.spaceBetween,
                spacing: 20,
                runSpacing: 18,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'الفحص والمخاطر',
                        style: TextStyle(
                          color: scheme.primary,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        'مركز صحة الشبكة',
                        style: theme.textTheme.headlineMedium,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'نتائج واضحة. دليل لكل ملاحظة. قرار مدروس.',
                        style: TextStyle(color: scheme.onSurfaceVariant),
                      ),
                    ],
                  ),
                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: [
                      IconButton(
                        tooltip: 'تحديث التقارير',
                        onPressed: _busy || _loading ? null : _reload,
                        icon: const Icon(Icons.refresh),
                      ),
                      if (widget.account.canManage)
                        IconButton(
                          tooltip: 'إعدادات الفحص',
                          onPressed:
                              _selected == null || _active != null || _loading
                              ? null
                              : _edit,
                          icon: const Icon(Icons.tune),
                        ),
                      if (_canScan)
                        FilledButton.icon(
                          key: const Key('health-start'),
                          onPressed:
                              !_available ||
                                  _busy ||
                                  _active != null ||
                                  _loading
                              ? null
                              : _start,
                          icon: const Icon(Icons.radar),
                          label: Text(
                            _requestId != null
                                ? 'استكمال طلب الفحص'
                                : 'بدء الفحص',
                          ),
                        ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 24),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  InfoBadge(
                    label: widget.deviceName,
                    icon: Icons.router_outlined,
                  ),
                  if (_siteName.isNotEmpty)
                    InfoBadge(label: _siteName, icon: Icons.place_outlined),
                  const InfoBadge(
                    label: 'فحص عند الطلب',
                    icon: Icons.touch_app_outlined,
                  ),
                  const InfoBadge(
                    label: 'قراءة إعدادات الراوتر',
                    icon: Icons.lock_outline,
                  ),
                ],
              ),
              if (_loading)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 20),
                  child: LinearProgressIndicator(),
                ),
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.only(top: 20),
                  child: _message(
                    context,
                    _error!,
                    SignalTone.unknown,
                    action: TextButton(
                      onPressed: _busy ? null : _reload,
                      child: const Text('إعادة المحاولة'),
                    ),
                  ),
                ),
              if (_notice != null)
                Padding(
                  padding: const EdgeInsets.only(top: 18),
                  child: _message(context, _notice!, SignalTone.info),
                ),
              if (!_canScan)
                Padding(
                  padding: const EdgeInsets.only(top: 18),
                  child: _message(
                    context,
                    'يمكنك قراءة التقارير المحفوظة. بدء الفحص متاح للفني والمدير والمالك.',
                    SignalTone.info,
                  ),
                ),
              if (_active != null)
                Padding(
                  padding: const EdgeInsets.only(top: 20),
                  child: _progress(context),
                ),
              const SizedBox(height: 24),
              _hero(context),
              const SizedBox(height: 22),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (var i = 0; i < 4; i++)
                    ChoiceChip(
                      key: Key('health-tab-$i'),
                      label: Text(
                        const [
                          'الملخص',
                          'الواجهات والسرعات',
                          'الملاحظات',
                          'سجل الفحوصات',
                        ][i],
                      ),
                      selected: _tab == i,
                      onSelected: (_) => setState(() => _tab = i),
                    ),
                ],
              ),
              const SizedBox(height: 24),
              if (_tab == 3)
                _historyView(context)
              else if (_selected?.completed != true)
                _empty(context)
              else if (_tab == 0)
                ..._summary(context)
              else if (_tab == 1)
                ..._interfaces(context)
              else
                _findings(context),
              const SizedBox(height: 26),
              Text(
                'النتائج تخص الاختبارات المعلنة ووقت قياسها. عدم توفر البيانات يبقى حالة غير معروفة.',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: scheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _message(
    BuildContext context,
    String message,
    SignalTone tone, {
    Widget? action,
  }) {
    final color = signalColor(context, tone);
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .07),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withValues(alpha: .25)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(
                tone == SignalTone.unknown
                    ? Icons.cloud_off_outlined
                    : Icons.info_outline,
                color: color,
                size: 21,
              ),
              const SizedBox(width: 12),
              Expanded(child: Text(message)),
            ],
          ),
          if (action != null)
            Align(alignment: AlignmentDirectional.centerStart, child: action),
        ],
      ),
    );
  }

  Widget _progress(BuildContext context) {
    final scan = _active!;
    final stage = switch (scan.stage) {
      'sampling' => 'قراءة الموارد والخدمات والواجهات',
      'measuring' => 'جمع عينات فعلية لحساب RX وTX',
      'assessing' => 'تقييم الأدلة وحفظ التقرير',
      _ => 'بدء الفحص',
    };
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Wrap(
              alignment: WrapAlignment.spaceBetween,
              spacing: 12,
              runSpacing: 8,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                StatusPill(tone: SignalTone.info, label: stage),
                if (_canScan)
                  TextButton.icon(
                    key: const Key('health-cancel'),
                    onPressed: _busy ? null : _cancel,
                    icon: const Icon(Icons.stop_circle_outlined),
                    label: const Text('إلغاء الفحص'),
                  ),
              ],
            ),
            const SizedBox(height: 18),
            LinearProgressIndicator(value: scan.progress / 100),
            const SizedBox(height: 12),
            const Text(
              'يمكنك متابعة التقدم هنا. التقرير السابق يحتفظ بوقت قياسه حتى اكتمال فحص جديد.',
            ),
          ],
        ),
      ),
    );
  }

  Widget _hero(BuildContext context) {
    final scheme = Theme.of(context).colorScheme,
        coverage = _selected?.coverage;
    final warnings = coverage?['warnings'] as int?;
    final measured = coverage?['measured'] as int?;
    final title = coverage == null
        ? 'ابدأ بقياس واضح'
        : measured == 0
        ? 'لم تتوفر قراءات كافية'
        : warnings != null && warnings > 0
        ? 'هناك نتائج تحتاج مراجعتك'
        : 'راجع النتائج وتغطية الفحص';
    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: scheme.primary.withValues(alpha: .25)),
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [scheme.primary.withValues(alpha: .11), scheme.surface],
        ),
      ),
      child: Stack(
        children: [
          PositionedDirectional(
            end: -70,
            top: -80,
            width: 340,
            height: 300,
            child: IgnorePointer(
              child: Opacity(
                opacity: .3,
                child: CustomPaint(
                  painter: NetworkThreads(const AlwaysStoppedAnimation(0)),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(26),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                StatusPill(tone: SignalTone.unknown, label: _age),
                const SizedBox(height: 18),
                Text(
                  title,
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 9),
                Text(
                  coverage == null
                      ? 'افحص الموارد والروابط وخدمات الإدارة، ثم افتح الدليل والخطوة المقترحة لكل نتيجة.'
                      : '${coverage['measured']} من ${coverage['total']} اختبارات ذات نتيجة مقاسة؛ ${coverage['unknown']} تحتاج بيانات إضافية.',
                ),
                if (_selected?.report != null) ...[
                  const SizedBox(height: 14),
                  Text(
                    'وقت التقرير: ${localTimestamp(_selected!.report!['completedAt'] as String)}',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _empty(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(32),
      child: Column(
        children: [
          Icon(
            Icons.radar,
            size: 46,
            color: Theme.of(context).colorScheme.primary,
          ),
          const SizedBox(height: 18),
          Text(
            _active != null
                ? 'الفحص جارٍ؛ ستظهر النتائج بعد اكتماله.'
                : 'لا يوجد تقرير مكتمل للعرض.',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 10),
          const Text(
            'ستجد الدليل والتوصيات هنا، ويُحفظ التقرير تلقائيًا في سجل الفحوصات.',
            textAlign: TextAlign.center,
          ),
        ],
      ),
    ),
  );
  List<Widget> _summary(BuildContext context) {
    final coverage = _selected!.coverage!,
        resources = _selected!.report!['resources'] as Map<String, dynamic>?;
    return [
      LayoutBuilder(
        builder: (context, box) {
          final columns = box.maxWidth >= 800 ? 4 : 2,
              width = (box.maxWidth - (columns - 1) * 12) / columns;
          return Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              _metric(
                context,
                width,
                'نجحت في القياس',
                '${coverage['passed']}',
                Icons.task_alt,
                SignalTone.success,
              ),
              _metric(
                context,
                width,
                'تحتاج مراجعة',
                '${coverage['warnings']}',
                Icons.warning_amber,
                _selected!.findings.any((v) => v['state'] == 'critical')
                    ? SignalTone.critical
                    : _selected!.findings.any((v) => v['state'] == 'high')
                    ? SignalTone.high
                    : (coverage['warnings'] as int) > 0
                    ? SignalTone.warning
                    : SignalTone.unknown,
              ),
              _metric(
                context,
                width,
                'غير معروفة',
                '${coverage['unknown']}',
                Icons.help_outline,
                SignalTone.unknown,
              ),
              _metric(
                context,
                width,
                'حمل المعالج',
                resources == null ? '—' : '${resources['cpuLoad']}%',
                Icons.speed,
                SignalTone.info,
              ),
            ],
          );
        },
      ),
      const SizedBox(height: 20),
      _traffic(context),
      const SizedBox(height: 20),
      Row(
        children: [
          Expanded(
            child: Text(
              'الملاحظات المهمة',
              style: Theme.of(context).textTheme.titleLarge,
            ),
          ),
          TextButton(
            onPressed: () => setState(() => _tab = 2),
            child: const Text('عرض الكل'),
          ),
        ],
      ),
      const SizedBox(height: 12),
      for (final row in _orderedFindings().take(3)) ...[
        _findingCard(context, row),
        const SizedBox(height: 12),
      ],
      if (widget.account.canChat)
        Align(
          alignment: AlignmentDirectional.centerStart,
          child: OutlinedButton.icon(
            key: const Key('health-ai'),
            onPressed: () => showDialog<void>(
              context: context,
              builder: (_) =>
                  HealthExplanation(scan: _selected!, account: widget.account),
            ),
            icon: const Icon(Icons.auto_awesome_outlined),
            label: const Text('شرح النتائج بالذكاء الاصطناعي'),
          ),
        ),
    ];
  }

  Widget _metric(
    BuildContext context,
    double width,
    String title,
    String value,
    IconData icon,
    SignalTone tone,
  ) => SizedBox(
    width: width,
    child: Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 22, color: signalColor(context, tone)),
            const SizedBox(height: 16),
            Text(
              value,
              textDirection: TextDirection.ltr,
              style: const TextStyle(
                fontFamily: 'JetBrainsMono',
                fontSize: 27,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 6),
            Text(title, style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ),
    ),
  );
  Widget _traffic(BuildContext context) {
    final ports = _selected!.interfaces;
    final current =
        ports.where((v) => v['id'] == _interfaceId).firstOrNull ??
        ports.where((v) => v['rxBps'] != null).firstOrNull ??
        ports.firstOrNull;
    final points = _selected!.traffic
        .where((v) => v['interfaceId'] == current?['id'])
        .toList();
    final scheme = Theme.of(context).colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Wrap(
              alignment: WrapAlignment.spaceBetween,
              crossAxisAlignment: WrapCrossAlignment.center,
              spacing: 16,
              runSpacing: 14,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'حركة البيانات المقاسة',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 5),
                    const Text('عينات الفحص المحدد؛ الرسم يحتفظ بوقت القياس.'),
                  ],
                ),
                if (current != null)
                  SizedBox(
                    width: 190,
                    child: DropdownButtonFormField<String>(
                      initialValue: current['id'] as String,
                      key: ValueKey('${_selected!.id}:${current['id']}'),
                      isExpanded: true,
                      decoration: const InputDecoration(labelText: 'الواجهة'),
                      items: [
                        for (final row in ports)
                          DropdownMenuItem(
                            value: row['id'] as String,
                            child: Text(
                              row['name'] as String,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontFamily: 'JetBrainsMono',
                                fontSize: 12,
                              ),
                            ),
                          ),
                      ],
                      onChanged: (id) => setState(() => _interfaceId = id),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 22),
            Wrap(
              spacing: 26,
              runSpacing: 12,
              children: [
                _rate(
                  context,
                  'استقبال الراوتر RX',
                  current?['rxBps'] as num?,
                  scheme.primary,
                ),
                _rate(
                  context,
                  'إرسال الراوتر TX',
                  current?['txBps'] as num?,
                  scheme.secondary,
                ),
              ],
            ),
            const SizedBox(height: 18),
            HealthTrafficChart(
              samples: points,
              interfaceName: '${current?['name'] ?? ''}',
            ),
            const Text(
              'المعدل خاص بالواجهة المختارة؛ قد تمر البيانات نفسها عبر واجهات أخرى.',
              style: TextStyle(fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }

  Widget _rate(BuildContext context, String label, num? value, Color color) =>
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: TextStyle(color: color, fontSize: 12)),
          const SizedBox(height: 6),
          Text(
            formatBitRate(value),
            textDirection: TextDirection.ltr,
            style: TextStyle(
              fontFamily: value == null ? 'Tajawal' : 'JetBrainsMono',
              fontSize: 18,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      );
  List<Widget> _interfaces(BuildContext context) => [
    _traffic(context),
    const SizedBox(height: 20),
    for (final row in _selected!.interfaces)
      Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Wrap(
                  spacing: 18,
                  runSpacing: 10,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    Text(
                      row['name'] as String,
                      style: const TextStyle(
                        fontFamily: 'JetBrainsMono',
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    StatusPill(
                      tone: row['disabled'] == true
                          ? SignalTone.warning
                          : row['running'] == true
                          ? SignalTone.success
                          : SignalTone.unknown,
                      label: row['disabled'] == true
                          ? 'معطّلة'
                          : row['running'] == true
                          ? 'رابط عامل'
                          : row['running'] == false
                          ? 'رابط غير عامل'
                          : 'الحالة غير معروفة',
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                Wrap(
                  spacing: 30,
                  runSpacing: 12,
                  children: [
                    _rate(
                      context,
                      'RX',
                      row['rxBps'] as num?,
                      Theme.of(context).colorScheme.primary,
                    ),
                    _rate(
                      context,
                      'TX',
                      row['txBps'] as num?,
                      Theme.of(context).colorScheme.secondary,
                    ),
                  ],
                ),
                if (row['reason'] != null)
                  const Padding(
                    padding: EdgeInsets.only(top: 12),
                    child: Text(
                      'المعدل غير متاح: نقص عينات أو تغير في العدادات أو مدة التشغيل.',
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    if (_selected!.interfaces.isEmpty)
      const Text('تعذرت قراءة الواجهات ضمن هذا الفحص.'),
  ];
  List<Map<String, dynamic>> _orderedFindings() {
    final rows = [..._selected!.findings];
    const order = {
      'critical': 0,
      'high': 1,
      'warning': 2,
      'unknown': 3,
      'pass': 4,
    };
    rows.sort((a, b) => order[a['state']]!.compareTo(order[b['state']]!));
    return rows;
  }

  Widget _findingCard(BuildContext context, Map<String, dynamic> row) => Card(
    child: InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: () => showFinding(context, row),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Wrap(
              spacing: 14,
              runSpacing: 10,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                StatusPill(
                  tone: findingTone(row['state'] as String),
                  label: findingLabel(row['state'] as String),
                ),
                Text(
                  row['title'] as String,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(row['summary'] as String),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: Text(
                    'الدليل والخطوة المقترحة',
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.primary,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                const SizedBox(width: 6),
                Icon(
                  Icons.arrow_back,
                  size: 17,
                  color: Theme.of(context).colorScheme.primary,
                ),
              ],
            ),
          ],
        ),
      ),
    ),
  );
  Widget _findings(BuildContext context) {
    const filters = {
      'notes': 'الملاحظات',
      'all': 'كل الاختبارات',
      'critical': 'حرج',
      'high': 'مرتفع',
      'warning': 'مراجعة',
      'unknown': 'غير معروف',
    };
    final rows = _orderedFindings()
        .where(
          (v) =>
              _severity == 'all' ||
              (_severity == 'notes'
                  ? v['state'] != 'pass'
                  : v['state'] == _severity),
        )
        .toList();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final filter in filters.entries)
              ChoiceChip(
                label: Text(filter.value),
                selected: _severity == filter.key,
                onSelected: (_) => setState(() => _severity = filter.key),
              ),
          ],
        ),
        const SizedBox(height: 18),
        if (rows.isEmpty)
          const Padding(
            padding: EdgeInsets.all(24),
            child: Text('لا توجد نتائج ضمن الفئة المحددة في هذا التقرير.'),
          ),
        for (final row in rows) ...[
          _findingCard(context, row),
          const SizedBox(height: 12),
        ],
      ],
    );
  }

  Widget _historyView(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      Wrap(
        spacing: 16,
        runSpacing: 10,
        alignment: WrapAlignment.spaceBetween,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          const Text(
            'يحتفظ السجل بأحدث 20 فحصًا لهذا الراوتر. حدّد فحصين مكتملين للمقارنة.',
          ),
          OutlinedButton.icon(
            key: const Key('health-compare'),
            onPressed: _compare.length == 2 && !_busy ? _compareReports : null,
            icon: const Icon(Icons.compare_arrows),
            label: const Text('مقارنة المحددين'),
          ),
        ],
      ),
      const SizedBox(height: 18),
      if (_history.isEmpty)
        const Card(
          child: Padding(
            padding: EdgeInsets.all(30),
            child: Text('لم تحفظ أي فحوصات بعد.'),
          ),
        ),
      for (final scan in _history)
        Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Wrap(
                    spacing: 12,
                    runSpacing: 10,
                    crossAxisAlignment: WrapCrossAlignment.center,
                    children: [
                      if (scan.status == 'completed')
                        Checkbox(
                          value: _compare.contains(scan.id),
                          semanticLabel:
                              'تحديد فحص ${localTimestamp(scan.createdAt.toIso8601String())} للمقارنة',
                          onChanged: _busy
                              ? null
                              : (v) => setState(() {
                                  if (v == true && _compare.length < 2) {
                                    _compare.add(scan.id);
                                  } else {
                                    _compare.remove(scan.id);
                                  }
                                }),
                        ),
                      Text(
                        localTimestamp(scan.createdAt.toIso8601String()),
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      StatusPill(
                        tone: scan.running
                            ? SignalTone.info
                            : SignalTone.unknown,
                        label: switch (scan.status) {
                          'running' => 'جارٍ الفحص',
                          'completed' => 'تقرير محفوظ',
                          'cancelled' => 'أُلغي الفحص',
                          _ => 'لم يكتمل الفحص',
                        },
                      ),
                      if (scan.status == 'completed')
                        TextButton(
                          onPressed: _busy ? null : () => _open(scan.id),
                          child: const Text('عرض التقرير'),
                        ),
                    ],
                  ),
                  if (scan.coverage != null)
                    Text(
                      '${scan.coverage!['measured']} / ${scan.coverage!['total']} نتائج مقاسة · ${scan.coverage!['warnings']} تحتاج مراجعة · ${scan.coverage!['unknown']} غير معروفة',
                    ),
                  if (scan.status == 'interrupted') Text(scan.failureMessage),
                ],
              ),
            ),
          ),
        ),
    ],
  );
}
