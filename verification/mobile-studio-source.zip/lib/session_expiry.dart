import 'dart:async';

class SessionExpiryNotice {
  const SessionExpiryNotice(this.endpoint, this.token);
  final String endpoint, token;
  @override
  String toString() => 'SessionExpiryNotice(redacted)';
}

abstract final class SessionExpiry {
  static final _events = StreamController<SessionExpiryNotice>.broadcast();
  static Stream<SessionExpiryNotice> get notices => _events.stream;
  static void report(String endpoint, String token) =>
      _events.add(SessionExpiryNotice(endpoint, token));
}
