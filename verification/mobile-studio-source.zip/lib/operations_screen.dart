import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'account_api.dart';
import 'account_views.dart';

String operationRequestId() {
  final random = Random.secure();
  final bytes = List<int>.generate(16, (_) => random.nextInt(256));
  bytes[6] = (bytes[6] & 15) | 64;
  bytes[8] = (bytes[8] & 63) | 128;
  final s = bytes.map((v) => v.toRadixString(16).padLeft(2, '0')).join();
  return '${s.substring(0, 8)}-${s.substring(8, 12)}-${s.substring(12, 16)}-${s.substring(16, 20)}-${s.substring(20)}';
}

const batchStatusNames = {
  'draft': 'مسودة؛ لم تنفذ', 'approved': 'معتمدة؛ تنتظر التنفيذ',
  'running': 'جارٍ التنفيذ', 'paused': 'توقفت؛ تحتاج مراجعة',
  'cancelled': 'أُوقف المتبقي', 'completed': 'اكتمل الإنشاء على الراوتر',
};

class OperationsScreen extends StatefulWidget {
  const OperationsScreen({super.key, required this.account, required this.sites, required this.devices});
  final AccountController account;
  final List<Map<String, dynamic>> sites, devices;
  @override
  State<OperationsScreen> createState() => _OperationsScreenState();
}

class _OperationsScreenState extends State<OperationsScreen> with WidgetsBindingObserver {
  String? _site, _error;
  String _kind = 'subscribers', _query = '';
  bool _loading = false, _busy = false, _archived = false;
  int _offset = 0, _total = 0, _epoch = 0;
  List<Map<String, dynamic>> _rows = [], _plans = [], _grants = [];
  Map<String, dynamic>? _portal;
  Timer? _search;
  AccountController get account => widget.account;
  List<Map<String, dynamic>> rows(dynamic value) => (value as List).cast<Map<String, dynamic>>();
  @override
  void initState() { super.initState(); WidgetsBinding.instance.addObserver(this); _site = widget.sites.firstOrNull?['id'] as String?; unawaited(_load()); }
  @override
  void dispose() { _epoch++; _search?.cancel(); WidgetsBinding.instance.removeObserver(this); super.dispose(); }
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) { if (state == AppLifecycleState.resumed && mounted) { unawaited(_load()); } }
  Future<void> _load() async {
    final epoch = ++_epoch, site = _site;
    if (site == null) { return; }
    setState(() { _loading = true; _error = null; });
    try {
      final query = {'siteId': site, 'q': _query, 'offset': '$_offset', 'limit': '50', 'archived': '$_archived'};
      final value = _kind == 'portal'
          ? await account.request('GET', '/v1/operations/portals/$site')
          : await account.request('GET', '/v1/operations/$_kind', query: _kind == 'batches' ? {'siteId': site, 'offset': '$_offset'} : query);
      final plans = rows((await account.request('GET', '/v1/operations/plans', query: {'siteId': site, 'limit': '100'}))['items']);
      final grants = account.canManage && _kind == 'batches' ? rows((await account.request('GET', '/v1/operations/write-grants', query: {'siteId': site}))['items']) : <Map<String,dynamic>>[];
      if (!mounted || epoch != _epoch) { return; }
      setState(() { _rows = _kind == 'portal' ? [] : rows(value['items']); _total = value['total'] as int? ?? 0; _plans = plans; _grants = grants; _portal = value['portal'] as Map<String,dynamic>?; _loading = false; });
    } catch (e) { if (mounted && epoch == _epoch) { setState(() { _error = accountError(e); _loading = false; _rows = []; _portal = null; }); } }
  }
  Future<void> _mutation(Future<void> Function() action) async {
    try { await action(); } on AccountFailure catch (e) {
      if (e.code != 'step_up_required') { rethrow; }
      final code = TextEditingController();
      try {
        final ok = await _edit('تأكيد هويتك', {'رمز تطبيق المصادقة': code}, () => account.stepUp(code.text.trim()));
        if (!ok) { throw const AccountFailure('action_cancelled', 0); }
      } finally { code.dispose(); }
      await action();
    }
  }
  void _notice(String text) { if (mounted) { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text))); } }
  Future<void> _action(Future<void> Function() action) async {
    if (_busy) { return; }
    setState(() => _busy = true);
    try { await action(); } catch (e) { _notice(accountError(e)); }
    finally { if (mounted) { setState(() => _busy = false); } }
  }
  Future<bool> _confirm(String title, String content) async => await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
    title: Text(title), content: SingleChildScrollView(child: SelectableText(content)), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('رجوع')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('اعتماد'))],
  )) ?? false;
  Future<bool> _edit(String title, Map<String, TextEditingController> fields, Future<void> Function() save, {Widget Function(StateSetter)? extra, Set<String> optional = const {}, Set<String> secret = const {}}) async {
    var busy = false; String? error;
    final route = DialogRoute<bool>(context: context, barrierDismissible: false, builder: (ctx) => StatefulBuilder(builder: (context, update) => AlertDialog(
      title: Text(title), content: SizedBox(width: 500, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        errorBox(error), for (final entry in fields.entries) Padding(padding: const EdgeInsets.only(bottom: 14), child: TextField(controller: entry.value, enabled: !busy, obscureText: secret.contains(entry.key), autocorrect: false, enableSuggestions: !secret.contains(entry.key), decoration: InputDecoration(labelText: entry.key), maxLength: entry.key == 'ملاحظة' ? 500 : 200)),
        if (extra != null) extra(update),
      ]))), actions: [TextButton(onPressed: busy ? null : () => Navigator.pop(ctx, false), child: const Text('إلغاء')), FilledButton(onPressed: busy ? null : () async {
        if (fields.entries.any((e) => !optional.contains(e.key) && e.value.text.trim().isEmpty)) { update(() => error = 'أكمل الحقول المطلوبة.'); return; }
        update(() { busy = true; error = null; });
        try { await save(); if (ctx.mounted) { Navigator.pop(ctx, true); } } catch (e) { if (ctx.mounted) { update(() => error = accountError(e)); } }
        finally { if (ctx.mounted) { update(() => busy = false); } }
      }, child: Text(busy ? 'جارٍ الحفظ…' : 'حفظ'))],
    )));
    final result = await Navigator.of(context, rootNavigator: true).push(route); await route.completed; return result == true;
  }
  Future<bool> _saveFile(String filename, List<int> bytes) async {
    final saved = await FilePicker.saveFile(mimeType: filename.endsWith('.zip') ? 'application/zip' : 'text/html', dialogTitle: 'حفظ الملف في مكان خاص', fileName: filename, bytes: Uint8List.fromList(bytes));
    if (saved != null && mounted) { _notice('تم حفظ الملف. افتح HTML في المتصفح للمعاينة والطباعة.'); }
    return saved != null;
  }
  Future<void> _record([Map<String,dynamic>? old]) async {
    final kind = _kind, site = _site!, fields = <String, TextEditingController>{};
    void field(String label, dynamic value) { fields[label] = TextEditingController(text: value?.toString() ?? ''); }
    field('الاسم', old?['name']); field('الهاتف', old?['phone']);
    if (kind == 'plans') { fields.remove('الهاتف')?.dispose(); field('السعر بالريال', old?['price']); field('الحجم MiB', old?['quotaMiB']); field('دقائق الاستخدام التراكمي', old?['uptimeMinutes']); field('اسم ملف Hotspot الموجود في الراوتر', old?['routerProfile']); }
    if (kind == 'resellers') { field('الموقع', old?['location']); }
    if (kind == 'subscribers') { field('ملاحظة', old?['note']); field('تاريخ الانتهاء الإداري YYYY-MM-DD', old?['endsOn']); }
    String? planId = old?['planId'] as String?;
    var status = old?['status'] as String? ?? 'active', archived = old?['archived'] == true;
    try {
      final saved = await _edit(old == null ? 'إضافة سجل' : 'تعديل السجل', fields, () => _mutation(() async {
        int number(String k) { final value = int.tryParse(fields[k]!.text.trim()); if (value == null) { throw const AccountFailure('invalid_request', 400); } return value; }
        final body = <String,dynamic>{'siteId': site, 'name': fields['الاسم']!.text.trim(), if (old != null) 'version': old['version']};
        if (kind == 'plans') { body.addAll({'price': number('السعر بالريال'), 'quotaMiB': number('الحجم MiB'), 'uptimeMinutes': number('دقائق الاستخدام التراكمي'), 'routerProfile': fields['اسم ملف Hotspot الموجود في الراوتر']!.text.trim(), 'archived': archived}); }
        else { body['phone'] = fields['الهاتف']!.text.trim(); }
        if (kind == 'resellers') { body.addAll({'location': fields['الموقع']!.text.trim(), 'archived': archived}); }
        if (kind == 'subscribers') { body.addAll({'note': fields['ملاحظة']!.text.trim(), 'endsOn': fields['تاريخ الانتهاء الإداري YYYY-MM-DD']!.text.trim().isEmpty ? null : fields['تاريخ الانتهاء الإداري YYYY-MM-DD']!.text.trim(), 'planId': planId, 'status': status}); }
        await account.request(old == null ? 'POST' : 'PATCH', '/v1/operations/$kind${old == null ? '' : '/${old['id']}'}', body: body);
      }), optional: {'الهاتف', 'الموقع', 'ملاحظة', 'تاريخ الانتهاء الإداري YYYY-MM-DD'}, extra: (update) => Column(children: [
        if (kind == 'subscribers') ...[
          DropdownButtonFormField<String>(isExpanded: true, initialValue: planId, decoration: const InputDecoration(labelText: 'باقة إدارية اختيارية'), items: [const DropdownMenuItem<String>(value: null, child: Text('بدون باقة')), if (planId != null && !_plans.any((p) => p['id'] == planId)) DropdownMenuItem(value: planId, child: const Text('الباقة السابقة المؤرشفة')), for (final p in _plans) DropdownMenuItem(value: p['id'] as String, child: Text(p['name'] as String))], onChanged: (v) => update(() => planId = v)),
          DropdownButtonFormField<String>(isExpanded: true, initialValue: status, decoration: const InputDecoration(labelText: 'حالة السجل الإداري'), items: const [DropdownMenuItem(value: 'active', child: Text('نشط إداريًا')), DropdownMenuItem(value: 'suspended', child: Text('موقوف إداريًا')), DropdownMenuItem(value: 'archived', child: Text('مؤرشف'))], onChanged: (v) => update(() => status = v!)),
          const Text('تعديل الحالة أو التاريخ لا يقطع خدمة المشترك على الراوتر. القياس والاستهلاك غير متاحين في هذا السجل.'),
        ] else SwitchListTile(value: archived, title: const Text('أرشفة السجل'), onChanged: (v) => update(() => archived = v)),
        if (kind == 'plans') const Text('السرعة من ملف Hotspot الموجود على الراوتر. المدة استخدام تراكمي؛ لا تُنشئ صلاحية تقويمية بعد أول دخول.'),
      ]));
      if (saved && mounted) { await _load(); }
    } finally { for (final c in fields.values) { c.dispose(); } }
  }
  Future<void> _grant(Map<String,dynamic> device) async {
    final username = TextEditingController(), password = TextEditingController();
    final old = _grants.where((g) => g['deviceId'] == device['id']).firstOrNull;
    try {
      final saved = await _edit('حساب مستقل لإنشاء مستخدمي الهوتسبوت', {'اسم المستخدم': username, 'كلمة المرور': password}, () => _mutation(() async {
        await account.request('POST', '/v1/operations/devices/${device['id']}/write-grant', body: {'username': username.text.trim(), 'password': password.text, 'version': old?['version'] ?? 0});
      }), secret: {'كلمة المرور'}, extra: (_) => const Text('يتحقق الخادم من القراءة بهذا الحساب. لا تُنفذ كتابة الآن. يُستخدم الحساب لاحقًا لإنشاء مستخدمي Hotspot فقط، بعد معاينة الدفعة واعتمادها. لا تستخدم حساب القراءة الحالي.'));
      if (saved && mounted) { await _load(); }
    } finally { username.dispose(); password.dispose(); }
  }
  Future<void> _newBatch() async {
    final devices = widget.devices.where((d) => d['siteId'] == _site && d['enabled'] == true).toList();
    if (devices.isEmpty || _plans.isEmpty) { _notice('أضف باقة وجهازًا مفعّلًا في هذا الموقع أولًا.'); return; }
    var deviceId = devices.first['id'] as String, planId = _plans.first['id'] as String;
    final resellers = rows((await account.request('GET', '/v1/operations/resellers', query: {'siteId': _site!, 'limit': '100'}))['items']);
    if (!mounted) { return; }
    String? resellerId;
    final count = TextEditingController(text: '25'), requestId = operationRequestId();
    try {
      // The request ID and selected inputs survive a network retry while this dialog remains open.
      Map<String,dynamic>? pending;
      final saved = await _edit('توليد دفعة كروت مشفرة', {'عدد الكروت 1 إلى 500': count}, () => _mutation(() async {
        final body = {'requestId': requestId, 'deviceId': deviceId, 'planId': planId, 'count': int.tryParse(count.text.trim()), 'resellerId': resellerId};
        if (pending != null && jsonEncode(pending) != jsonEncode(body)) { throw const AccountFailure('idempotency_conflict', 409); }
        pending = body;
        await account.request('POST', '/v1/operations/batches', body: body);
      }), extra: (update) => Column(children: [
        DropdownButtonFormField<String>(isExpanded: true, initialValue: deviceId, decoration: const InputDecoration(labelText: 'الراوتر'), items: devices.map((d) => DropdownMenuItem(value: d['id'] as String, child: Text(d['name'] as String))).toList(), onChanged: (v) => update(() => deviceId = v!)),
        DropdownButtonFormField<String>(isExpanded: true, initialValue: planId, decoration: const InputDecoration(labelText: 'الباقة'), items: _plans.map((p) => DropdownMenuItem(value: p['id'] as String, child: Text(p['name'] as String))).toList(), onChanged: (v) => update(() => planId = v!)),
        DropdownButtonFormField<String>(isExpanded: true, initialValue: resellerId, decoration: const InputDecoration(labelText: 'نقطة البيع الاختيارية'), items: [const DropdownMenuItem<String>(value: null, child: Text('بدون تخصيص')), for (final r in resellers) DropdownMenuItem(value: r['id'] as String, child: Text(r['name'] as String))], onChanged: (v) => update(() => resellerId = v)),
        const Text('التوليد يحفظ مسودة فقط. الطباعة متاحة للكروت التي تأكد إنشاؤها على الراوتر. عند فشل الاتصال أعد حفظ الطلب نفسه؛ لا تُنشئ دفعة بديلة قبل تحديث القائمة.'),
      ]));
      if (saved && mounted) { await _load(); }
    } finally { count.dispose(); }
  }
  Future<void> _deploy(Map<String,dynamic> batch) async {
    final id = batch['id'];
    final preview = await account.request('POST', '/v1/operations/batches/$id/preview', body: {});
    if (!mounted) { return; }
    if (!await _confirm('معاينة إنشاء الكروت على الراوتر', 'الراوتر: ${preview['deviceId']}\nالباقة: ${(preview['plan'] as Map)['name']}\nالإجمالي: ${preview['count']} — المنجز: ${preview['ready']} — غير المحسوم: ${preview['unknown']}\n\nسيُنشأ مستخدمو Hotspot المحددون فقط بحساب الكتابة المستقل. الإلغاء يوقف المتبقي ولا يحذف المستخدمين المنشأين. النتائج غير المحسومة تُفحص دون إعادة كتابة تلقائية.\n\nالبصمة: ${preview['digest']}')) { return; }
    await _mutation(() async {
      final approved = await account.request('POST', '/v1/operations/batches/$id/approve', body: {'version': preview['version'], 'digest': preview['digest']});
      await account.request('POST', '/v1/operations/batches/$id/execute', body: {'version': approved['version']});
    });
    await _load(); _notice('بدأ التنفيذ. حدّث القائمة لمتابعة التقدم؛ لا يلزم إبقاء هذه الشاشة مفتوحة.');
  }
  Future<void> _portalEdit() async {
    final old = _portal, design = old?['design'] as Map<String,dynamic>?;
    final title = TextEditingController(text: design?['title'] as String? ?? 'شبكتي'), welcome = TextEditingController(text: design?['welcome'] as String? ?? 'أهلًا بك في شبكتنا'), phone = TextEditingController(text: design?['phone'] as String? ?? '');
    var plans = design?['showPlans'] != false, pos = design?['showResellers'] != false;
    try {
      final saved = await _edit('تصميم صفحة الدخول', {'اسم الشبكة': title, 'رسالة الترحيب': welcome, 'الهاتف': phone}, () => _mutation(() async { await account.request('POST', '/v1/operations/portals/$_site', body: {'version': old?['version'] ?? 0, 'design': {'title': title.text.trim(), 'welcome': welcome.text.trim(), 'phone': phone.text.trim(), 'showPlans': plans, 'showResellers': pos}}); }), optional: {'الهاتف'}, extra: (update) => Column(children: [SwitchListTile(value: plans, title: const Text('إظهار الباقات'), onChanged: (v) => update(() => plans = v)), SwitchListTile(value: pos, title: const Text('إظهار نقاط البيع'), onChanged: (v) => update(() => pos = v))]));
      if (saved && mounted) { await _load(); }
    } finally { title.dispose(); welcome.dispose(); phone.dispose(); }
  }
  Future<void> _portalPreview() async {
    final site = _site!, value = await account.request('POST', '/v1/operations/portals/$site/preview', body: {});
    if (!await _saveFile('copilot-hotspot-preview.html', utf8.encode(value['html'] as String))) { return; }
    if (!mounted) { return; }
    if (await _confirm('اعتماد التصميم بعد المعاينة', 'افتح ملف المعاينة المحفوظ وراجعه قبل الاعتماد.\n${jsonEncode(value['snapshot'])}\n\nالبصمة: ${value['digest']}\n\nالاعتماد يثبّت نسخة للتصدير؛ لا يرفع شيئًا إلى الراوتر.')) {
      await _mutation(() async { await account.request('POST', '/v1/operations/portals/$site/approve', body: {'version': (value['snapshot'] as Map)['version'], 'digest': value['digest']}); });
      await _load();
    }
  }
  @override
  Widget build(BuildContext context) {
    if (widget.sites.isEmpty) { return const Center(child: Text('أضف موقعًا أولًا لربط سجلات الإدارة به.')); }
    final names = {'subscribers': 'المشتركون', 'plans': 'الباقات', 'resellers': 'نقاط البيع', if (account.canManage) 'batches': 'الكروت والطباعة', if (account.canManage) 'portal': 'صفحة الهوتسبوت'};
    return ListView(padding: const EdgeInsets.all(18), children: [
      const Text('إدارة الشبكة', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      const Text('سجلات فعلية في مساحة عملك. لا تُعرض قياسات أو مبيعات تجريبية.'),
      const SizedBox(height: 18),
      DropdownButtonFormField<String>(isExpanded: true, initialValue: _site, decoration: const InputDecoration(labelText: 'الموقع'), items: widget.sites.map((s) => DropdownMenuItem(value: s['id'] as String, child: Text(s['name'] as String))).toList(), onChanged: _busy ? null : (v) { setState(() { _site = v; _offset = 0; }); unawaited(_load()); }),
      const SizedBox(height: 14),
      Wrap(spacing: 8, runSpacing: 8, children: names.entries.map((e) => ChoiceChip(label: Text(e.value), selected: _kind == e.key, onSelected: _busy ? null : (_) { setState(() { _kind = e.key; _offset = 0; _query = ''; _archived = false; }); unawaited(_load()); })).toList()),
      const SizedBox(height: 16),
      if (!['portal', 'batches'].contains(_kind)) ...[
        TextField(key: ValueKey(_kind), decoration: const InputDecoration(labelText: 'بحث بالاسم', prefixIcon: Icon(Icons.search)), onChanged: (v) { _query = v; _offset = 0; _search?.cancel(); _search = Timer(const Duration(milliseconds: 350), _load); }),
        SwitchListTile(value: _archived, title: const Text('عرض المؤرشف'), onChanged: _busy ? null : (v) { setState(() { _archived = v; _offset = 0; }); unawaited(_load()); }),
      ],
      Wrap(spacing: 8, runSpacing: 8, children: [
        OutlinedButton.icon(onPressed: _busy || _loading ? null : _load, icon: const Icon(Icons.refresh), label: const Text('تحديث')),
        if (account.canManage && !['portal', 'batches'].contains(_kind)) FilledButton.icon(onPressed: _busy || _loading ? null : () => _action(_record), icon: const Icon(Icons.add), label: const Text('إضافة')),
        if (_kind == 'batches') FilledButton.icon(onPressed: _busy || _loading ? null : () => _action(_newBatch), icon: const Icon(Icons.confirmation_number_outlined), label: const Text('دفعة جديدة')),
      ]),
      if (_loading || _busy) const LinearProgressIndicator(),
      if (_error != null) Padding(padding: const EdgeInsets.all(16), child: Column(children: [const Icon(Icons.error_outline), Text(_error!), TextButton(onPressed: _load, child: const Text('إعادة المحاولة'))])),
      if (!_loading && _error == null && _kind == 'batches') ...[
        const Text('حسابات إنشاء الكروت: تظل معطلة حتى تهيئ حساب كتابة مستقلًا في مختبرك. لا تنفذ على الراوتر العامل قبل قبول تجربة CHR.'),
        for (final d in widget.devices.where((d) => d['siteId'] == _site && d['enabled'] == true)) Card(child: Padding(padding: const EdgeInsets.all(12), child: Wrap(spacing: 8, runSpacing: 8, crossAxisAlignment: WrapCrossAlignment.center, children: [Text(d['name'] as String), OutlinedButton(onPressed: _busy ? null : () => _action(() => _grant(d)), child: const Text('تهيئة حساب الكتابة')), for (final g in _grants.where((g) => g['deviceId'] == d['id'] && g['enabled'] == true)) TextButton.icon(onPressed: _busy ? null : () => _action(() async { if (await _confirm('إيقاف صلاحية إنشاء الكروت', 'سيتوقف إنشاء كروت جديدة. يبقى ما أُنشئ على الراوتر كما هو.')) { await _mutation(() async { await account.request('POST', '/v1/operations/devices/${d['id']}/disable-write-grant', body: {'version': g['version']}); }); await _load(); } }), icon: const Icon(Icons.block), label: const Text('إيقاف الكتابة'))]))),
      ],
      if (!_loading && _error == null && _kind == 'portal') _portalCard(),
      if (!_loading && _error == null && _kind != 'portal' && _rows.isEmpty)
        const Padding(
          padding: EdgeInsets.all(28),
          child: Row(
            children: [
              Icon(Icons.inbox_outlined),
              SizedBox(width: 12),
              Expanded(child: Text('لا توجد سجلات مطابقة.')),
            ],
          ),
        ),
      for (final row in _rows) if (_kind == 'batches') _batchCard(row) else Card(child: ListTile(isThreeLine: true, leading: Icon(_kind == 'subscribers' ? Icons.person_outline : _kind == 'plans' ? Icons.inventory_2_outlined : Icons.storefront_outlined), title: Text(row['name'] as String), subtitle: Text(_kind == 'plans' ? '${row['price']} ريال · ${row['quotaMiB']} MiB\n${row['uptimeMinutes']} دقيقة تراكمية · ملف ${row['routerProfile']}' : _kind == 'subscribers' ? '${row['phone']} · ${row['endsOn'] ?? 'بدون تاريخ'}\nحالة إدارية: ${row['status'] == 'active' ? 'نشط' : row['status'] == 'suspended' ? 'موقوف' : 'مؤرشف'} · الاستهلاك غير متاح' : '${row['phone']}\n${row['location']}'), trailing: account.canManage ? IconButton(tooltip: 'تعديل', onPressed: _busy ? null : () => _action(() => _record(row)), icon: const Icon(Icons.edit_outlined)) : null)),
      if (_kind != 'portal')
        Row(
          key: const Key('operations-pagination'),
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            IconButton(
              tooltip: 'السابق',
              onPressed: _offset == 0 || _busy ? null : () {
                _offset = max(0, _offset - 50);
                unawaited(_load());
              },
              icon: const Icon(Icons.chevron_right),
            ),
            Flexible(
              child: Text(
                '${_rows.isEmpty ? 0 : _offset + 1} — ${min(_offset + _rows.length, _total)} من $_total',
                textAlign: TextAlign.center,
              ),
            ),
            IconButton(
              tooltip: 'التالي',
              onPressed: _offset + 50 >= _total || _busy ? null : () {
                _offset += 50;
                unawaited(_load());
              },
              icon: const Icon(Icons.chevron_left),
            ),
          ],
        ),
    ]);
  }
  Widget _batchCard(Map<String,dynamic> b) => Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [const Icon(Icons.confirmation_number_outlined), const SizedBox(width: 8), Expanded(child: Text('${(b['plan'] as Map)['name']} · ${b['count']} كرت'))]),
    Text('${batchStatusNames[b['status']] ?? b['status']} · المنجز ${b['ready'] ?? 0}/${b['count']}'),
    if (b['reason'] != null) Text(AccountFailure(b['reason'] as String, 0).message),
    Wrap(spacing: 8, runSpacing: 8, children: [
      if (!['completed', 'running'].contains(b['status'])) FilledButton(onPressed: _busy ? null : () => _action(() => _deploy(b)), child: const Text('معاينة واعتماد التنفيذ')),
      if (b['status'] != 'completed') TextButton.icon(onPressed: _busy ? null : () => _action(() async { if (await _confirm('إيقاف المتبقي', 'ما أُنشئ على الراوتر سيبقى. قد تنتهي العملية الجارية الآن قبل الإيقاف.')) { await account.request('POST', '/v1/operations/batches/${b['id']}/cancel', body: {}); await _load(); } }), icon: const Icon(Icons.stop_circle_outlined), label: const Text('إيقاف المتبقي')),
      if ((b['ready'] as int? ?? 0) > 0) OutlinedButton.icon(onPressed: _busy ? null : () => _action(() => _mutation(() async { final result = await account.request('POST', '/v1/operations/batches/${b['id']}/print', body: {}); await _saveFile(result['filename'] as String, utf8.encode(result['html'] as String)); })), icon: const Icon(Icons.print_outlined), label: const Text('حفظ صفحة الطباعة')),
    ]),
  ])));
  Widget _portalCard() {
    final d = _portal?['design'] as Map?;
    return Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const Row(
        children: [
          Icon(Icons.preview_outlined),
          SizedBox(width: 10),
          Expanded(child: Text('تصميم صفحة الهوتسبوت')),
        ],
      ),
      if (d != null) ...[Text(d['title'] as String, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)), Text(d['welcome'] as String), const Text('اسم المستخدم  ─────────\nكلمة المرور  ─────────'), FilledButton(onPressed: null, child: const Text('دخول الشبكة — معاينة')), Text('☎ ${d['phone']}'), Text('نسخة ${_portal!['version']} · ${_portal!['approvedVersion'] == _portal!['version'] ? 'معتمدة للتصدير' : 'مسودة'}')],
      const Text('المعاينة داخل التطبيق تقريب للتصميم. احفظ معاينة HTML وافتحها لعرض الصفحة الفعلية قبل الاعتماد. تصدير ZIP لا ينشرها على الراوتر؛ تتطلب تجربة CHR مع HTTPS Hotspot.'),
      Wrap(spacing: 8, runSpacing: 8, children: [OutlinedButton(onPressed: _busy ? null : () => _action(_portalEdit), child: const Text('تحرير')), if (_portal != null) OutlinedButton(onPressed: _busy ? null : () => _action(_portalPreview), child: const Text('حفظ المعاينة ثم الاعتماد')), if (_portal?['approvedVersion'] != null && _portal?['approvedVersion'] == _portal?['version']) FilledButton(onPressed: _busy ? null : () => _action(() async { final result = await account.request('POST', '/v1/operations/portals/$_site/export', body: {}); await _saveFile(result['filename'] as String, base64Decode(result['base64'] as String)); }), child: const Text('تصدير ZIP المعتمد'))]),
    ])));
  }
}
