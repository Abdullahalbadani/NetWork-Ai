import 'package:flutter/material.dart';
import 'account_api.dart';
import 'account_views.dart';
import 'emergency_api.dart';
import 'markdown_view.dart';

class EmergencyAiDialog extends StatefulWidget {
  const EmergencyAiDialog({super.key, required this.account, required this.incidentId});
  final AccountController account;
  final String incidentId;
  @override
  State<EmergencyAiDialog> createState() => _EmergencyAiDialogState();
}
class _EmergencyAiDialogState extends State<EmergencyAiDialog> {
  Map<String, dynamic>? prepared, answer;
  String? error;
  bool loading = false, sharing = false;
  int epoch = 0;
  @override
  void initState() { super.initState(); prepare(); }
  @override
  void dispose() { epoch++; super.dispose(); }
  Future<void> prepare() async {
    final current = ++epoch;
    setState(() { loading = true; error = null; sharing = false; answer = null; });
    try { final value = await EmergencyApi(widget.account).get('incidents/${widget.incidentId}/ai-context'); if (mounted && current == epoch) setState(() => prepared = value); }
    catch (e) { if (mounted && current == epoch) setState(() { error = accountError(e); prepared = null; }); }
    finally { if (mounted && current == epoch) setState(() => loading = false); }
  }
  Future<void> send() async {
    if (!sharing || loading || prepared == null || prepared!['available'] != true) return;
    final current = ++epoch, hash = prepared!['hash'];
    setState(() { loading = true; error = null; });
    try {
      final value = await EmergencyApi(widget.account).post('incidents/${widget.incidentId}/ai-explanation', {'share': true, 'contextHash': hash});
      if (value['source'] != 'gemini' || value['routerWrite'] != false || value['deviceAccess'] != false || value['contextHash'] != hash || value['text'] is! String) throw const AccountFailure('invalid_response', 502);
      if (mounted && current == epoch) setState(() => answer = value);
    } catch (e) { if (mounted && current == epoch) setState(() { error = accountError(e); if (e is AccountFailure && [401, 403, 404].contains(e.status)) { prepared = null; answer = null; } }); }
    finally { if (mounted && current == epoch) setState(() => loading = false); }
  }
  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('تحليل العطل وخطة المعالجة'),
    content: SizedBox(width: 750, child: ConstrainedBox(constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(context).height * 0.65), child: SingleChildScrollView(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      if (loading) const LinearProgressIndicator(),
      if (error != null) ...[Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)), const SizedBox(height: 10), OutlinedButton.icon(onPressed: loading ? null : prepare, icon: const Icon(Icons.refresh), label: const Text('تحديث الأدلة وإعادة المحاولة'))],
      if (answer == null && prepared != null) ...[
        const Text('راجع بيانات هذا العطل قبل إرسالها إلى Google. يُستخدم اتصال الإنترنت عند الإرسال، ويُعاد استخدام الشرح المحفوظ للنتائج نفسها.'),
        const SizedBox(height: 12), Text('وقت الدليل: ${emergencyTime(prepared!['observedAt'])}'),
        const SizedBox(height: 12), ExpansionTile(tilePadding: EdgeInsets.zero, title: const Text('معاينة النص والبيانات التي ستُرسل'), children: [Padding(padding: const EdgeInsets.all(12), child: SelectableText('${prepared!['text']}'))]),
        const SizedBox(height: 12),
        if (prepared!['available'] != true) const Text('المساعد غير مهيأ في الخادم حاليًا. تبقى الأدلة والفحص والمعالجة المعتمدة متاحة.'),
        CheckboxListTile(key: const Key('emergency-ai-consent'), contentPadding: EdgeInsets.zero, title: const Text('أوافق على إرسال البيانات المعروضة إلى Google لشرح العطل.'), value: sharing, onChanged: loading || prepared!['available'] != true ? null : (v) => setState(() => sharing = v == true)),
      ],
      if (answer != null) ...[
        Text(answer!['cached'] == true ? 'شرح محفوظ لنفس النتائج' : 'شرح Gemini', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8), Text('وقت الشرح: ${emergencyTime(answer!['generatedAt'])}'),
        const SizedBox(height: 16), MarkdownView(text: '${answer!['text']}'),
        if (answer!['truncated'] == true) const Padding(padding: EdgeInsets.only(top: 10), child: Text('بلغ الشرح حد النص المتاح؛ قد لا يكون مكتملًا.')),
        const SizedBox(height: 16), const Text('لم يُنفّذ هذا التحليل تغييرًا على الراوتر. المعاينة التالية تعرض الهدف والقيم والأثر؛ التنفيذ يحتاج اعتمادك ثم يتحقق التطبيق من النتيجة.'),
        if (widget.account.canManage) ...[
          for (final action in emergencyRows(answer!['actions'])) Padding(padding: const EdgeInsets.only(top: 12), child: OutlinedButton.icon(onPressed: () => Navigator.pop(context, '${action['kind']}'), icon: const Icon(Icons.preview_outlined), label: Text('معاينة ${action['title']}'))),
        ],
        if (emergencyRows(answer!['actions']).isEmpty) const Padding(padding: EdgeInsets.only(top: 10), child: Text('لهذا العطل خطوات تشخيص أو معالجة ميدانية؛ لا توجد له كتابة تلقائية معتمدة.')),
      ],
    ])))),
    actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('عودة')),
      if (answer == null) FilledButton.icon(key: const Key('emergency-ai-send'), onPressed: loading || !sharing || prepared?['available'] != true ? null : send, icon: const Icon(Icons.auto_awesome_outlined), label: Text(loading ? 'جارٍ التحليل…' : 'إرسال للتحليل')),
    ],
  );
}
