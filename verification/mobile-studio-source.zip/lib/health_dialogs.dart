import 'package:flutter/material.dart';
import 'account_api.dart';
import 'account_views.dart' show accountError;
import 'health_api.dart';
import 'markdown_view.dart';
import 'status_pill.dart';
import 'ui.dart';

SignalTone findingTone(String value) => switch (value) {
  'pass' => SignalTone.success,
  'warning' => SignalTone.warning,
  'high' => SignalTone.high,
  'critical' => SignalTone.critical,
  _ => SignalTone.unknown,
};
String findingLabel(String value) => switch (value) {
  'pass' => 'نجح الفحص',
  'warning' => 'تحتاج مراجعة',
  'high' => 'خطر مرتفع',
  'critical' => 'حرج',
  _ => 'غير معروف',
};

Future<void> showFinding(
  BuildContext context,
  Map<String, dynamic> finding,
) => showDialog<void>(
  context: context,
  builder: (context) => _HealthDialog(
    title: finding['title'] as String,
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        StatusPill(
          tone: findingTone(finding['state'] as String),
          label: findingLabel(finding['state'] as String),
        ),
        const SizedBox(height: 20),
        Text(
          finding['summary'] as String,
          style: Theme.of(context).textTheme.bodyLarge,
        ),
        const SizedBox(height: 24),
        const Text('الدليل', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 10),
        if ((finding['evidence'] as List).isEmpty)
          const Text('لم تتوفر بيانات قياس كافية لهذا الاختبار.'),
        for (final row in finding['evidence'] as List)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: SelectableText('${row['label']}: ${row['value']}'),
          ),
        const Divider(),
        const SizedBox(height: 14),
        const Text(
          'الخطوة المقترحة',
          style: TextStyle(fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 8),
        Text(finding['recommendation'] as String),
        const SizedBox(height: 24),
        Text(
          finding['observedAt'] == null
              ? 'وقت القياس: غير متاح'
              : 'وقت القياس: ${localTimestamp(finding['observedAt'] as String)}',
        ),
        const SizedBox(height: 8),
        SelectableText(
          'المصدر: ${finding['source']}',
          style: Theme.of(context).textTheme.bodySmall,
        ),
      ],
    ),
  ),
);

class _HealthDialog extends StatelessWidget {
  const _HealthDialog({
    required this.title,
    required this.child,
    this.actions = const [],
  });
  final String title;
  final Widget child;
  final List<Widget> actions;
  @override
  Widget build(BuildContext context) => Dialog(
    insetPadding: const EdgeInsets.all(18),
    child: ConstrainedBox(
      constraints: BoxConstraints(
        maxWidth: 740,
        maxHeight: MediaQuery.sizeOf(context).height - 70,
      ),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    title,
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                ),
                IconButton(
                  tooltip: 'إغلاق',
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close),
                ),
              ],
            ),
            const SizedBox(height: 18),
            Flexible(child: SingleChildScrollView(child: child)),
            if (actions.isNotEmpty) ...[
              const SizedBox(height: 20),
              Wrap(spacing: 10, runSpacing: 10, children: actions),
            ],
          ],
        ),
      ),
    ),
  );
}

Future<bool> confirmHealthIdentity(
  BuildContext context,
  AccountController account,
) async {
  final code = TextEditingController();
  try {
    return await showDialog<bool>(
          context: context,
          builder: (context) => _IdentityDialog(account: account, code: code),
        ) ??
        false;
  } finally {
    code.dispose();
  }
}

class _IdentityDialog extends StatefulWidget {
  const _IdentityDialog({required this.account, required this.code});
  final AccountController account;
  final TextEditingController code;
  @override
  State<_IdentityDialog> createState() => _IdentityDialogState();
}

class _IdentityDialogState extends State<_IdentityDialog> {
  bool busy = false;
  String? error;
  @override
  Widget build(BuildContext context) => _HealthDialog(
    title: 'تأكيد هويتك',
    actions: [
      FilledButton(
        onPressed: busy
            ? null
            : () async {
                setState(() {
                  busy = true;
                  error = null;
                });
                try {
                  await widget.account.stepUp(widget.code.text.trim());
                  if (context.mounted) Navigator.pop(context, true);
                } catch (e) {
                  if (mounted) {
                    setState(() {
                      error = accountError(e);
                      busy = false;
                    });
                  }
                }
              },
        child: Text(busy ? 'جارٍ التحقق…' : 'تأكيد'),
      ),
    ],
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Text('أدخل رمز المصادقة الحديث لحفظ إعدادات الفحص.'),
        const SizedBox(height: 18),
        TextField(
          controller: widget.code,
          keyboardType: TextInputType.number,
          textDirection: TextDirection.ltr,
          maxLength: 6,
          decoration: const InputDecoration(labelText: 'رمز تطبيق المصادقة'),
          enabled: !busy,
        ),
        if (error != null)
          Text(
            error!,
            style: TextStyle(color: Theme.of(context).colorScheme.error),
          ),
      ],
    ),
  );
}

Future<bool> editHealthProfile(
  BuildContext context,
  HealthApi api,
  Map<String, dynamic> profile,
  List<Map<String, dynamic>> interfaces,
) async =>
    await showDialog<bool>(
      context: context,
      builder: (context) =>
          _ProfileDialog(api: api, profile: profile, interfaces: interfaces),
    ) ??
    false;

class _ProfileDialog extends StatefulWidget {
  const _ProfileDialog({
    required this.api,
    required this.profile,
    required this.interfaces,
  });
  final HealthApi api;
  final Map<String, dynamic> profile;
  final List<Map<String, dynamic>> interfaces;
  @override
  State<_ProfileDialog> createState() => _ProfileDialogState();
}

class _ProfileDialogState extends State<_ProfileDialog> {
  late final List<Map<String, dynamic>> links;
  bool busy = false;
  String? error;
  static const roles = {
    'other': 'غير محدد',
    'wan': 'إنترنت WAN',
    'lan': 'داخلية LAN',
    'management': 'إدارة',
    'uplink': 'ربط رئيسي',
  };
  @override
  void initState() {
    super.initState();
    final saved = (widget.profile['links'] as List)
        .cast<Map<String, dynamic>>();
    final names = {
      ...widget.interfaces.map((v) => v['name'] as String),
      ...saved.map((v) => v['name'] as String),
    };
    links = [
      for (final name in names)
        Map<String, dynamic>.of(
          saved.where((v) => v['name'] == name).firstOrNull ??
              {'name': name, 'role': 'other', 'required': false},
        ),
    ];
  }

  Future<void> save() async {
    setState(() {
      busy = true;
      error = null;
    });
    try {
      Future<void> action() async {
        final configured = links
            .where((v) => v['required'] == true || v['role'] != 'other')
            .toList();
        if (configured.length > 64) {
          throw const AccountFailure('health_profile_limit', 400);
        }
        await widget.api.saveProfile({
          'version': widget.profile['version'],
          'links': configured,
        });
      }

      try {
        await action();
      } on AccountFailure catch (e) {
        if (e.code != 'step_up_required') rethrow;
        if (!mounted ||
            !await confirmHealthIdentity(context, widget.api.account)) {
          return;
        }
        await action();
      }
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) setState(() => error = accountError(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => _HealthDialog(
    title: 'أدوار الواجهات والروابط المطلوبة',
    actions: [
      FilledButton(
        onPressed: busy || links.isEmpty ? null : save,
        child: Text(busy ? 'جارٍ الحفظ…' : 'حفظ إعدادات الفحص'),
      ),
    ],
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Text(
          'هذه إعدادات للفحص داخل التطبيق. حدّد دور كل واجهة، وهل تتوقع أن تكون عاملة. اختيار WAN لا يجري اختبار إنترنت.',
        ),
        const SizedBox(height: 20),
        if (links.isEmpty)
          const Text('ابدأ فحصًا أولًا للحصول على أسماء الواجهات.'),
        for (final row in links)
          Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Row(
                    children: [
                      const Icon(Icons.settings_ethernet),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          row['name'] as String,
                          style: const TextStyle(fontFamily: 'JetBrainsMono'),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String>(
                    initialValue: row['role'] as String,
                    decoration: const InputDecoration(labelText: 'دور الواجهة'),
                    items: [
                      for (final role in roles.entries)
                        DropdownMenuItem(
                          value: role.key,
                          child: Text(role.value),
                        ),
                    ],
                    onChanged: busy
                        ? null
                        : (v) => setState(() => row['role'] = v!),
                  ),
                  CheckboxListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('أتوقع أن يكون هذا الرابط عاملًا'),
                    value: row['required'] as bool,
                    onChanged: busy
                        ? null
                        : (v) => setState(() => row['required'] = v!),
                  ),
                ],
              ),
            ),
          ),
        if (error != null)
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Text(
              error!,
              style: TextStyle(color: Theme.of(context).colorScheme.error),
            ),
          ),
      ],
    ),
  );
}

Future<void> compareHealthReports(
  BuildContext context,
  HealthScan first,
  HealthScan second,
) => showDialog<void>(
  context: context,
  builder: (context) => _HealthDialog(
    title: 'مقارنة الفحصين',
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          'الأول: ${localTimestamp(first.report!['completedAt'] as String)}',
        ),
        Text(
          'الثاني: ${localTimestamp(second.report!['completedAt'] as String)}',
        ),
        const SizedBox(height: 14),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: DataTable(
            columnSpacing: 16,
            horizontalMargin: 0,
            columns: const [
              DataColumn(label: Text('القياس')),
              DataColumn(label: Text('الأول')),
              DataColumn(label: Text('الثاني')),
            ],
            rows: [
              for (final entry in [
                ('cpuLoad', 'المعالج', '%'),
                ('freeMemory', 'ذاكرة متاحة', ' B'),
                ('freeHddSpace', 'تخزين متاح', ' B'),
              ])
                DataRow(
                  cells: [
                    DataCell(Text(entry.$2)),
                    DataCell(
                      Text(
                        first.report!['resources']?[entry.$1] == null
                            ? 'غير معروف'
                            : '${first.report!['resources'][entry.$1]}${entry.$3}',
                        textDirection: TextDirection.ltr,
                      ),
                    ),
                    DataCell(
                      Text(
                        second.report!['resources']?[entry.$1] == null
                            ? 'غير معروف'
                            : '${second.report!['resources'][entry.$1]}${entry.$3}',
                        textDirection: TextDirection.ltr,
                      ),
                    ),
                  ],
                ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        if (first.report!['profile']['version'] !=
            second.report!['profile']['version'])
          const Padding(
            padding: EdgeInsets.only(bottom: 16),
            child: Text(
              'تغيرت إعدادات الفحص بين التقريرين. راعِ هذا الاختلاف عند المقارنة.',
            ),
          ),
        for (final row in second.findings)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  row['title'] as String,
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 9),
                Wrap(
                  spacing: 12,
                  runSpacing: 8,
                  children: [
                    StatusPill(
                      tone: findingTone(
                        first.findings.firstWhere(
                              (v) => v['id'] == row['id'],
                            )['state']
                            as String,
                      ),
                      label:
                          'الأول: ${findingLabel(first.findings.firstWhere((v) => v['id'] == row['id'])['state'] as String)}',
                    ),
                    StatusPill(
                      tone: findingTone(row['state'] as String),
                      label: 'الثاني: ${findingLabel(row['state'] as String)}',
                    ),
                  ],
                ),
                Text(
                  'الأول: ${first.findings.firstWhere((v) => v['id'] == row['id'])['summary']}',
                ),
                Text('الثاني: ${row['summary']}'),
              ],
            ),
          ),
      ],
    ),
  ),
);

class HealthExplanation extends StatefulWidget {
  const HealthExplanation({
    super.key,
    required this.scan,
    required this.account,
  });
  final HealthScan scan;
  final AccountController account;
  @override
  State<HealthExplanation> createState() => _HealthExplanationState();
}

class _HealthExplanationState extends State<HealthExplanation> {
  late final Set<String> selected = widget.scan.findings
      .where((v) => v['state'] != 'pass')
      .map((v) => v['id'] as String)
      .toSet();
  String? answer, error;
  bool busy = false, truncated = false;
  Future<void> send() async {
    setState(() {
      busy = true;
      error = null;
    });
    try {
      final result = await widget.account.request(
        'POST',
        '/v1/chat',
        body: {
          'messages': [
            {'role': 'user', 'text': explanationPrompt(widget.scan, selected)},
          ],
        },
      );
      if (result['text'] is! String ||
          (result['text'] as String).length > 30000) {
        throw const AccountFailure('invalid_response', 502);
      }
      if (mounted) {
        setState(() {
          answer = result['text'] as String;
          truncated = result['truncated'] == true;
        });
      }
    } catch (e) {
      if (mounted) setState(() => error = accountError(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => _HealthDialog(
    title: 'شرح نتائج الفحص',
    actions: [
      if (answer == null)
        FilledButton.icon(
          onPressed: busy || selected.isEmpty ? null : send,
          icon: const Icon(Icons.auto_awesome_outlined),
          label: Text(busy ? 'جارٍ طلب الشرح…' : 'إرسال للشرح'),
        ),
      if (answer != null)
        OutlinedButton.icon(
          onPressed: () => copyText(context, answer!),
          icon: const Icon(Icons.copy),
          label: const Text('نسخ الشرح'),
        ),
    ],
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (answer != null) ...[
          MarkdownView(text: answer!),
          if (truncated)
            const Padding(
              padding: EdgeInsets.only(top: 14),
              child: StatusPill(
                tone: SignalTone.warning,
                label: 'الشرح غير مكتمل؛ بلغ حد النص المتاح.',
              ),
            ),
        ] else ...[
          const Text(
            'اختر النتائج التي تريد شرحها. سترسل البيانات المعروضة أدناه إلى Google عند الضغط على إرسال؛ يتطلب ذلك اتصالًا بالإنترنت.',
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final row in widget.scan.findings)
                FilterChip(
                  label: Text(row['title'] as String),
                  selected: selected.contains(row['id']),
                  onSelected: busy
                      ? null
                      : (v) => setState(() {
                          if (v) {
                            selected.add(row['id'] as String);
                          } else {
                            selected.remove(row['id']);
                          }
                        }),
                ),
            ],
          ),
          const SizedBox(height: 18),
          ExpansionTile(
            title: const Text('معاينة النص والبيانات التي ستُرسل'),
            children: [
              Padding(
                padding: const EdgeInsets.all(12),
                child: SelectableText(explanationPrompt(widget.scan, selected)),
              ),
            ],
          ),
        ],
        if (busy)
          const Padding(
            padding: EdgeInsets.all(18),
            child: LinearProgressIndicator(),
          ),
        if (error != null)
          Padding(
            padding: const EdgeInsets.only(top: 16),
            child: Text(
              error!,
              style: TextStyle(color: Theme.of(context).colorScheme.error),
            ),
          ),
      ],
    ),
  );
}
