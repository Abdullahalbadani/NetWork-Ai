import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'ui.dart';

// Render a bounded Markdown subset as Flutter text. No HTML, image loading,
// JavaScript, executable code blocks or automatic navigation to model links.
class MarkdownView extends StatelessWidget {
  const MarkdownView({super.key, required this.text});
  final String text;

  static final _fence = String.fromCharCodes([96, 96, 96]);
  static final _inline = RegExp(
    r'\*\*([^*]+)\*\*|\x60([^\x60]+)\x60|\*([^*\n]+)\*|\[([^\]]+)\]\((https?://[^)\s]+)\)',
  );
  static final _heading = RegExp(r'^(#{1,6})\s+(.+)$');
  static final _bullet = RegExp(r'^(?:[-*]|\d+[.)])\s+(.+)$');

  static List<InlineSpan> spans(BuildContext context, String source) {
    final scheme = Theme.of(context).colorScheme;
    final result = <InlineSpan>[];
    var cursor = 0;
    for (final match in _inline.allMatches(source)) {
      if (match.start > cursor) {
        result.add(TextSpan(text: source.substring(cursor, match.start)));
      }
      if (match.group(1) != null) {
        result.add(
          TextSpan(
            text: match.group(1),
            style: const TextStyle(fontWeight: FontWeight.w700),
          ),
        );
      } else if (match.group(2) != null) {
        result.add(
          TextSpan(
            text: match.group(2),
            style: TextStyle(
              fontFamily: 'JetBrainsMono',
              fontFamilyFallback: const ['Tajawal'],
              fontSize: 13,
              backgroundColor: scheme.primary.withValues(alpha: 0.09),
            ),
          ),
        );
      } else if (match.group(3) != null) {
        result.add(
          TextSpan(
            text: match.group(3),
            style: const TextStyle(fontStyle: FontStyle.italic),
          ),
        );
      } else {
        result.add(
          TextSpan(
            text: '${match.group(4)} (${match.group(5)})',
            style: TextStyle(color: scheme.primary),
          ),
        );
      }
      cursor = match.end;
    }
    if (cursor < source.length) {
      result.add(TextSpan(text: source.substring(cursor)));
    }
    return result;
  }

  static List<String> _cells(String line) {
    var value = line.trim();
    if (value.startsWith('|')) {
      value = value.substring(1);
    }
    if (value.endsWith('|')) {
      value = value.substring(0, value.length - 1);
    }
    return value.split('|').map((cell) => cell.trim()).take(8).toList();
  }

  static bool _separator(String line) {
    final cells = _cells(line);
    return cells.length >= 2 &&
        cells.every((cell) => RegExp(r'^:?-{3,}:?$').hasMatch(cell));
  }

  Widget _rich(BuildContext context, String source, {TextStyle? style}) {
    return Text.rich(
      TextSpan(children: spans(context, source)),
      style: style ?? Theme.of(context).textTheme.bodyLarge,
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final lines = text.replaceAll('\r\n', '\n').split('\n');
    final blocks = <Widget>[];
    var index = 0;
    while (index < lines.length && blocks.length < 160) {
      final line = lines[index].trim();
      if (line.isEmpty) {
        index++;
        continue;
      }
      if (line.startsWith(_fence)) {
        final language = line.substring(3).trim();
        final code = <String>[];
        index++;
        while (index < lines.length &&
            !lines[index].trim().startsWith(_fence)) {
          code.add(lines[index++]);
        }
        if (index < lines.length) {
          index++;
        }
        final value = code.join('\n');
        blocks.add(
          Container(
            margin: const EdgeInsets.only(bottom: 14),
            decoration: BoxDecoration(
              color: scheme.primary.withValues(alpha: 0.055),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: scheme.outlineVariant),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Padding(
                  padding: const EdgeInsetsDirectional.only(start: 14, end: 5),
                  child: Row(
                    children: [
                      const Icon(Icons.code, size: 17),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          language.isEmpty
                              ? 'نص برمجي'
                              : language.substring(
                                  0,
                                  math.min(language.length, 40),
                                ),
                          style: theme.textTheme.bodySmall,
                        ),
                      ),
                      IconButton(
                        tooltip: 'نسخ النص البرمجي',
                        onPressed: () => copyText(context, value),
                        icon: const Icon(Icons.copy_outlined, size: 17),
                      ),
                    ],
                  ),
                ),
                const Divider(),
                Directionality(
                  textDirection: TextDirection.ltr,
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.all(16),
                    child: Text(
                      value,
                      textDirection: TextDirection.ltr,
                      style: TextStyle(
                        fontFamily: 'JetBrainsMono',
                        fontFamilyFallback: const ['Tajawal'],
                        fontSize: 13,
                        height: 1.7,
                        color: scheme.onSurface,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
        continue;
      }
      if (index + 1 < lines.length &&
          line.contains('|') &&
          _separator(lines[index + 1])) {
        final header = _cells(line);
        final rows = <List<String>>[];
        index += 2;
        while (index < lines.length &&
            lines[index].trim().isNotEmpty &&
            lines[index].contains('|') &&
            rows.length < 30) {
          rows.add(_cells(lines[index++]));
        }
        Widget cell(String value, {bool heading = false}) => Padding(
          padding: const EdgeInsets.all(12),
          child: _rich(
            context,
            value,
            style: theme.textTheme.bodyMedium?.copyWith(
              fontWeight: heading ? FontWeight.w700 : FontWeight.w400,
            ),
          ),
        );
        blocks.add(
          Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: LayoutBuilder(
              builder: (context, constraints) {
                return SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: SizedBox(
                    width: math.max(
                      constraints.maxWidth,
                      header.length * 170.0,
                    ),
                    child: Table(
                      border: TableBorder.all(
                        color: scheme.outlineVariant,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      defaultVerticalAlignment: TableCellVerticalAlignment.top,
                      children: [
                        TableRow(
                          decoration: BoxDecoration(
                            color: scheme.primary.withValues(alpha: 0.06),
                          ),
                          children: header
                              .map((item) => cell(item, heading: true))
                              .toList(),
                        ),
                        for (final row in rows)
                          TableRow(
                            children: List.generate(
                              header.length,
                              (column) =>
                                  cell(column < row.length ? row[column] : ''),
                            ),
                          ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        );
        continue;
      }
      final heading = _heading.firstMatch(line);
      if (heading != null) {
        blocks.add(
          Padding(
            padding: const EdgeInsets.only(top: 6, bottom: 10),
            child: _rich(
              context,
              heading.group(2)!,
              style: theme.textTheme.titleMedium?.copyWith(
                fontSize: heading.group(1)!.length <= 2 ? 21 : 18,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        );
        index++;
        continue;
      }
      if (RegExp(r'^(?:-{3,}|\*{3,}|_{3,})$').hasMatch(line)) {
        blocks.add(
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 12),
            child: Divider(),
          ),
        );
        index++;
        continue;
      }
      final bullet = _bullet.firstMatch(line);
      if (bullet != null) {
        blocks.add(
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsetsDirectional.only(top: 10, end: 10),
                  child: Icon(Icons.circle, size: 5, color: scheme.primary),
                ),
                Expanded(child: _rich(context, bullet.group(1)!)),
              ],
            ),
          ),
        );
        index++;
        continue;
      }
      blocks.add(
        Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: _rich(
            context,
            line.startsWith('> ') ? line.substring(2) : line,
          ),
        ),
      );
      index++;
    }
    if (index < lines.length) {
      blocks.add(const Text('الرد طويل؛ يمكنك نسخه لقراءة النص كاملًا.'));
    }
    return SelectionArea(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: blocks,
      ),
    );
  }
}
