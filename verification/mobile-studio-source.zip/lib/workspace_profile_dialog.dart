import 'package:flutter/material.dart';
import 'account_api.dart';
import 'account_views.dart';
import 'emergency_common.dart';

class WorkspaceProfileDialog extends StatefulWidget {
  const WorkspaceProfileDialog({super.key, required this.account, required this.name, required this.version});
  final AccountController account;
  final String name;
  final int version;
  @override
  State<WorkspaceProfileDialog> createState() => _WorkspaceProfileDialogState();
}
class _WorkspaceProfileDialogState extends State<WorkspaceProfileDialog> {
  late final name = TextEditingController(text: widget.name);
  bool busy = false;
  String? error;
  @override
  void dispose() { name.dispose(); super.dispose(); }
  Future<void> save() async {
    final value = name.text.trim();
    if (value.isEmpty || value.length > 100) { setState(() => error = 'أدخل اسمًا من حرف إلى 100 حرف.'); return; }
    setState(() { busy = true; error = null; });
    try {
      await emergencyMutation(context, widget.account, () => widget.account.request('PATCH', '/v1/workspace-profile', body: {'name': value, 'version': widget.version}));
      await widget.account.loadProfile();
      if (mounted) Navigator.pop(context, true);
    } catch (e) { if (mounted) setState(() => error = accountError(e)); }
    finally { if (mounted) setState(() => busy = false); }
  }
  @override
  Widget build(BuildContext context) => AlertDialog(title: const Text('اسم الشبكة'), content: SizedBox(width: 440, child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    const Text('اسم مساحة الشبكة المعروض في الرئيسية والتنقل.'), const SizedBox(height: 16),
    TextField(controller: name, enabled: !busy, maxLength: 100, decoration: const InputDecoration(labelText: 'اسم الشبكة'), onSubmitted: (_) { if (!busy) save(); }),
    if (error != null) Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
    if (busy) const LinearProgressIndicator(),
  ])), actions: [TextButton(onPressed: busy ? null : () => Navigator.pop(context), child: const Text('عودة')), FilledButton(onPressed: busy ? null : save, child: const Text('حفظ اسم الشبكة'))]);
}
