package app.networkcopilot.mobile

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import java.io.File
import java.io.FileNotFoundException

class StudioFileProvider : ContentProvider() {
    override fun onCreate() = true
    private fun file(uri: Uri): File {
        val context = context ?: throw FileNotFoundException()
        val name = uri.lastPathSegment ?: throw FileNotFoundException()
        if (uri.authority != context.packageName + ".studio.files" || uri.pathSegments.size != 1 || !Regex("^copilot-cards-[a-f0-9-]{36}\\.pdf$").matches(name)) throw FileNotFoundException()
        val root = File(context.cacheDir, "studio-pdf").canonicalFile
        val target = File(root, name).canonicalFile
        if (target.parentFile != root || !target.isFile) throw FileNotFoundException()
        return target
    }
    override fun getType(uri: Uri): String { file(uri); return "application/pdf" }
    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        if(mode != "r") throw FileNotFoundException()
        return ParcelFileDescriptor.open(file(uri), ParcelFileDescriptor.MODE_READ_ONLY)
    }
    override fun query(uri: Uri, projection: Array<out String>?, selection: String?, selectionArgs: Array<out String>?, sortOrder: String?): Cursor {
        val target=file(uri)
        val columns = projection?.filter { it == OpenableColumns.DISPLAY_NAME || it == OpenableColumns.SIZE }?.toTypedArray() ?: arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE)
        return MatrixCursor(columns,1).apply { addRow(columns.map { if(it==OpenableColumns.DISPLAY_NAME) target.name else target.length() }.toTypedArray()) }
    }
    override fun insert(uri: Uri, values: ContentValues?): Uri? = throw UnsupportedOperationException()
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = throw UnsupportedOperationException()
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = throw UnsupportedOperationException()
}
