package app.networkcopilot.mobile

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.StandardMessageCodec
import io.flutter.plugin.platform.PlatformView
import io.flutter.plugin.platform.PlatformViewFactory
import org.json.JSONObject
import java.io.File

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(engine: FlutterEngine) {
        super.configureFlutterEngine(engine)
        engine.platformViewsController.registry.registerViewFactory("copilot/card-studio", StudioViewFactory(engine))
        MethodChannel(engine.dartExecutor.binaryMessenger, "copilot/studio-files").setMethodCallHandler { call, result ->
            if (call.method != "file") { result.notImplemented(); return@setMethodCallHandler }
            try {
                val name = call.argument<String>("filename") ?: throw IllegalArgumentException()
                val bytes = call.argument<ByteArray>("bytes") ?: throw IllegalArgumentException()
                val kind = call.argument<String>("kind") ?: throw IllegalArgumentException()
                if (!Regex("^copilot-cards-[a-f0-9-]{36}\\.pdf$").matches(name) || bytes.size > 24 * 1024 * 1024 || bytes.size < 5 || String(bytes.copyOfRange(0,5), Charsets.US_ASCII) != "%PDF-" || kind !in listOf("preview", "print", "share")) throw IllegalArgumentException()
                val folder = File(cacheDir, "studio-pdf").apply { mkdirs() }
                val oldFiles = folder.listFiles()?.sortedBy { it.lastModified() } ?: emptyList()
                var total = oldFiles.sumOf { it.length() }
                for (old in oldFiles) {
                    if (System.currentTimeMillis() - old.lastModified() > 30 * 60 * 1000 || total + bytes.size > 64 * 1024 * 1024) { val size = old.length(); if (old.delete()) total -= size }
                }
                val file = File(folder, name)
                file.outputStream().use { it.write(bytes) }
                val uri = Uri.parse("content://$packageName.studio.files/$name")
                val intent = if (kind == "share") Intent(Intent.ACTION_SEND).apply { type="application/pdf"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                else Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri, "application/pdf"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                startActivity(Intent.createChooser(intent, if(kind == "share") "مشاركة ملف الكروت" else "معاينة PDF والطباعة"))
                result.success(mapOf("opened" to true))
            } catch (_: Exception) { result.error("pdf_viewer_unavailable", "احفظ PDF وافتحه بعارض ملفات PDF.", null) }
        }
    }
}

private class StudioViewFactory(private val engine: FlutterEngine) : PlatformViewFactory(StandardMessageCodec.INSTANCE) {
    override fun create(context: Context, id: Int, args: Any?): PlatformView = StudioView(context, id, args as? Map<*,*>, engine)
}
private class StudioView(context: Context, id: Int, args: Map<*,*>?, engine: FlutterEngine) : PlatformView {
    private val web = WebView(context)
    private val main = Handler(Looper.getMainLooper())
    private var disposed = false
    private val channel = MethodChannel(engine.dartExecutor.binaryMessenger, "copilot/card-studio/$id")
    init {
        web.setBackgroundColor(android.graphics.Color.rgb(7,16,30))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = false
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = false
        web.settings.blockNetworkLoads = true
        web.settings.javaScriptCanOpenWindowsAutomatically = false
        web.settings.setSupportMultipleWindows(false)
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean = true
        }
        web.addJavascriptInterface(object {
            @JavascriptInterface fun postMessage(message: String) {
                if (disposed || message.length > 35000000) return
                main.post {
                    if (disposed) return@post
                    channel.invokeMethod("request", message, object: MethodChannel.Result {
                        override fun success(value: Any?) {
                            if (disposed) return
                            try {
                                val json = JSONObject(value as Map<*,*>).toString()
                                web.evaluateJavascript("window.studioReply($json)", null)
                            } catch (_: Exception) { }
                        }
                        override fun error(code: String, message: String?, details: Any?) { }
                        override fun notImplemented() { }
                    })
                }
            }
        }, "CopilotStudio")
        val html = args?.get("html") as? String ?: ""
        channel.setMethodCallHandler { call, result ->
            if(call.method == "ready" && !disposed && html.length <= 2000000) {
                web.loadDataWithBaseURL("https://studio.networkcopilot.invalid/", html, "text/html", "UTF-8", null)
                result.success(null)
            } else result.notImplemented()
        }
    }
    override fun getView(): View = web
    override fun dispose() { disposed=true; channel.setMethodCallHandler(null); web.removeJavascriptInterface("CopilotStudio"); web.stopLoading(); web.destroy() }
}
