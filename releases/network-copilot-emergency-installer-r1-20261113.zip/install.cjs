'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),os=require('node:os'),net=require('node:net'),zlib=require('node:zlib'),child=require('node:child_process');
const expectedPayload='751d4284d372bf74d76bca44117949382fba81a618c11010ae5fcaf728783b2a',expectedRunner='972a18dbea7290157bd50d871bf45337fd37d7a4e949301dc229fe206190c40a',expectedCompatibility='92c98e7157d836c9728896776ee65115b458b6c1733ac613ea103f0a0f43831f';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const canonical=b=>Buffer.from(b.toString('utf8').replace(/^\uFEFF/,'').replace(/\r\n/g,'\n'));
async function stopped(){
 const listening=await new Promise(resolve=>{const s=net.connect({host:'127.0.0.1',port:3443});s.setTimeout(1000);s.once('connect',()=>{s.destroy();resolve(true);});s.once('error',()=>resolve(false));s.once('timeout',()=>{s.destroy();resolve(true);});});
 if(listening)throw Error('SERVER_RUNNING: stop the server on 3443 before applying this update.');
}
async function main(){
 const args=process.argv.slice(2),codeOnly=args.includes('--code-only'),pos=args.filter(a=>a!=='--code-only');
 if(pos.length!==1||args.some(a=>a.startsWith('--')&&a!=='--code-only'))throw Error('Usage: node install.cjs "D:\\NetWork-Ai" [--code-only]');
 if(Number(process.versions.node.split('.')[0])<24)throw Error('Node 24 or newer is required.');
 const root=path.resolve(pos[0]);
 if(!fs.existsSync(root)||fs.lstatSync(root).isSymbolicLink())throw Error('EXISTING_PROJECT_REQUIRED');
 for(const marker of ['package.json','runtime/v06/package.json']){let current=root;for(const part of marker.split('/')){current=path.join(current,part);if(fs.lstatSync(current).isSymbolicLink())throw Error('UPDATE_SYMLINK_REFUSED');}}
 const metadata=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8').replace(/^\uFEFF/,''));
 const runtime=JSON.parse(fs.readFileSync(path.join(root,'runtime/v06/package.json'),'utf8').replace(/^\uFEFF/,''));
 if(metadata.name!=='network-copilot'||!['0.8.0','0.8.1'].includes(runtime.version))throw Error('CONFIRMED_080_R2_BASELINE_REQUIRED');
 const originalDelivery=path.resolve(__dirname,'..','copilot-emergency');
 const payloadPath=path.join(originalDelivery,'emergency-update.ncp'),runnerPath=path.join(originalDelivery,'apply-foundation-update.cjs'),compatPath=path.join(__dirname,'compatibility.json');
 for(const [file,hash]of [[payloadPath,expectedPayload],[runnerPath,expectedRunner],[compatPath,expectedCompatibility]]){
  const s=fs.lstatSync(file);if(!s.isFile()||s.isSymbolicLink()||s.size>32*1024*1024||sha(fs.readFileSync(file))!==hash)throw Error('DELIVERY_INTEGRITY_FAILED: '+path.basename(file));
 }
 const runner=require(runnerPath),compat=JSON.parse(fs.readFileSync(compatPath,'utf8')),observedPackageHashes=new Map();
 for(const item of compat.files){
  const target=runner.safePath(root,item.path);let bytes=null;
  if(fs.existsSync(target)){const s=fs.lstatSync(target);if(!s.isFile()||s.size>16*1024*1024)throw Error('INVALID_BASELINE_FILE: '+item.path);bytes=fs.readFileSync(target);}
  const hash=bytes?sha(item.binary?bytes:canonical(bytes)):null;
  if(item.path==='package.json'||item.path==='package-lock.json')observedPackageHashes.set(item.path,hash);
  let known=item.hashes.includes(hash);
  if(!known&&bytes&&item.path.endsWith('.dart')&&item.sourceHashes){try{known=item.sourceHashes.includes(runner.sourceHash(bytes));}catch{}}
  if(!known)throw Error('UNKNOWN_LOCAL_EDIT: '+item.path+'; no files were written.');
 }
 const ownerPackage=observedPackageHashes.get('package.json')==='a7f38c9b99e469fb7e7571be137e8e4126a78aaab1dfcc45a1a11386fee5c6d7',ownerLock=observedPackageHashes.get('package-lock.json')==='756b29ac8e0a48d72951da0782790b706006da5d8997cb904f334d5b2cd1bee5';
 if(ownerPackage!==ownerLock)throw Error('PACKAGE_PAIR_MISMATCH: package.json and package-lock.json must describe the same recognized TypeScript declaration; no files were written.');
 await stopped();
 // Pure preflight: validate every payload entry and current bytes before creating the install lock or backup.
 const compressed=fs.readFileSync(payloadPath),pkg=JSON.parse(zlib.brotliDecompressSync(compressed,{maxOutputLength:64*1024*1024}));
 for(const item of pkg.files){
  if(!runner.allowedPath(item.path)||sha(Buffer.from(item.content,'base64'))!==item.after)throw Error('INVALID_PAYLOAD_ENTRY');
 }
 const lockPath=path.join(root,'.copilot-integration.lock');let lock,temporary,result;
 try{
  lock=fs.openSync(lockPath,'wx',0o600);temporary=fs.mkdtempSync(path.join(os.tmpdir(),'copilot-emergency-'));
  const hex=path.join(temporary,'payload.hex');fs.writeFileSync(hex,compressed.toString('hex'),{flag:'wx',mode:0o600});
  result=runner.apply(root,hex,expectedPayload,()=>{});
  if(ownerPackage)console.log('Recognized existing TypeScript ^5.9.3 declaration; package.json and package-lock.json preserved byte-for-byte. No npm install.');
  if(result.changed){console.log('Emergency radar code installed. Files: '+result.changed);console.log('Code backup: '+result.backup);}
  else console.log('Emergency radar code is already installed.');
  if(codeOnly){console.log('CODE ONLY: database was not touched. Run runtime/v06/scripts/upgrade-emergency-foundation.mjs before starting the updated server.');return;}
  const migration=child.spawnSync(process.execPath,['--env-file-if-exists=.env',path.join(root,'runtime/v06/scripts/upgrade-emergency-foundation.mjs')],{cwd:root,stdio:'inherit',windowsHide:true});
  if(migration.error||migration.status!==0){console.error('DATABASE UPGRADE INCOMPLETE. Keep the server stopped. Preserve the code backup and encrypted backup. Rerun this installer after correcting the reported readiness issue; it is safe to retry. Code was not automatically rolled back because schema 4 might already be committed.');process.exitCode=1;return;}
  console.log('Update ready: runtime/v06, version 0.8.1, schema 4. Accounts, MFA, private settings, signing and existing caches preserved. No RouterOS command was executed.');
 }finally{
  if(temporary)fs.rmSync(temporary,{recursive:true,force:true});
  if(lock!==undefined){fs.closeSync(lock);fs.unlinkSync(lockPath);}
 }
}
main().catch(e=>{console.error('Update stopped: '+(e.code==='EEXIST'?'INSTALL_LOCK_EXISTS: another installer may be active. Inspect .copilot-integration.lock before recovery.':e.message));process.exitCode=1;});
