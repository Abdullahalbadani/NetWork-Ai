'use strict';
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),zlib=require('node:zlib'),child=require('node:child_process');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),textBytes=b=>Buffer.from(b.toString('utf8').replace(/^\uFEFF/,'').replace(/\r\n/g,'\n')),fail=message=>{throw Error(message);};
const expectedMetadata='dd24219053622d56732c766a8378c50c7193b3eba7ab7ddfe89a762fc51d0988';
function tokenize(value) {
  const source = textBytes(value).toString('utf8');
  const tokens = [];
  let i = 0;
  const identifierStart = /[A-Za-z_$\p{L}]/u;
  const identifierPart = /[A-Za-z0-9_$\p{L}\p{N}]/u;
  const operators = [
    '>>>=', '...?', '~/=', '>>>', '??=', '<<=', '>>=', '...', '?..',
    '==', '!=', '<=', '>=', '&&', '||', '++', '--', '+=', '-=', '*=',
    '/=', '%=', '&=', '|=', '^=', '<<', '>>', '??', '?.', '=>', '..', '~/',
  ];
  function comment() {
    const start = i;
    if (source.startsWith('//', i)) {
      const end = source.indexOf('\n', i);
      i = end < 0 ? source.length : end;
    } else {
      let depth = 1;
      i += 2;
      while (i < source.length && depth) {
        if (source.startsWith('/*', i)) { depth++; i += 2; }
        else if (source.startsWith('*/', i)) { depth--; i += 2; }
        else i++;
      }
      if (depth) fail('INVALID_DART_SOURCE');
    }
    return source.slice(start, i);
  }
  function isString() {
    return source[i] === '"' || source[i] === "'" ||
      (source[i] === 'r' && (source[i + 1] === '"' || source[i + 1] === "'"));
  }
  function interpolation() {
    let depth = 1;
    i += 2;
    while (i < source.length && depth) {
      if (isString()) quoted();
      else if (source.startsWith('//', i) || source.startsWith('/*', i)) comment();
      else if (source[i] === '{') { depth++; i++; }
      else if (source[i] === '}') { depth--; i++; }
      else i++;
    }
    if (depth) fail('INVALID_DART_SOURCE');
  }
  function quoted() {
    const start = i;
    const raw = source[i] === 'r';
    if (raw) i++;
    const quote = source[i];
    const delimiter = source.startsWith(quote.repeat(3), i) ? quote.repeat(3) : quote;
    i += delimiter.length;
    while (i < source.length) {
      if (source.startsWith(delimiter, i)) {
        i += delimiter.length;
        return source.slice(start, i);
      }
      if (!raw && source[i] === '\\') i += 2;
      else if (!raw && source[i] === '$' && source[i + 1] === '{') interpolation();
      else i++;
    }
    fail('INVALID_DART_SOURCE');
  }
  while (i < source.length) {
    if (/\s/.test(source[i])) { i++; continue; }
    if (isString()) { tokens.push(['string', quoted()]); continue; }
    if (source.startsWith('//', i) || source.startsWith('/*', i)) {
      tokens.push(['comment', comment()]); continue;
    }
    if (identifierStart.test(source[i])) {
      const start = i++;
      while (i < source.length && identifierPart.test(source[i])) i++;
      tokens.push(['identifier', source.slice(start, i)]); continue;
    }
    if (/[0-9]/.test(source[i])) {
      const number = source.slice(i).match(/^(?:0[xX][0-9a-fA-F]+|[0-9]+(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?)/)[0];
      tokens.push(['number', number]); i += number.length; continue;
    }
    const operator = operators.find(item => source.startsWith(item, i));
    tokens.push(['punctuation', operator || source[i]]);
    i += operator ? operator.length : 1;
  }
  return tokens;
}
function ordered(v){if(Array.isArray(v))return v.map(ordered);if(v&&typeof v==='object')return Object.fromEntries(Object.keys(v).sort().map(k=>[k,ordered(v[k])]));return v;}
const jsonHash=v=>sha(JSON.stringify(ordered(v)));
function safe(root,relative){if(typeof relative!=='string'||relative.includes('\\')||relative.includes(':')||relative.split('/').some(p=>!p||p==='.'||p==='..'))fail('unsafe_reference_path');let p=root;for(const part of relative.split('/')){p=path.join(p,part);if(fs.existsSync(p)&&fs.lstatSync(p).isSymbolicLink())fail('symlink_refused');}return p;}
function jsonFields(v,base='',out={}){if(v&&typeof v==='object'){const keys=Object.keys(v);for(const k of keys.sort())jsonFields(v[k],base?base+'.'+k:k,out);if(!keys.length)out[base]=jsonHash(v);}else out[base]=jsonHash(v);return out;}
function fieldDifferences(before,after){const out=[];for(const k of [...new Set([...Object.keys(before??{}),...Object.keys(after)])].sort()){if(before?.[k]!==after[k]){out.push({field:k,kind:!Object.hasOwn(before??{},k)?'added':!Object.hasOwn(after,k)?'removed':'changed'});if(out.length>=40)break;}}return out;}
function localReference(root,item,metadata){const folder=path.dirname(root),candidates=[path.join(folder,'copilot-ui-r2','ui-update.ncp'),path.join(folder,'copilot-integration-r2','ui-update.ncp')];for(const file of candidates){try{const stat=fs.lstatSync(file);if(!stat.isFile()||stat.isSymbolicLink()||stat.size>1024*1024)continue;const b=fs.readFileSync(file);if(sha(b)!==metadata.localR2PayloadSha256)continue;const data=JSON.parse(zlib.brotliDecompressSync(b,{maxOutputLength:4*1024*1024})),row=data.files.find(f=>f.path===item.path);if(!row||!item.hashes.includes(row.after))continue;const content=Buffer.from(row.content,'base64');if(sha(content)===row.after)return content;}catch{}}return null;}
function lockGraph(lock){const packages=lock?.packages;if(!packages||typeof packages!=='object'||Array.isArray(packages))return null;return Object.fromEntries(Object.keys(packages).sort().map(k=>{const p=packages[k];return[k,{version:p?.version??null,integrity:p?.integrity??null,resolved:p?.resolved??null,link:p?.link??false,dependencies:p?.dependencies??null,optionalDependencies:p?.optionalDependencies??null,peerDependencies:p?.peerDependencies??null,peerDependenciesMeta:p?.peerDependenciesMeta??null,engines:p?.engines??null,os:p?.os??null,cpu:p?.cpu??null,libc:p?.libc??null,hasInstallScript:p?.hasInstallScript??false}];}));}
function dartPath(root){try{const local=fs.readFileSync(safe(root,'apps/mobile/android/local.properties'),'utf8'),line=local.split(/\r?\n/).find(v=>v.startsWith('flutter.sdk='));if(!line)return null;const sdk=line.slice(12).replace(/\\([\\: ])/g,'$1');for(const name of [path.join(sdk,'bin','cache','dart-sdk','bin','dart.exe'),path.join(sdk,'bin','cache','dart-sdk','bin','dart')])if(fs.existsSync(name)&&fs.statSync(name).isFile())return name;}catch{}return null;}
function formattedComparison(executable,reference,actual){if(!executable)return{available:false,reason:'existing_cached_Dart_not_found'};let dir;
 try{dir=fs.mkdtempSync(path.join(os.tmpdir(),'copilot-format-inspect-'));const file=path.join(dir,'input.dart');fs.writeFileSync(path.join(dir,'pubspec.yaml'),"name: copilot_format_inspect\nenvironment:\n  sdk: '>=3.12.0 <4.0.0'\n");
  const run=b=>{fs.writeFileSync(file,b);const r=child.spawnSync(executable,['format','--output=show','--summary=none',file],{cwd:dir,encoding:'utf8',timeout:15000,maxBuffer:4*1024*1024,windowsHide:true,env:{...process.env,DART_SUPPRESS_ANALYTICS:'true',FLUTTER_SUPPRESS_ANALYTICS:'true',CI:'true'}});if(r.error||r.status!==0)return null;return sha(textBytes(Buffer.from(r.stdout)));};
  const before=run(reference),after=run(actual);return{available:true,executed:before!==null&&after!==null,equal:before!==null&&after!==null&&before===after,referenceFormattedSha256:before,currentFormattedSha256:after};
 }catch{return{available:true,executed:false,reason:'formatter_inspection_failed'};}finally{if(dir)fs.rmSync(dir,{recursive:true,force:true});}}
function inspect(rootArg){
 if(!rootArg)fail('Usage: node inspect.cjs "D:\\NetWork-Ai"');const root=path.resolve(rootArg);if(!fs.existsSync(root)||!fs.statSync(root).isDirectory()||fs.lstatSync(root).isSymbolicLink())fail('existing_project_required');
 const metadataPath=path.join(__dirname,'expected-hashes.json'),rawMetadata=fs.readFileSync(metadataPath);if(sha(rawMetadata)!==expectedMetadata)fail('metadata_integrity_failed');const metadata=JSON.parse(rawMetadata),{compat}=metadata;
 const exe=dartPath(root),report={mode:'READ_ONLY_PROJECT',baseline:'0.8.0 + UI R2',checked:0,conflicts:[]};
 for(const item of compat.files){report.checked++;let bytes,hash,sourceHash;try{const target=safe(root,item.path);if(fs.existsSync(target)){const s=fs.statSync(target);if(!s.isFile()||s.size>16*1024*1024){report.conflicts.push({path:item.path,reason:'invalid_file_type_or_size'});continue;}bytes=fs.readFileSync(target);}else bytes=null;hash=bytes?sha(item.binary?bytes:textBytes(bytes)):null;if(bytes&&item.path.endsWith('.dart')){try{sourceHash=sha(JSON.stringify(tokenize(bytes)));}catch{}}
  if(item.hashes.includes(hash)||sourceHash&&item.sourceHashes?.includes(sourceHash))continue;
  const row={path:item.path,bytes:bytes?.length??null,sha256:hash,...(sourceHash?{sourceHash}:{}),reason:bytes?'unrecognized_content':'missing_file'};
  const expectedJson=metadata.json[item.path],reference=item.path.endsWith('.dart')?localReference(root,item,metadata):null;
  if(bytes&&expectedJson&&item.path.endsWith('.json')){try{const actual=JSON.parse(textBytes(bytes).toString('utf8'));row.json={sameContent:jsonHash(actual)===expectedJson.canonicalSha256,canonicalSha256:jsonHash(actual),referenceCanonicalSha256:expectedJson.canonicalSha256,differences:expectedJson.fields?fieldDifferences(expectedJson.fields,jsonFields(actual)):[]};
    if(item.path.endsWith('lock.json')){const a=lockGraph(actual);row.lock={lockfileVersion:actual.lockfileVersion??null,packageCount:a?Object.keys(a).length:null,referencePackageCount:expectedJson.packageCount??null,sameResolutionGraph:a!==null&&jsonHash(a)===expectedJson.resolutionGraphSha256,resolutionGraphSha256:a?jsonHash(a):null,referenceResolutionGraphSha256:expectedJson.resolutionGraphSha256??null,rootDependenciesSame:jsonHash(actual.packages?.['']??null)===expectedJson.rootRecordSha256};}
   }catch{row.json={valid:false};}}
  if(bytes&&item.path.endsWith('.dart'))row.cachedDartFormatter=reference?formattedComparison(exe,reference,bytes):{available:Boolean(exe),executed:false,reason:'local_R2_reference_not_found'};
  report.conflicts.push(row);
 }catch(e){report.conflicts.push({path:item.path,reason:['symlink_refused','unsafe_reference_path'].includes(e.message)?e.message:'read_failed'});}}
 report.conflictCount=report.conflicts.length;return report;
}
if(require.main===module){try{if(process.argv.length!==3)fail('Usage: node inspect.cjs project');console.log(JSON.stringify(inspect(process.argv[2]),null,2));}catch(e){console.error('Inspection stopped: '+e.message);process.exitCode=1;}}
module.exports={inspect,jsonHash,jsonFields,fieldDifferences,lockGraph,formattedComparison};
