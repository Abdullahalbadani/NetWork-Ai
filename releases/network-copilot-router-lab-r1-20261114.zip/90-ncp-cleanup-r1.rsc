# Remove only exact owned lab objects. App history and backup stay intact.
{
    {
        :local item [/ip hotspot user profile find where name="ncp-lab-main-v1"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_PROFILE" }
        :if ([:len $item] = 1) do={
            :if ([:tostr [/ip hotspot user profile get $item on-logout]] != "# NCP-LAB-V1-20261114") do={
                :put ("NCP_LAB_PROFILE_DIAG profile=ncp-lab-main-v1 field=on-logout type=" . [:typeof [/ip hotspot user profile get $item on-logout]] . " text-length=" . [:len [:tostr [/ip hotspot user profile get $item on-logout]]])
                :error "PROFILE_PROPERTY_MISMATCH: ncp-lab-main-v1 on-logout"
            }
            :if ([:tostr [/ip hotspot user profile get $item on-login]] != "") do={
                :put ("NCP_LAB_PROFILE_DIAG profile=ncp-lab-main-v1 field=on-login type=" . [:typeof [/ip hotspot user profile get $item on-login]] . " text-length=" . [:len [:tostr [/ip hotspot user profile get $item on-login]]])
                :error "PROFILE_PROPERTY_MISMATCH: ncp-lab-main-v1 on-login"
            }
            :if ([/ip hotspot user profile get $item shared-users] != 1) do={
                :put ("NCP_LAB_PROFILE_DIAG profile=ncp-lab-main-v1 field=shared-users type=" . [:typeof [/ip hotspot user profile get $item shared-users]] . " text-length=" . [:len [:tostr [/ip hotspot user profile get $item shared-users]]])
                :error "PROFILE_PROPERTY_MISMATCH: ncp-lab-main-v1 shared-users"
            }
            :if ([/ip hotspot user profile get $item rate-limit] != "2M/2M") do={
                :put ("NCP_LAB_PROFILE_DIAG profile=ncp-lab-main-v1 field=rate-limit type=" . [:typeof [/ip hotspot user profile get $item rate-limit]] . " text-length=" . [:len [:tostr [/ip hotspot user profile get $item rate-limit]]])
                :error "PROFILE_PROPERTY_MISMATCH: ncp-lab-main-v1 rate-limit"
            }
            :if ([/ip hotspot user profile get $item add-mac-cookie] != false) do={
                :put ("NCP_LAB_PROFILE_DIAG profile=ncp-lab-main-v1 field=add-mac-cookie type=" . [:typeof [/ip hotspot user profile get $item add-mac-cookie]] . " text-length=" . [:len [:tostr [/ip hotspot user profile get $item add-mac-cookie]]])
                :error "PROFILE_PROPERTY_MISMATCH: ncp-lab-main-v1 add-mac-cookie"
            }
            :if ([/ip hotspot user profile get $item transparent-proxy] != false) do={
                :put ("NCP_LAB_PROFILE_DIAG profile=ncp-lab-main-v1 field=transparent-proxy type=" . [:typeof [/ip hotspot user profile get $item transparent-proxy]] . " text-length=" . [:len [:tostr [/ip hotspot user profile get $item transparent-proxy]]])
                :error "PROFILE_PROPERTY_MISMATCH: ncp-lab-main-v1 transparent-proxy"
            }
        }
    }
    {
        :local item [/ip hotspot user profile find where name="ncp-lab-shared-v1"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_PROFILE" }
        :if ([:len $item] = 1) do={
            :if ([:tostr [/ip hotspot user profile get $item on-logout]] != "# NCP-LAB-V1-20261114") do={
                :put ("NCP_LAB_PROFILE_DIAG profile=ncp-lab-shared-v1 field=on-logout type=" . [:typeof [/ip hotspot user profile get $item on-logout]] . " text-length=" . [:len [:tostr [/ip hotspot user profile get $item on-logout]]])
                :error "PROFILE_PROPERTY_MISMATCH: ncp-lab-shared-v1 on-logout"
            }
            :if ([:tostr [/ip hotspot user profile get $item on-login]] != "") do={
                :put ("NCP_LAB_PROFILE_DIAG profile=ncp-lab-shared-v1 field=on-login type=" . [:typeof [/ip hotspot user profile get $item on-login]] . " text-length=" . [:len [:tostr [/ip hotspot user profile get $item on-login]]])
                :error "PROFILE_PROPERTY_MISMATCH: ncp-lab-shared-v1 on-login"
            }
            :if ([/ip hotspot user profile get $item shared-users] != 2) do={
                :put ("NCP_LAB_PROFILE_DIAG profile=ncp-lab-shared-v1 field=shared-users type=" . [:typeof [/ip hotspot user profile get $item shared-users]] . " text-length=" . [:len [:tostr [/ip hotspot user profile get $item shared-users]]])
                :error "PROFILE_PROPERTY_MISMATCH: ncp-lab-shared-v1 shared-users"
            }
            :if ([/ip hotspot user profile get $item rate-limit] != "2M/2M") do={
                :put ("NCP_LAB_PROFILE_DIAG profile=ncp-lab-shared-v1 field=rate-limit type=" . [:typeof [/ip hotspot user profile get $item rate-limit]] . " text-length=" . [:len [:tostr [/ip hotspot user profile get $item rate-limit]]])
                :error "PROFILE_PROPERTY_MISMATCH: ncp-lab-shared-v1 rate-limit"
            }
            :if ([/ip hotspot user profile get $item add-mac-cookie] != false) do={
                :put ("NCP_LAB_PROFILE_DIAG profile=ncp-lab-shared-v1 field=add-mac-cookie type=" . [:typeof [/ip hotspot user profile get $item add-mac-cookie]] . " text-length=" . [:len [:tostr [/ip hotspot user profile get $item add-mac-cookie]]])
                :error "PROFILE_PROPERTY_MISMATCH: ncp-lab-shared-v1 add-mac-cookie"
            }
            :if ([/ip hotspot user profile get $item transparent-proxy] != false) do={
                :put ("NCP_LAB_PROFILE_DIAG profile=ncp-lab-shared-v1 field=transparent-proxy type=" . [:typeof [/ip hotspot user profile get $item transparent-proxy]] . " text-length=" . [:len [:tostr [/ip hotspot user profile get $item transparent-proxy]]])
                :error "PROFILE_PROPERTY_MISMATCH: ncp-lab-shared-v1 transparent-proxy"
            }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-500-01"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-main-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 16777216) || ([/ip hotspot user get $item limit-uptime] != 60m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-500-02"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-main-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 16777216) || ([/ip hotspot user get $item limit-uptime] != 60m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-500-03"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-main-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 16777216) || ([/ip hotspot user get $item limit-uptime] != 60m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-1000-01"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-main-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 33554432) || ([/ip hotspot user get $item limit-uptime] != 120m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-1000-02"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-main-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 33554432) || ([/ip hotspot user get $item limit-uptime] != 120m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-free-01"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-main-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 8388608) || ([/ip hotspot user get $item limit-uptime] != 30m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-unknown-01"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-main-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 12582912) || ([/ip hotspot user get $item limit-uptime] != 45m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-disabled-01"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-main-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 16777216) || ([/ip hotspot user get $item limit-uptime] != 60m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-short-01"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-main-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 2097152) || ([/ip hotspot user get $item limit-uptime] != 2m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-shared-01"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-shared-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 16777216) || ([/ip hotspot user get $item limit-uptime] != 60m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/interface find where name="ncp-lab-link-v1"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_LAB_INTERFACE" }
        :if ([:len $item] = 1) do={
            :if ([/interface get $item type] != "vlan") do={ :error "LAB_INTERFACE_NAME_COLLISION" }
            :if (([/interface vlan get $item comment] != "NCP-LAB-V1-20261114") || ([/interface vlan get $item interface] != "ether3") || ([/interface vlan get $item vlan-id] != 4093)) do={ :error "UNKNOWN_OR_CHANGED_LAB_VLAN" }
        }
    }
    :if ([:len [/interface find where name="ncp-lab-link-v1"]] = 1) do={
        :if ([:len [/ip address find where interface="ncp-lab-link-v1"]] > 0) do={ :error "LAB_VLAN_HAS_IP_STOP" }
        :if ([:len [/ipv6 address find where interface="ncp-lab-link-v1" and dynamic=no]] > 0) do={ :error "LAB_VLAN_HAS_STATIC_IPV6_STOP" }
        :if ([:len [/interface bridge port find where interface="ncp-lab-link-v1"]] > 0) do={ :error "LAB_VLAN_ATTACHED_TO_BRIDGE_STOP" }
        :if ([:len [/ip dhcp-server find where interface="ncp-lab-link-v1"]] > 0) do={ :error "LAB_VLAN_HAS_DHCP_SERVER_STOP" }
        :if ([:len [/ip dhcp-client find where interface="ncp-lab-link-v1"]] > 0) do={ :error "LAB_VLAN_HAS_DHCP_CLIENT_STOP" }
        :if ([:len [/ip hotspot find where interface="ncp-lab-link-v1"]] > 0) do={ :error "LAB_VLAN_HAS_HOTSPOT_STOP" }
        :if ([:len [/interface vlan find where interface="ncp-lab-link-v1"]] > 0) do={ :error "LAB_VLAN_HAS_CHILD_STOP" }
    }
    :local cardNames {"ncp-lab-500-01";"ncp-lab-500-02";"ncp-lab-500-03";"ncp-lab-1000-01";"ncp-lab-1000-02";"ncp-lab-free-01";"ncp-lab-unknown-01";"ncp-lab-disabled-01";"ncp-lab-short-01";"ncp-lab-shared-01"}
    :foreach card in=$cardNames do={
        :if ([:len [/ip hotspot active find where user=$card]] > 0) do={ :error "LOG_OUT_TEST_CLIENTS_BEFORE_CLEANUP" }
    }
    :if ([:len [/ip hotspot user profile find where name="ncp-lab-main-v1"]] = 1) do={
        :foreach item in=[/ip hotspot user find where profile="ncp-lab-main-v1"] do={
            :local card [/ip hotspot user get $item name]
            :if (([:typeof [:find $cardNames $card]] = "nil") || ([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114")) do={ :error "PROFILE_REFERENCED_BY_OTHER_USER" }
        }
    }
    :if ([:len [/ip hotspot user profile find where name="ncp-lab-shared-v1"]] = 1) do={
        :foreach item in=[/ip hotspot user find where profile="ncp-lab-shared-v1"] do={
            :local card [/ip hotspot user get $item name]
            :if (([:typeof [:find $cardNames $card]] = "nil") || ([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114")) do={ :error "PROFILE_REFERENCED_BY_OTHER_USER" }
        }
    }
    :foreach card in=$cardNames do={
        /ip hotspot cookie remove [/ip hotspot cookie find where user=$card]
        /ip hotspot user remove [/ip hotspot user find where name=$card]
    }
    /ip hotspot user profile remove [/ip hotspot user profile find where name="ncp-lab-main-v1"]
    /ip hotspot user profile remove [/ip hotspot user profile find where name="ncp-lab-shared-v1"]
    /interface vlan remove [/interface vlan find where name="ncp-lab-link-v1"]
    :put "NCP_LAB_ROUTER_OBJECTS_REMOVED_APP_HISTORY_AND_BACKUP_PRESERVED"
}
