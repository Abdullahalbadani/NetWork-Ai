# Add only new tagged fixture objects. No existing network/account changes.
{
    :local board [/system resource get board-name]
    :if (!($board ~ "CHR")) do={ :error "CHR_LAB_REQUIRED" }
    :local ros [/system resource get version]
    :if ([:pick $ros 0 2] != "7.") do={ :error "ROUTEROS7_REQUIRED" }
    :local hs [/ip hotspot find where name="hotspot1"]
    :if ([:len $hs] != 1) do={ :error "HOTSPOT1_REQUIRED" }
    :if ([/ip hotspot get $hs interface] != "ether3") do={ :error "HOTSPOT_INTERFACE_CHANGED" }
    :if ([/ip hotspot get $hs disabled] = true) do={ :error "HOTSPOT_DISABLED" }
    :if ([:len [/ip address find where address="192.168.56.10/24" and interface="ether2" and disabled=no]] != 1) do={ :error "MANAGEMENT_BINDING_CHANGED" }
    :local httpsService [/ip service find where name="www-ssl" and dynamic=no]
    :if ([:len $httpsService] != 1) do={ :error "STATIC_HTTPS_SERVICE_REQUIRED" }
    :if ([/ip service get $httpsService port] != 8443) do={ :error "HTTPS_PORT_CHANGED" }
    :local backup [/file find where name="ncp-before-lab-v1.backup"]
    :if ([:len $backup] != 1) do={ :error "SAVE_PRIVATE_ENCRYPTED_BACKUP_FIRST" }
    :if ([/file get $backup size] = 0) do={ :error "BACKUP_FILE_EMPTY" }
    {
        :local item [/ip hotspot user profile find where name="ncp-lab-main-v1"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_PROFILE" }
        :if ([:len $item] = 1) do={
            :if ([:tostr [/ip hotspot user profile get $item on-logout]] != "# NCP-LAB-V1-20261114") do={
                :put ("NCP_LAB_PROFILE_DIAG profile=ncp-lab-main-v1 field=on-logout type=" . [:typeof [/ip hotspot user profile get $item on-logout]] . " text-length=" . [:len [:tostr [/ip hotspot user profile get $item on-logout]]])
                :error "PROFILE_PROPERTY_MISMATCH: ncp-lab-main-v1 on-logout"
            }
            :if ([:tostr [/ip hotspot user profile get $item on-login]] != "") do={
                :put ("NCP_LAB_PROFILE_DIAG profile=ncp-lab-main-v1 field=on-login type=" . [:typeof [/ip hotspot user profile get $item on-login]] . " text-length=" . [:len [:tostr [/ip hotspot user profile get $item on-login]]])
                :error "PROFILE_PROPERTY_MISMATCH: ncp-lab-main-v1 on-login"
            }
            :if ([/ip hotspot user profile get $item shared-users] != 1) do={
                :put ("NCP_LAB_PROFILE_DIAG profile=ncp-lab-main-v1 field=shared-users type=" . [:typeof [/ip hotspot user profile get $item shared-users]] . " text-length=" . [:len [:tostr [/ip hotspot user profile get $item shared-users]]])
                :error "PROFILE_PROPERTY_MISMATCH: ncp-lab-main-v1 shared-users"
            }
            :if ([/ip hotspot user profile get $item rate-limit] != "2M/2M") do={
                :put ("NCP_LAB_PROFILE_DIAG profile=ncp-lab-main-v1 field=rate-limit type=" . [:typeof [/ip hotspot user profile get $item rate-limit]] . " text-length=" . [:len [:tostr [/ip hotspot user profile get $item rate-limit]]])
                :error "PROFILE_PROPERTY_MISMATCH: ncp-lab-main-v1 rate-limit"
            }
            :if ([/ip hotspot user profile get $item add-mac-cookie] != false) do={
                :put ("NCP_LAB_PROFILE_DIAG profile=ncp-lab-main-v1 field=add-mac-cookie type=" . [:typeof [/ip hotspot user profile get $item add-mac-cookie]] . " text-length=" . [:len [:tostr [/ip hotspot user profile get $item add-mac-cookie]]])
                :error "PROFILE_PROPERTY_MISMATCH: ncp-lab-main-v1 add-mac-cookie"
            }
            :if ([/ip hotspot user profile get $item transparent-proxy] != false) do={
                :put ("NCP_LAB_PROFILE_DIAG profile=ncp-lab-main-v1 field=transparent-proxy type=" . [:typeof [/ip hotspot user profile get $item transparent-proxy]] . " text-length=" . [:len [:tostr [/ip hotspot user profile get $item transparent-proxy]]])
                :error "PROFILE_PROPERTY_MISMATCH: ncp-lab-main-v1 transparent-proxy"
            }
        }
    }
    {
        :local item [/ip hotspot user profile find where name="ncp-lab-shared-v1"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_PROFILE" }
        :if ([:len $item] = 1) do={
            :if ([:tostr [/ip hotspot user profile get $item on-logout]] != "# NCP-LAB-V1-20261114") do={
                :put ("NCP_LAB_PROFILE_DIAG profile=ncp-lab-shared-v1 field=on-logout type=" . [:typeof [/ip hotspot user profile get $item on-logout]] . " text-length=" . [:len [:tostr [/ip hotspot user profile get $item on-logout]]])
                :error "PROFILE_PROPERTY_MISMATCH: ncp-lab-shared-v1 on-logout"
            }
            :if ([:tostr [/ip hotspot user profile get $item on-login]] != "") do={
                :put ("NCP_LAB_PROFILE_DIAG profile=ncp-lab-shared-v1 field=on-login type=" . [:typeof [/ip hotspot user profile get $item on-login]] . " text-length=" . [:len [:tostr [/ip hotspot user profile get $item on-login]]])
                :error "PROFILE_PROPERTY_MISMATCH: ncp-lab-shared-v1 on-login"
            }
            :if ([/ip hotspot user profile get $item shared-users] != 2) do={
                :put ("NCP_LAB_PROFILE_DIAG profile=ncp-lab-shared-v1 field=shared-users type=" . [:typeof [/ip hotspot user profile get $item shared-users]] . " text-length=" . [:len [:tostr [/ip hotspot user profile get $item shared-users]]])
                :error "PROFILE_PROPERTY_MISMATCH: ncp-lab-shared-v1 shared-users"
            }
            :if ([/ip hotspot user profile get $item rate-limit] != "2M/2M") do={
                :put ("NCP_LAB_PROFILE_DIAG profile=ncp-lab-shared-v1 field=rate-limit type=" . [:typeof [/ip hotspot user profile get $item rate-limit]] . " text-length=" . [:len [:tostr [/ip hotspot user profile get $item rate-limit]]])
                :error "PROFILE_PROPERTY_MISMATCH: ncp-lab-shared-v1 rate-limit"
            }
            :if ([/ip hotspot user profile get $item add-mac-cookie] != false) do={
                :put ("NCP_LAB_PROFILE_DIAG profile=ncp-lab-shared-v1 field=add-mac-cookie type=" . [:typeof [/ip hotspot user profile get $item add-mac-cookie]] . " text-length=" . [:len [:tostr [/ip hotspot user profile get $item add-mac-cookie]]])
                :error "PROFILE_PROPERTY_MISMATCH: ncp-lab-shared-v1 add-mac-cookie"
            }
            :if ([/ip hotspot user profile get $item transparent-proxy] != false) do={
                :put ("NCP_LAB_PROFILE_DIAG profile=ncp-lab-shared-v1 field=transparent-proxy type=" . [:typeof [/ip hotspot user profile get $item transparent-proxy]] . " text-length=" . [:len [:tostr [/ip hotspot user profile get $item transparent-proxy]]])
                :error "PROFILE_PROPERTY_MISMATCH: ncp-lab-shared-v1 transparent-proxy"
            }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-500-01"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-main-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 16777216) || ([/ip hotspot user get $item limit-uptime] != 60m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-500-02"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-main-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 16777216) || ([/ip hotspot user get $item limit-uptime] != 60m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-500-03"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-main-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 16777216) || ([/ip hotspot user get $item limit-uptime] != 60m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-1000-01"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-main-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 33554432) || ([/ip hotspot user get $item limit-uptime] != 120m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-1000-02"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-main-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 33554432) || ([/ip hotspot user get $item limit-uptime] != 120m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-free-01"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-main-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 8388608) || ([/ip hotspot user get $item limit-uptime] != 30m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-unknown-01"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-main-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 12582912) || ([/ip hotspot user get $item limit-uptime] != 45m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-disabled-01"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-main-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 16777216) || ([/ip hotspot user get $item limit-uptime] != 60m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-short-01"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-main-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 2097152) || ([/ip hotspot user get $item limit-uptime] != 2m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-shared-01"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-shared-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 16777216) || ([/ip hotspot user get $item limit-uptime] != 60m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/interface find where name="ncp-lab-link-v1"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_LAB_INTERFACE" }
        :if ([:len $item] = 1) do={
            :if ([/interface get $item type] != "vlan") do={ :error "LAB_INTERFACE_NAME_COLLISION" }
            :if (([/interface vlan get $item comment] != "NCP-LAB-V1-20261114") || ([/interface vlan get $item interface] != "ether3") || ([/interface vlan get $item vlan-id] != 4093)) do={ :error "UNKNOWN_OR_CHANGED_LAB_VLAN" }
        }
    }
    :if ([:len [/interface find where name="ncp-lab-link-v1"]] = 1) do={
        :if ([:len [/ip address find where interface="ncp-lab-link-v1"]] > 0) do={ :error "LAB_VLAN_HAS_IP_STOP" }
        :if ([:len [/ipv6 address find where interface="ncp-lab-link-v1" and dynamic=no]] > 0) do={ :error "LAB_VLAN_HAS_STATIC_IPV6_STOP" }
        :if ([:len [/interface bridge port find where interface="ncp-lab-link-v1"]] > 0) do={ :error "LAB_VLAN_ATTACHED_TO_BRIDGE_STOP" }
        :if ([:len [/ip dhcp-server find where interface="ncp-lab-link-v1"]] > 0) do={ :error "LAB_VLAN_HAS_DHCP_SERVER_STOP" }
        :if ([:len [/ip dhcp-client find where interface="ncp-lab-link-v1"]] > 0) do={ :error "LAB_VLAN_HAS_DHCP_CLIENT_STOP" }
        :if ([:len [/ip hotspot find where interface="ncp-lab-link-v1"]] > 0) do={ :error "LAB_VLAN_HAS_HOTSPOT_STOP" }
        :if ([:len [/interface vlan find where interface="ncp-lab-link-v1"]] > 0) do={ :error "LAB_VLAN_HAS_CHILD_STOP" }
    }
    :foreach item in=[/interface vlan find where interface="ether3" and vlan-id=4093] do={
        :if ([/interface vlan get $item name] != "ncp-lab-link-v1") do={ :error "VLAN_ID_IN_USE" }
    }
    :local madeProfiles [:toarray ""]
    :local madeUsers [:toarray ""]
    :local madeLinks [:toarray ""]
    :local stage "start"
    :do {
        :set stage "ncp-lab-main-v1"
        :if ([:len [/ip hotspot user profile find where name="ncp-lab-main-v1"]] = 0) do={
            /ip hotspot user profile add name="ncp-lab-main-v1" shared-users=1 rate-limit="2M/2M" add-mac-cookie=no transparent-proxy=no on-login="" on-logout="# NCP-LAB-V1-20261114"
            :set madeProfiles ($madeProfiles, [/ip hotspot user profile find where name="ncp-lab-main-v1"])
        }
        :set stage "ncp-lab-shared-v1"
        :if ([:len [/ip hotspot user profile find where name="ncp-lab-shared-v1"]] = 0) do={
            /ip hotspot user profile add name="ncp-lab-shared-v1" shared-users=2 rate-limit="2M/2M" add-mac-cookie=no transparent-proxy=no on-login="" on-logout="# NCP-LAB-V1-20261114"
            :set madeProfiles ($madeProfiles, [/ip hotspot user profile find where name="ncp-lab-shared-v1"])
        }
        :set stage "ncp-lab-link-v1"
        :if ([:len [/interface find where name="ncp-lab-link-v1"]] = 0) do={
            /interface vlan add name="ncp-lab-link-v1" interface="ether3" vlan-id=4093 disabled=no comment="NCP-LAB-V1-20261114"
            :set madeLinks ($madeLinks, [/interface vlan find where name="ncp-lab-link-v1"])
        }
        :set stage "ncp-lab-500-01"
        :if ([:len [/ip hotspot user find where name="ncp-lab-500-01"]] = 0) do={
            /ip hotspot user add name="ncp-lab-500-01" password=[:rndstr length=20] server="hotspot1" profile="ncp-lab-main-v1" limit-bytes-total=16777216 limit-uptime=60m disabled=no comment="NCP-LAB-V1-20261114"
            :set madeUsers ($madeUsers, [/ip hotspot user find where name="ncp-lab-500-01"])
        }
        :set stage "ncp-lab-500-02"
        :if ([:len [/ip hotspot user find where name="ncp-lab-500-02"]] = 0) do={
            /ip hotspot user add name="ncp-lab-500-02" password=[:rndstr length=20] server="hotspot1" profile="ncp-lab-main-v1" limit-bytes-total=16777216 limit-uptime=60m disabled=no comment="NCP-LAB-V1-20261114"
            :set madeUsers ($madeUsers, [/ip hotspot user find where name="ncp-lab-500-02"])
        }
        :set stage "ncp-lab-500-03"
        :if ([:len [/ip hotspot user find where name="ncp-lab-500-03"]] = 0) do={
            /ip hotspot user add name="ncp-lab-500-03" password=[:rndstr length=20] server="hotspot1" profile="ncp-lab-main-v1" limit-bytes-total=16777216 limit-uptime=60m disabled=no comment="NCP-LAB-V1-20261114"
            :set madeUsers ($madeUsers, [/ip hotspot user find where name="ncp-lab-500-03"])
        }
        :set stage "ncp-lab-1000-01"
        :if ([:len [/ip hotspot user find where name="ncp-lab-1000-01"]] = 0) do={
            /ip hotspot user add name="ncp-lab-1000-01" password=[:rndstr length=20] server="hotspot1" profile="ncp-lab-main-v1" limit-bytes-total=33554432 limit-uptime=120m disabled=no comment="NCP-LAB-V1-20261114"
            :set madeUsers ($madeUsers, [/ip hotspot user find where name="ncp-lab-1000-01"])
        }
        :set stage "ncp-lab-1000-02"
        :if ([:len [/ip hotspot user find where name="ncp-lab-1000-02"]] = 0) do={
            /ip hotspot user add name="ncp-lab-1000-02" password=[:rndstr length=20] server="hotspot1" profile="ncp-lab-main-v1" limit-bytes-total=33554432 limit-uptime=120m disabled=no comment="NCP-LAB-V1-20261114"
            :set madeUsers ($madeUsers, [/ip hotspot user find where name="ncp-lab-1000-02"])
        }
        :set stage "ncp-lab-free-01"
        :if ([:len [/ip hotspot user find where name="ncp-lab-free-01"]] = 0) do={
            /ip hotspot user add name="ncp-lab-free-01" password=[:rndstr length=20] server="hotspot1" profile="ncp-lab-main-v1" limit-bytes-total=8388608 limit-uptime=30m disabled=no comment="NCP-LAB-V1-20261114"
            :set madeUsers ($madeUsers, [/ip hotspot user find where name="ncp-lab-free-01"])
        }
        :set stage "ncp-lab-unknown-01"
        :if ([:len [/ip hotspot user find where name="ncp-lab-unknown-01"]] = 0) do={
            /ip hotspot user add name="ncp-lab-unknown-01" password=[:rndstr length=20] server="hotspot1" profile="ncp-lab-main-v1" limit-bytes-total=12582912 limit-uptime=45m disabled=no comment="NCP-LAB-V1-20261114"
            :set madeUsers ($madeUsers, [/ip hotspot user find where name="ncp-lab-unknown-01"])
        }
        :set stage "ncp-lab-disabled-01"
        :if ([:len [/ip hotspot user find where name="ncp-lab-disabled-01"]] = 0) do={
            /ip hotspot user add name="ncp-lab-disabled-01" password=[:rndstr length=20] server="hotspot1" profile="ncp-lab-main-v1" limit-bytes-total=16777216 limit-uptime=60m disabled=yes comment="NCP-LAB-V1-20261114"
            :set madeUsers ($madeUsers, [/ip hotspot user find where name="ncp-lab-disabled-01"])
        }
        :set stage "ncp-lab-short-01"
        :if ([:len [/ip hotspot user find where name="ncp-lab-short-01"]] = 0) do={
            /ip hotspot user add name="ncp-lab-short-01" password=[:rndstr length=20] server="hotspot1" profile="ncp-lab-main-v1" limit-bytes-total=2097152 limit-uptime=2m disabled=no comment="NCP-LAB-V1-20261114"
            :set madeUsers ($madeUsers, [/ip hotspot user find where name="ncp-lab-short-01"])
        }
        :set stage "ncp-lab-shared-01"
        :if ([:len [/ip hotspot user find where name="ncp-lab-shared-01"]] = 0) do={
            /ip hotspot user add name="ncp-lab-shared-01" password=[:rndstr length=20] server="hotspot1" profile="ncp-lab-shared-v1" limit-bytes-total=16777216 limit-uptime=60m disabled=no comment="NCP-LAB-V1-20261114"
            :set madeUsers ($madeUsers, [/ip hotspot user find where name="ncp-lab-shared-01"])
        }
    } on-error={
        :put ("NCP_LAB_SEED_FAILED stage=" . $stage)
        :foreach item in=$madeUsers do={ :do { /ip hotspot user remove $item } on-error={ :put "CLEANUP_USER_INCOMPLETE" } }
        :foreach item in=$madeLinks do={ :do { /interface vlan remove $item } on-error={ :put "CLEANUP_LINK_INCOMPLETE" } }
        :foreach item in=$madeProfiles do={ :do { /ip hotspot user profile remove $item } on-error={ :put "CLEANUP_PROFILE_INCOMPLETE" } }
        :error "SEED_STOPPED_CHECK_PERMISSIONS_AND_REPORT_STAGE"
    }
    :put ("NCP_LAB_READY new-users=" . [:len $madeUsers] . " profiles-added=" . [:len $madeProfiles] . " links-added=" . [:len $madeLinks])
    :put ("TOTAL_HOTSPOT_USERS=" . [:len [/ip hotspot user find]])
    :put "Passwords were generated locally. View test credentials privately in WinBox."
}
