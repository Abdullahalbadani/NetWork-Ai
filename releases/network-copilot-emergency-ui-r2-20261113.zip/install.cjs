'use strict';
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),zlib=require('node:zlib');
const expectedPayload='109b37bc916d75932b65789a6c1f7382f292bc0d8f0477a1c0b585ccf5f766c9',expectedRunner='972a18dbea7290157bd50d871bf45337fd37d7a4e949301dc229fe206190c40a';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
try{
 if(Number(process.versions.node.split('.')[0])<24)throw Error('Node 24 or newer is required');
 if(process.argv.length!==3)throw Error('Usage: node install.cjs "D:\\NetWork-Ai"');
 const root=path.resolve(process.argv[2]);
 if(!fs.existsSync(root)||fs.lstatSync(root).isSymbolicLink()||!fs.statSync(root).isDirectory())throw Error('EXISTING_PROJECT_REQUIRED');
 const runnerPath=path.join(__dirname,'apply-foundation-update.cjs'),payloadPath=path.join(__dirname,'ui-update.ncp');
 for(const[file,hash]of[[runnerPath,expectedRunner],[payloadPath,expectedPayload]]){const s=fs.lstatSync(file);if(!s.isFile()||s.isSymbolicLink()||s.size>1024*1024||sha(fs.readFileSync(file))!==hash)throw Error('DELIVERY_INTEGRITY_FAILED');}
 const runner=require(runnerPath);let project,runtime;
 try{project=JSON.parse(fs.readFileSync(runner.safePath(root,'package.json'),'utf8').replace(/^\uFEFF/,''));runtime=JSON.parse(fs.readFileSync(runner.safePath(root,'runtime/v06/package.json'),'utf8').replace(/^\uFEFF/,''));}catch{throw Error('INVALID_PROJECT_MARKERS');}
 const pubspec=fs.readFileSync(runner.safePath(root,'apps/mobile/pubspec.yaml'),'utf8').replace(/^\uFEFF/,'');
 if(project.name!=='network-copilot'||runtime.name!=='network-copilot-runtime'||runtime.version!=='0.8.1'||!/^name:\s*network_copilot\s*$/m.test(pubspec)||!/^version:\s*0\.8\.1\+9\s*$/m.test(pubspec))throw Error('INSTALLED_081_SOURCE_REQUIRED');
 const bytes=fs.readFileSync(payloadPath),pkg=JSON.parse(zlib.brotliDecompressSync(bytes,{maxOutputLength:1024*1024})),allowed=new Set(["apps/mobile/lib/emergency_home.dart","apps/mobile/lib/emergency_incident.dart"]);
 if(pkg.version!=='emergency-v081'||pkg.patchVersion!=='emergency-ui-r2-20261113'||pkg.files.length!==2||pkg.files.some(f=>!allowed.delete(f.path))||allowed.size)throw Error('UI_PATCH_SCOPE_REFUSED');
 const temporary=fs.mkdtempSync(path.join(os.tmpdir(),'copilot-emergency-ui-r2-')),lockPath=path.join(root,'.copilot-integration.lock');let lock;
 try{lock=fs.openSync(lockPath,'wx',0o600);const hex=path.join(temporary,'payload.hex');fs.writeFileSync(hex,bytes.toString('hex'),{flag:'wx',mode:0o600});const result=runner.apply(root,hex,expectedPayload,()=>{});if(result.changed){console.log('Emergency UI R2 installed. Files: '+result.changed);console.log('Code backup: '+result.backup);}else console.log('Emergency UI R2 is already installed.');}
 finally{fs.rmSync(temporary,{recursive:true,force:true});if(lock!==undefined){fs.closeSync(lock);fs.unlinkSync(lockPath);}}
 console.log('Client source lint fix only. Schema 4, backend, accounts, MFA, package manifests, signing, caches and startup preserved. No dependency download or RouterOS write. Rerun verify-client.ps1, then start Chrome.');
}catch(e){console.error('UI fix stopped: '+(e.code==='EEXIST'?'INSTALL_LOCK_EXISTS: inspect the active installer before retrying':e.message));process.exitCode=1;}
