'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const runnerPath=path.join(__dirname,'apply-foundation-update.cjs');if(crypto.createHash('sha256').update(fs.readFileSync(runnerPath)).digest('hex')!=='972a18dbea7290157bd50d871bf45337fd37d7a4e949301dc229fe206190c40a')throw Error('RUNNER_HASH_MISMATCH');const {safePath}=require(runnerPath);
const sha=value=>crypto.createHash('sha256').update(value).digest('hex');
function rollback(rootArg,backupArg){
 const root=path.resolve(rootArg),backup=path.resolve(backupArg);
 const relative=path.relative(root,backup).replaceAll('\\','/');
 if(!/^\.copilot-update-backups\/(?:foundation-v06|health-v07|operations-v08|emergency-v081)-/.test(relative)||safePath(root,relative)!==backup)throw Error('Choose the exact update backup inside this project');
 const manifestPath=safePath(root,relative+'/update.json');
 if(fs.statSync(manifestPath).size>1024*1024)throw Error('Invalid backup manifest');
 const manifest=JSON.parse(fs.readFileSync(manifestPath,'utf8'));
 if(!['foundation-v06','health-v07','operations-v08','emergency-v081'].includes(manifest.version)||!Array.isArray(manifest.files)||manifest.files.length>2500)throw Error('Invalid backup version');
 const expectedFiles=new Map([["apps/mobile/lib/emergency_home.dart","ae7c83b05c8935e77dcb8273894de634c5d5c22328ecc6de529ba117a9421f23"],["apps/mobile/lib/emergency_incident.dart","9b82baf4653fb316b2909524a144bf9e98dae6c508dab3a18d156d99e5db646e"]]);if(manifest.version!=='emergency-v081'||!manifest.files.length||manifest.files.some(f=>expectedFiles.get(f.path)!==f.after))throw Error('Use the exact Emergency UI R2 code backup printed by this installer');
 const plan=[];
 for(const row of manifest.files){
  const target=safePath(root,row.path),saved=safePath(root,relative+'/'+row.path);
  const current=fs.existsSync(target)?fs.readFileSync(target):null;
  if(row.existed && current && sha(current)===row.before)continue;
  if(!row.existed && current===null)continue;
  if(!current||sha(current)!==row.after)throw Error('File changed after update; preserved: '+row.path);
  const previous=row.existed?fs.readFileSync(saved):null;
  if(previous&&sha(previous)!==row.before)throw Error('Backup hash mismatch');
  plan.push({target,previous});
 }
 for(const row of plan){if(row.previous)fs.writeFileSync(row.target,row.previous);else fs.unlinkSync(row.target);}
 console.log('Code update rolled back. The foundation database and protected configuration were preserved.');
}
if(require.main===module){try{rollback(...process.argv.slice(2));}catch(e){console.error('Rollback stopped: '+e.message);process.exitCode=1;}}
module.exports={rollback};
