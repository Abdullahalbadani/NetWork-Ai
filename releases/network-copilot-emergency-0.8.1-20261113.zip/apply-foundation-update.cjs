'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const zlib = require('node:zlib');

const VERSIONS = new Set(['foundation-v06', 'health-v07', 'operations-v08', 'emergency-v081']);
const sha = value => crypto.createHash('sha256').update(value).digest('hex');
const textBytes = value => Buffer.from(
  value.toString('utf8').replace(/^\uFEFF/, '').replace(/\r\n/g, '\n'),
);
const fail = message => { throw new Error(message); };
const digest = value => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value);

// Compare known Dart sources across whitespace-only formatting. String contents,
// comments, identifiers, punctuation and trailing commas remain significant.
// This never executes Dart, evaluates strings or accepts arbitrary code changes.
function sourceHash(value) {
  const source = textBytes(value).toString('utf8');
  const tokens = [];
  let i = 0;
  const identifierStart = /[A-Za-z_$\p{L}]/u;
  const identifierPart = /[A-Za-z0-9_$\p{L}\p{N}]/u;
  const operators = [
    '>>>=', '...?', '~/=', '>>>', '??=', '<<=', '>>=', '...', '?..',
    '==', '!=', '<=', '>=', '&&', '||', '++', '--', '+=', '-=', '*=',
    '/=', '%=', '&=', '|=', '^=', '<<', '>>', '??', '?.', '=>', '..', '~/',
  ];
  function comment() {
    const start = i;
    if (source.startsWith('//', i)) {
      const end = source.indexOf('\n', i);
      i = end < 0 ? source.length : end;
    } else {
      let depth = 1;
      i += 2;
      while (i < source.length && depth) {
        if (source.startsWith('/*', i)) { depth++; i += 2; }
        else if (source.startsWith('*/', i)) { depth--; i += 2; }
        else i++;
      }
      if (depth) fail('INVALID_DART_SOURCE');
    }
    return source.slice(start, i);
  }
  function isString() {
    return source[i] === '"' || source[i] === "'" ||
      (source[i] === 'r' && (source[i + 1] === '"' || source[i + 1] === "'"));
  }
  function interpolation() {
    let depth = 1;
    i += 2;
    while (i < source.length && depth) {
      if (isString()) quoted();
      else if (source.startsWith('//', i) || source.startsWith('/*', i)) comment();
      else if (source[i] === '{') { depth++; i++; }
      else if (source[i] === '}') { depth--; i++; }
      else i++;
    }
    if (depth) fail('INVALID_DART_SOURCE');
  }
  function quoted() {
    const start = i;
    const raw = source[i] === 'r';
    if (raw) i++;
    const quote = source[i];
    const delimiter = source.startsWith(quote.repeat(3), i) ? quote.repeat(3) : quote;
    i += delimiter.length;
    while (i < source.length) {
      if (source.startsWith(delimiter, i)) {
        i += delimiter.length;
        return source.slice(start, i);
      }
      if (!raw && source[i] === '\\') i += 2;
      else if (!raw && source[i] === '$' && source[i + 1] === '{') interpolation();
      else i++;
    }
    fail('INVALID_DART_SOURCE');
  }
  while (i < source.length) {
    if (/\s/.test(source[i])) { i++; continue; }
    if (isString()) { tokens.push(['string', quoted()]); continue; }
    if (source.startsWith('//', i) || source.startsWith('/*', i)) {
      tokens.push(['comment', comment()]); continue;
    }
    if (identifierStart.test(source[i])) {
      const start = i++;
      while (i < source.length && identifierPart.test(source[i])) i++;
      tokens.push(['identifier', source.slice(start, i)]); continue;
    }
    if (/[0-9]/.test(source[i])) {
      const number = source.slice(i).match(/^(?:0[xX][0-9a-fA-F]+|[0-9]+(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?)/)[0];
      tokens.push(['number', number]); i += number.length; continue;
    }
    const operator = operators.find(item => source.startsWith(item, i));
    tokens.push(['punctuation', operator || source[i]]);
    i += operator ? operator.length : 1;
  }
  return sha(JSON.stringify(tokens));
}

function safePath(root, relative) {
  if (typeof relative !== 'string' || !relative || relative.includes('\\') ||
      relative.includes(':') || relative.startsWith('/') ||
      relative.split('/').some(part => !part || part === '.' || part === '..' || part.endsWith('.') || /^(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)/i.test(part))) {
    fail('INVALID_UPDATE_PATH');
  }
  const target = path.resolve(root, ...relative.split('/'));
  if (!target.startsWith(root + path.sep)) fail('UPDATE_PATH_ESCAPES_ROOT');
  let current = root;
  for (const part of relative.split('/')) {
    current = path.join(current, part);
    if (fs.existsSync(current) && fs.lstatSync(current).isSymbolicLink()) {
      fail('UPDATE_SYMLINK_REFUSED');
    }
  }
  return target;
}

function allowedPath(relative) {
  if (/(?:^|\/)(?:node_modules|\.git|\.dart_tool|build|\.idea)(?:\/|$)/.test(relative)) return false;
  if (/(?:^|\/)\.env(?:\.|$)|\.private\.|\.(?:key|pem|ncbak)$|local\.properties$|keystore/i.test(relative)) return false;
  return /^(?:apps\/mobile\/(?:lib\/[a-z_]+\.dart|test\/[a-z_]+\.dart|assets\/fonts\/[A-Za-z0-9_.-]+|pubspec\.yaml|analysis_options\.yaml|web\/(?:index\.html|manifest\.json|app-icon\.svg|favicon\.png|icons\/Icon(?:-maskable)?-(?:192|512)\.png)|android\/[A-Za-z0-9_./-]+)|apps\/server\/(?:src\/(?:foundation\/)?[a-z-]+\.ts|test\/(?:[a-z.-]+\.test\.ts|fixtures\/[a-z-]+\.(?:mjs|ts)))|runtime\/v06\/[A-Za-z0-9_@./-]+|docs\/[a-z0-9.-]+\.(?:md|json)|scripts\/[a-z0-9-]+\.(?:cjs|mjs)|package(?:-lock)?\.json|tsconfig\.json|README\.md|START_HERE\.md|\.gitignore|start-foundation\.cmd)$/.test(relative);
}

function apply(rootArg, dataFile, expectedHash, print = console.log) {
  const root = path.resolve(rootArg);
  if (!digest(expectedHash)) fail('EXPECTED_HASH_REQUIRED');
  if (!fs.existsSync(root) || fs.lstatSync(root).isSymbolicLink() ||
      !fs.statSync(root).isDirectory()) fail('PROJECT_FOLDER_REQUIRED');
  const hex = fs.readFileSync(dataFile, 'utf8').replace(/\s/g, '');
  if (!hex || hex.length % 2 || /[^a-f0-9]/i.test(hex)) fail('INVALID_UPDATE_DATA');
  const compressed = Buffer.from(hex, 'hex');
  if (sha(compressed) !== expectedHash) fail('UPDATE_HASH_MISMATCH');
  const pkg = JSON.parse(zlib.brotliDecompressSync(compressed, {
    maxOutputLength: 64 * 1024 * 1024,
  }).toString('utf8'));
  if (!VERSIONS.has(pkg.version) || !Array.isArray(pkg.files) ||
      pkg.files.length < 1 || pkg.files.length > 2500) fail('INVALID_UPDATE_MANIFEST');
  const seen = new Set();
  const planned = [];
  for (const entry of pkg.files) {
    if (!entry || !allowedPath(entry.path) || seen.has(entry.path) ||
        typeof entry.binary !== 'boolean' ||
        entry.binary !== /\.(?:ttf|png|jar)$/.test(entry.path) ||
        !digest(entry.after) || !Array.isArray(entry.before) ||
        entry.before.some(value => value !== null && !digest(value)) ||
        typeof entry.content !== 'string') fail('UPDATE_SCOPE_REFUSED');
    seen.add(entry.path);
    const dest = safePath(root, entry.path);
    const after = Buffer.from(entry.content, 'base64');
    if (after.length > 16 * 1024 * 1024 || sha(after) !== entry.after) {
      fail('NEW_FILE_HASH_MISMATCH');
    }
    const canonical = data => entry.binary ? data : textBytes(data);
    if (fs.existsSync(dest) && (!fs.statSync(dest).isFile() ||
        fs.statSync(dest).size > 16 * 1024 * 1024)) {
      fail('LOCAL_FILE_CONFLICT: ' + entry.path);
    }
    const before = fs.existsSync(dest) ? fs.readFileSync(dest) : null;
    const hash = before ? sha(canonical(before)) : null;
    let tokenHash;
    if (before && entry.path.endsWith('.dart')) {
      try { tokenHash = sourceHash(before); } catch { tokenHash = undefined; }
    }
    if (hash === entry.after ||
        (tokenHash && digest(entry.afterSource) && tokenHash === entry.afterSource)) {
      continue;
    }
    const knownSource = tokenHash && Array.isArray(entry.beforeSource) &&
      entry.beforeSource.every(digest) && entry.beforeSource.includes(tokenHash);
    if (!entry.before.includes(hash) && !knownSource) {
      fail('LOCAL_FILE_CONFLICT: ' + entry.path);
    }
    planned.push({ path: entry.path, dest, before, after, afterHash: entry.after });
  }
  if (!planned.length) {
    print('This update is already installed.');
    return { changed: 0 };
  }
  const backupRelative = '.copilot-update-backups/' + pkg.version + '-' +
    Date.now() + '-' + crypto.randomUUID();
  const backup = safePath(root, backupRelative);
  fs.mkdirSync(backup, { recursive: true, mode: 0o700 });
  for (const entry of planned) if (entry.before) {
    const target = safePath(root, backupRelative + '/' + entry.path);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(target, entry.before, { flag: 'wx', mode: 0o600 });
  }
  fs.writeFileSync(path.join(backup, 'update.json'), JSON.stringify({
    version: pkg.version,
    files: planned.map(entry => ({
      path: entry.path,
      existed: entry.before !== null,
      before: entry.before ? sha(entry.before) : null,
      after: entry.afterHash,
    })),
  }, null, 2), { flag: 'wx', mode: 0o600 });
  const changed = [];
  try {
    for (const entry of planned) {
      safePath(root, entry.path);
      const current = fs.existsSync(entry.dest) ? fs.readFileSync(entry.dest) : null;
      if (Boolean(current) !== Boolean(entry.before) ||
          (current && !current.equals(entry.before))) {
        fail('FILE_CHANGED_DURING_UPDATE: ' + entry.path);
      }
      fs.mkdirSync(path.dirname(entry.dest), { recursive: true });
      const temporary = entry.dest + '.' + crypto.randomUUID() + '.tmp';
      try {
        fs.writeFileSync(temporary, entry.after, { flag: 'wx', mode: entry.path.endsWith('/gradlew') ? 0o700 : 0o600 });
        fs.renameSync(temporary, entry.dest);
      } finally {
        if (fs.existsSync(temporary)) fs.unlinkSync(temporary);
      }
      changed.push(entry);
    }
  } catch (error) {
    for (const entry of changed.reverse()) {
      if (!fs.existsSync(entry.dest) ||
          sha(fs.readFileSync(entry.dest)) !== entry.afterHash) continue;
      if (entry.before) fs.writeFileSync(entry.dest, entry.before);
      else fs.unlinkSync(entry.dest);
    }
    throw error;
  }
  print((pkg.version === 'emergency-v081' ? 'Emergency radar v0.8.1' : pkg.version === 'operations-v08' ? 'Network operations v0.8' : pkg.version === 'health-v07' ? 'Network health v0.7' : 'Foundation v0.6') + ' update installed. Files: ' + planned.length);
  print('Backup: ' + backup);
  print('Your .env, router credentials, certificates and Google key were preserved.');
  return { changed: planned.length, backup };
}

if (require.main === module) {
  try { apply(...process.argv.slice(2)); }
  catch (error) {
    console.error('Update stopped: ' + error.message);
    process.exitCode = 1;
  }
}

module.exports = { apply, sourceHash, safePath, allowedPath };
