# تحديث رادار الطوارئ — Network Copilot 0.8.1+9

هذه حزمة تحديث لمشروعك القائم `D:\NetWork-Ai`، مبنية على آخر تثبيت أكدته: **0.8.0 + واجهة R2، مخطط PostgreSQL 3**. تضيف رادار الطوارئ في أول الرئيسية وتنتقل إلى المخطط 4. التنفيذ الجديد داخل معماريتك؛ لم يُنقل خادم صديقك أو SQLite أو مصادقته. أقسام الحملات الجغرافية واستوديو الهوتسبوت والكروت الشامل والانتينات ليست ضمن هذه الدفعة الخاصة بالرادار.

المراقبة، الأدلة، استلام المتابعة، الإجراءات المسماة، الصلاحيات، المعاينة والاعتماد والتحقق والاستعادة والسجل موصولة بالخادم والتخزين. الأعطال المادية لها دليل وخطوات صيانة وإعادة قياس؛ لا يدّعي زر إصلاح كابل أو تبريد جهاز برمجيًا. تفاصيل الوظائف والحدود في `FUNCTIONS_AR.md` وخطوات قبول الجوال/CHR/الأجهزة الحقيقية في `ACCEPTANCE_AR.md`.

## 1. التطبيق بأمر واحد

استخرج ZIP في مجلد مستقل **`D:\copilot-emergency`**. أوقف نافذة خادم Node الحالي بـCtrl+C وانتظر عودة سطر PowerShell. لا توقف PostgreSQL، ثم:

```powershell
node "D:\copilot-emergency\install.cjs" "D:\NetWork-Ai"
if ($LASTEXITCODE -ne 0) { throw "توقف التحديث؛ احتفظ بالرسالة ولا تكمل البناء." }
```

الترتيب: تحقق سلامة الحمولة والملفات → نسخة أصلية للملفات المتغيرة → تحديث المصدر وruntime المجمّع → نسخة بيانات مشفرة خارج المشروع → ترحيل 3 إلى 4. يطبع مسارين؛ احتفظ بهما:

- **Code backup** داخل `D:\NetWork-Ai\.copilot-update-backups\emergency-v081-...`.
- **Encrypted pre-upgrade backup** داخل `D:\network-copilot-private\before-emergency-....ncbak`، ومفتاحه `backup-v1.key` في المجلد الخاص.

تكرار الأمر آمن؛ لا يعيد الترحيل أو ينشئ نسخة مشفرة ثانية بعد نجاحه. اختلاف محلي مجهول يوقفه قبل الكتابة؛ لا تعدل البصمات ولا تستخدم فرض الاستبدال. BOM وCRLF وتنسيق مسافات Dart المعروف مقبولة. يحفظ التوقيع والكاش وملفات الافتتاحية والإعدادات والحسابات وMFA والجلسات ومراجع أسرار الراوتر. لا تُجرى كتابة على الراوتر أثناء التثبيت.

إذا طبع **DATABASE UPGRADE INCOMPLETE**: أبق الخادم متوقفًا واحتفظ بنسختي الكود والبيانات. صحح جاهزية PostgreSQL/الإعداد الخاص ثم أعد الأمر نفسه. قد يكون المخطط 4 قد التزم بالفعل؛ لذلك لا يعيد المثبّت الكود تلقائيًا إلى خادم قديم غير متوافق. حالة `--code-only` للاختبار المعزول فقط؛ لا تستخدمها في التطبيق المعتاد.

## 2. تشغيل الخادم المحدّث

في نافذة PowerShell مستقلة:

```powershell
cd "D:\NetWork-Ai"
node --use-env-proxy --env-file=.env ".\runtime\v06\dist\server.js" --foundation
```

انتظر `Network Copilot foundation is listening on https://127.0.0.1:3443`، وأبق هذه النافذة مفتوحة. يستمر اسم runtime/v06 للتوافق، ويحتوي الإصدار الجديد. لا إنشاء حساب أو إعادة MFA أو تغيير شهادة دخول الهاتف مطلوب.

## 3. التحقق من Flutter الموجود عندك

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "D:\copilot-emergency\verify-client.ps1" -ProjectRoot "D:\NetWork-Ai"
if ($LASTEXITCODE -ne 0) { throw "توقف؛ أرسل نهاية سجل التحليل أو الاختبار قبل بناء الهاتف." }
```

يقرأ SDK من `apps\mobile\android\local.properties` ويستخدم `pub get --offline` و`analyze --no-pub` و`test --no-pub`. لا توجد تبعيات Flutter جديدة. إذا غاب عنصر من الكاش يتوقف؛ لا يوجه لتنزيل جماعي. في بيئة التسليم لم يتوفر Flutter SDK، لذلك **لم يُنفذ flutter analyze أو flutter test أو بناء APK هنا**؛ كتبنا عشرة اختبارات إضافية للرادار وفحصنا صياغة ملفات Dart. نتائج جهازك مطلوبة قبل وصف بناء الواجهة بأنه ناجح.

## 4. بناء الهاتف وتثبيته فوق الحالي

بعد نجاح التحقق، صل الهاتف بكابل ثابت وافتحه واسمح بتصحيح USB:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "D:\copilot-emergency\build-phone.ps1" -ProjectRoot "D:\NetWork-Ai"
```

يستدعي **Gradle 9.3.1-all الموجود في الكاش مباشرة**، مع --offline ومنع تنزيل SDK/JDK، ويبقي wrapper 9.1.0. يبني Android arm64 باسم 0.8.1 ورقم 9، ثم `adb -d install -r` بنفس توقيع جهازك المحلي، ويؤكد تحويل 3443 ويفتح التطبيق. لا uninstall أو مسح بيانات.

لبناء APK دون الحاجة لتوصيل الهاتف أثناء البناء، أضف `-BuildOnly`، ثم للتثبيت فقط دون إعادة البناء:

```powershell
$copilotAdb = @(
  "$env:ANDROID_HOME\platform-tools\adb.exe"
  "$env:LOCALAPPDATA\Android\Sdk\platform-tools\adb.exe"
  (Get-Command adb -ErrorAction SilentlyContinue).Source
) | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1
if (-not $copilotAdb) { throw "لم نجد adb الموجود لديك." }
& $copilotAdb -d install -r "D:\NetWork-Ai\apps\mobile\build\app\outputs\flutter-apk\app-debug.apk"
if ($LASTEXITCODE -ne 0) { throw "توقف التثبيت؛ احتفظ بالتطبيق وبياناته وأرسل السبب." }
powershell -NoProfile -ExecutionPolicy Bypass -File "D:\copilot-emergency\connect-phone.ps1" -AdbPath $copilotAdb
```

خطأ المساحة يحتاج إتاحة مساحة في الهاتف؛ لا إزالة Network Copilot. بعد فصل USB أو إعادة ADB أعد `connect-phone.ps1`. رجوع الأمر إلى سطر PowerShell طبيعي؛ التحويل يعمل في الخلفية والخادم وحده يبقى في نافذته.

## 5. التجربة من الجوال

1. الحساب الحالي ثم MFA، فحص الصحة وسجله والمقارنة والإلغاء، والخلفية والعودة.
2. الرئيسية → رادار الطوارئ → «قياس الآن». راجع وقت القياس وتغطية المصادر، ثم «إعداد الرادار والمعالجة» لتفعيل مراقبة جهاز اختبار. المراقبة مستمرة من الخادم، ولا تعتمد على بقاء الهاتف مفتوحًا.
3. عند وجود عطل اضغط الإجراء المسمى بجانبه؛ ستجد الدليل وخطوات المعالجة والسجل. تغيير إعداد راوتر يحتاج حساب RouterOS معالجة مستقلًا وسياسة ومنافذ إدارة محمية ومعاينة واعتمادًا. التثبيت لا ينشئ هذا الحساب ولا يحوّل حساب القراءة إلى كتابة.
4. ابدأ قبول الكتابة على CHR معزول وفق `ACCEPTANCE_AR.md`. WiFi والحساسات والقدرة/الكابلات الحقيقية تحتاج جهازًا مناسبًا؛ نتائج المحاكاة ليست اختبارًا لها. المراقب يقرأ فقط، والفني يتابع ويقيس في موقعه؛ المعالجة للمالك/المدير مع MFA.

## 6. الرجوع عن الكود والبيانات

**رجوع الكود لا يخفض مخطط قاعدة البيانات.** إذا التزم المخطط 4، لن يعمل خادم 0.8.0 على قاعدة 4. حافظ على القاعدة الحالية، واستعد نسخة ما قبل التحديث إلى قاعدة منفصلة عند الحاجة للرجوع الكامل. بيانات أضيفت بعد النسخة لا تكون داخل النسخة الأقدم.

أوقف الخادم. استخدم مسار **Code backup الذي طبعه هذا المثبّت بالضبط**:

```powershell
node "D:\copilot-emergency\rollback.cjs" "D:\NetWork-Ai" "D:\NetWork-Ai\.copilot-update-backups\emergency-v081-ضع-المعرف-المطبوع"
if ($LASTEXITCODE -ne 0) { throw "توقف الرجوع؛ أرسل الرسالة، ولا تستبدل الملفات يدويًا." }
```

يعيد بايتات الملفات الأصلية، ويحذف الملفات التي أضافها هذا التحديث فقط، ويرفض تعديلات لاحقة أو نسخة تحديث أخرى. يمكن تكراره بأمان. إذا لم يبدأ الترحيل وبقي المخطط 3 يمكن تشغيل الكود المستعاد مباشرة. إذا وصل إلى 4، بعد رجوع الكود استخدم **أداة الاستعادة القديمة التي عادت معه**:

```powershell
cd "D:\NetWork-Ai"
$copilotRestoreDb = "copilot_restore_er_" + (Get-Date -Format "yyyyMMdd_HHmmss")
node --env-file=.env ".\runtime\v06\scripts\restore-foundation.mjs" "D:\network-copilot-private\before-emergency-ضع-المعرف-المطبوع.ncbak" $copilotRestoreDb
if ($LASTEXITCODE -ne 0) { throw "توقفت الاستعادة؛ قاعدة التشغيل الحالية محفوظة." }
$env:COPILOT_FOUNDATION_CONFIG = "D:\network-copilot-private\$copilotRestoreDb.private.json"
node --use-env-proxy --env-file=.env ".\runtime\v06\dist\server.js" --foundation
```

تُنشأ قاعدة مخطط 3 وملف إعداد خاص جديدان؛ لا تُكتب بيانات فوق قاعدة التشغيل الحالية ولا يتغير ملف الإعداد الأصلي. اختيار ملف الاستعادة في هذا الأمر مؤقت لهذه نافذة PowerShell. الحسابات وكلمات المرور وTOTP وأسرار الأجهزة تستعاد؛ **الجلسات المستعادة تُلغى عمدًا**، فسجّل الدخول بنفس حسابك ورمزك دون إعادة إنشاء شيء. احتفظ بالقاعدة 4 حتى تراجع ما أضيف بعد النسخة، ولا تحذفها آليًا.

إذا أردت إعادة الهاتف إلى المصدر المستعاد، شغّل verify-client ثم build-phone من هذه الحزمة بعد الرجوع. يحافظ مساعد البناء على رقم Android 9 حتى يسمح بتثبيت كود الرجوع بـ-r دون خفض الرقم أو حذف بيانات الهاتف؛ مصدر المشروع المستعاد وخادمه يكونان 0.8.0.

## ملفات التسليم

`emergency-update.ncp` حمولة مضغوطة؛ `install.cjs` يتحقق منها ويفك الملفات إلى مواضعها الأصلية. `file-manifest.json` إصدار ومسارات وبصمات، و`compatibility.json` أساس التوافق، و`rollback.cjs` رجوع الكود، ومساعدات PowerShell، وتقرير الاختبارات والأدلة المهيكلة. لا إعدادات خاصة أو .env أو قواعد حقيقية أو مفاتيح توقيع أو نسخ بيانات ضمن ZIP.
