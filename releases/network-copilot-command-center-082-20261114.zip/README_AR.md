# تحديث مركز التحكم — Network Copilot 0.8.2+10

الحزمة لمشروعك القائم **0.8.1 / PostgreSQL 4**، سواء طُبق تصحيح واجهة R2 أم بقي المصدر الأصلي المعروف. تحدّث المصدر والخادم المجمّع داخل `runtime/v06` وتنتقل إلى المخطط 5. لا تنشئ مشروعًا متداخلًا، ولا تعيد الحساب أو MFA أو الشهادات أو التوقيع. تبقي ملفات package.json وpackage-lock.json الحالية وكاش npm/Flutter/Gradle. الدفع وواجهة بيع الكروت مؤجلان؛ إحصائيات YER تحسب قيمة أول تفعيل مثبت، وليست تحصيل المال.

## التطبيق

استخرج ZIP مباشرة في **`D:\copilot-command`** بحيث يوجد `install.cjs` داخله. أوقف نافذة خادم Node وFlutter بـCtrl+C، وأبق PostgreSQL يعمل، ثم:

```powershell
node "D:\copilot-command\install.cjs" "D:\NetWork-Ai"
if ($LASTEXITCODE -ne 0) { throw "توقف التحديث؛ احتفظ برسالة الخطأ ولا تكمل." }
```

يفحص سلامة الحمولة والتوافق قبل الكتابة، ويحفظ الملفات الأصلية، ثم يحدّث الكود وruntime، وينشئ نسخة بيانات مشفرة في المجلد الخاص قبل ترحيل 4 إلى 5. احتفظ بالمسارين اللذين يطبعهما:

- `Code backup`: داخل `D:\NetWork-Ai\.copilot-update-backups\command-v082-...`.
- `Encrypted pre-upgrade backup`: داخل `D:\network-copilot-private\before-command-....ncbak`، مع مفتاح `backup-v1.key` الموجود بالمجلد الخاص.

التكرار بعد النجاح آمن ولا يكرر الترحيل. تعديل محلي مجهول يوقف العملية قبل أي كتابة؛ لا تعدّل البصمات ولا تفرض الاستبدال. تُقبل BOM وCRLF وتنسيقات المسافات المعروفة في Dart. لا كتابة على RouterOS أثناء التثبيت. قراءة المتصلين والتفعيل تبقى اختيارية حتى تفعّلها من إعداد الرادار.

إذا ظهر `DATABASE UPGRADE INCOMPLETE`: أبق الخادم متوقفًا، واحتفظ بنسختي الكود والبيانات. صحح جاهزية PostgreSQL/الإعداد الخاص ثم أعد أمر التثبيت نفسه. قد يكون الترحيل التزم؛ لا يعيد المثبّت كودًا قديمًا تلقائيًا فوق مخطط أحدث. `--code-only` مخصص للاختبارات المعزولة وليس للتطبيق المعتاد.

## تشغيل الخادم وChrome

في نافذة PowerShell أولى، أبقها مفتوحة:

```powershell
cd "D:\NetWork-Ai"
node --use-env-proxy --env-file=.env ".\runtime\v06\dist\server.js" --foundation
```

انتظر رسالة الاستماع على `https://127.0.0.1:3443`. في نافذة ثانية:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "D:\copilot-command\test-chrome.ps1" -ProjectRoot "D:\NetWork-Ai"
if ($LASTEXITCODE -ne 0) { throw "توقف؛ أرسل نهاية نتيجة التحليل أو الاختبار." }
```

يشغّل `pub get --offline` ثم `analyze --no-pub` ثم `test --no-pub`، وبعد نجاحها يقدّم الواجهة على **`http://127.0.0.1:52100`**. افتحها في Chrome بالحساب والشهادة الحاليين. إذا كانت نافذة Flutter القديمة تعمل فأوقفها قبل هذه الخطوة. لا يعطّل التحقق من TLS، ولا يستخدم خدمة CDN أو ينزّل SDK أو يغيّر wrapper. إذا غاب عنصر من الكاش يتوقف لبيان العنصر المطلوب.

## أين تجد الإضافات

الرئيسية تبدأ برادار الطوارئ. بعدها اسم الشبكة واختصارات **إحصائيات الشبكة، قراءات مركز التحكم، سجل الشبكة والتنبيهات، إعدادات الرادار، الدخول وقيمة التفعيل**. تعديل الاسم للمالك. تظهر أعداد الأجهزة المصنفة والموارد وWAN وHotspot والمواقع وتغطية القياس؛ افتح جهازًا لتفاصيل الموارد والمنافذ والرسم واللاسلكي والحساسات والجلسات الحالية.

من **إعدادات الرادار → إحصائيات المتصلين وتفعيل الكروت** فعّل القراءة على راوتر الاختبار، ثم اطلب قياسًا. حسابات قديمة مستخدمة قبل التتبع تبقى بتاريخ مجهول. للكروت الخارجية اعتمد أسعار الفئات قبل أول فترة استخدام جديدة؛ الكرت العائد لا يكرر قيمته. تظهر الأرقام بالريال اليمني ويوم عدن.

داخل أي عطل افتح **تحليل العطل وخطة المعالجة**، راجع البيانات ثم وافق على الإرسال. يستخدم إعداد Gemini المحلي الحالي؛ لا تطلب الحزمة مفتاحًا جديدًا ولا تضم مفتاحك. AI يشرح ويتيح الانتقال إلى معاينة معالج معتمد؛ التنفيذ يحتاج صلاحية وحساب RouterOS مستقلًا وMFA واعتمادًا وتحققًا. لا ينفذ نص النموذج كأوامر. دليل الوظائف والمصدر والحدود في `FUNCTIONS_AR.md`، وقائمة التجربة في `ACCEPTANCE_AR.md`.

## الهاتف من الكاش وبالتوقيع الحالي

بعد نجاح فحوص Flutter، صل هاتفًا واحدًا بكابل ثابت وافتحه واسمح بتصحيح USB:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "D:\copilot-command\build-phone.ps1" -ProjectRoot "D:\NetWork-Ai"
```

يستدعي **Gradle 9.3.1-all من الكاش مباشرة** مع `--offline`، ويمنع تنزيل SDK/JDK، ويبقي wrapper 9.1.0. يبني arm64 باسم 0.8.2 ورقم 10، ثم يثبت بـ`adb -d install -r` بالتوقيع الموجود ويؤكد `reverse tcp:3443 tcp:3443`. لا uninstall أو مسح بيانات. للبناء دون توصيل الهاتف أثناء البناء أضف `-BuildOnly`. للتثبيت فقط دون إعادة البناء:

```powershell
$copilotAdb = @(
  "$env:ANDROID_HOME\platform-tools\adb.exe"
  "$env:LOCALAPPDATA\Android\Sdk\platform-tools\adb.exe"
  (Get-Command adb -ErrorAction SilentlyContinue).Source
) | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1
if (-not $copilotAdb) { throw "لم نجد adb الموجود لديك." }
& $copilotAdb -d install -r "D:\NetWork-Ai\apps\mobile\build\app\outputs\flutter-apk\app-debug.apk"
if ($LASTEXITCODE -ne 0) { throw "توقف التثبيت؛ أبق التطبيق وبياناته وأرسل السبب." }
powershell -NoProfile -ExecutionPolicy Bypass -File "D:\copilot-command\connect-phone.ps1" -AdbPath $copilotAdb
```

التحويل يعمل في الخلفية؛ عودة سطر PowerShell طبيعية. بعد فصل USB أو إعادة ADB أعد connect-phone. الخادم وحده يبقى مفتوحًا في نافذته. عند نقص مساحة الهاتف وفّر مساحة دون إزالة Network Copilot.

## الرجوع والتعافي

**رجوع الكود لا يخفض قاعدة البيانات 5.** أوقف الخادم، واستعمل مسار النسخة الذي طبعه المثبّت بالضبط:

```powershell
node "D:\copilot-command\rollback.cjs" "D:\NetWork-Ai" "D:\NetWork-Ai\.copilot-update-backups\command-v082-ضع-المعرف-المطبوع"
if ($LASTEXITCODE -ne 0) { throw "توقف الرجوع؛ لا تستبدل الملفات يدويًا وأرسل الرسالة." }
```

يعيد بايتات الملفات الأصلية ويحذف إضافات هذا التحديث فقط، ويرفض التعديلات اللاحقة أو نسخة تحديث آخر. يمكن تكراره. إذا لم يبدأ الترحيل وبقي المخطط 4، شغّل الكود المستعاد مباشرة. إذا وصل إلى 5 فلن يعمل خادم 0.8.1 عليه؛ استعد النسخة الأقدم إلى **قاعدة منفصلة** بالأداة القديمة التي عادت بعد رجوع الكود:

```powershell
cd "D:\NetWork-Ai"
$copilotRestoreDb = "copilot_restore_cc_" + (Get-Date -Format "yyyyMMdd_HHmmss")
node --env-file=.env ".\runtime\v06\scripts\restore-foundation.mjs" "D:\network-copilot-private\before-command-ضع-المعرف-المطبوع.ncbak" $copilotRestoreDb
if ($LASTEXITCODE -ne 0) { throw "توقفت الاستعادة؛ قاعدة التشغيل الحالية محفوظة." }
$env:COPILOT_FOUNDATION_CONFIG = "D:\network-copilot-private\$copilotRestoreDb.private.json"
node --use-env-proxy --env-file=.env ".\runtime\v06\dist\server.js" --foundation
```

تنشأ قاعدة مخطط 4 وإعداد خاص جديدان، دون الكتابة فوق قاعدة 5 أو تغيير ملف الإعداد الأصلي. اختيار الإعداد مؤقت في نافذة PowerShell. الحسابات وكلمات المرور وTOTP والأسرار تعود، و**جلسات النسخة المستعادة تُلغى عمدًا**؛ سجل الدخول بنفس الحساب والرمز دون إعادة تجهيز. بيانات أضيفت بعد النسخة القديمة لا تكون فيها؛ احتفظ بقاعدة 5 للمراجعة ولا تحذفها آليًا. بعد الرجوع يمكن إعادة بناء الهاتف من المصدر المستعاد وبالتوقيع نفسه؛ مساعد البناء يبقي رقم Android 10 لتثبيت الرجوع بـ-r دون حذف البيانات، رغم أن مصدر الوظيفة المستعاد 0.8.1.

## التحقق وحدود التسليم

تقرير النتائج الفعلية `TEST_REPORT_AR.md` وأدلته JSON داخل الحزمة. نجحت اختبارات الخادم والمثبت والترحيل والاستعادة المعزولة. **لم تُنفذ Flutter analyze/test أو APK أو Chrome حقيقي أو تجربة هاتف/CHR أو استدعاء Gemini فعلي هنا**؛ فحص قواعد Dart لا يحل محلها. لا تعتبر الرئيسية مغلقة بكل أفكار الخطة: القائمة الدقيقة للوظائف المتقدمة غير المنفذة في `HOME_SCOPE_AR.md`. لا تنقل SQLite أو بيانات صديقك أو أسراره.

الحمولة `command-update.ncp` مضغوطة ومتحقق منها؛ يفكها المثبّت إلى المسارات الأصلية. `file-manifest.json` للإصدار ومسارات الملفات وبصماتها، و`compatibility.json` يحتوي بيانات التوافق وبصمات فقط. لا .env أو إعدادات خاصة أو قاعدة بيانات حقيقية أو مفتاح توقيع أو نسخة بيانات ضمن ZIP.
