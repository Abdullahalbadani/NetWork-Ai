param([string]$AdbPath = '')
$ErrorActionPreference = 'Stop'
$copilotAdb = $AdbPath
if (-not $copilotAdb) {
    $copilotAdb = @(
        "$env:ANDROID_HOME\platform-tools\adb.exe"
        "$env:LOCALAPPDATA\Android\Sdk\platform-tools\adb.exe"
        (Get-Command adb -ErrorAction SilentlyContinue).Source
    ) | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1
}
if (-not $copilotAdb -or -not (Test-Path -LiteralPath $copilotAdb)) {
    throw 'Existing adb was not found. No tools were downloaded.'
}
& $copilotAdb -d get-state
if ($LASTEXITCODE -ne 0) { throw 'Connect and authorize one USB Android phone, then retry.' }
& $copilotAdb -d reverse tcp:3443 tcp:3443
if ($LASTEXITCODE -ne 0) { throw 'USB forwarding could not be created.' }
$copilotForwardRows = @(& $copilotAdb -d reverse --list)
if ($LASTEXITCODE -ne 0 -or -not ($copilotForwardRows -match '(?:^|\s)tcp:3443\s+tcp:3443(?:\s|$)')) {
    throw 'USB forwarding was not confirmed. Keep the existing app and inspect the connection.'
}
$copilotForwardRows | ForEach-Object { Write-Host $_ }
Write-Host 'USB forwarding 3443 is confirmed. It runs in the background; reconnect it after a USB or ADB restart.'
