param([string]$ProjectRoot = 'D:\NetWork-Ai')
$ErrorActionPreference = 'Stop'
$copilotProject = (Resolve-Path -LiteralPath $ProjectRoot).Path
$copilotProperties = Join-Path $copilotProject 'apps\mobile\android\local.properties'
$copilotLine = Get-Content -LiteralPath $copilotProperties | Where-Object { $_ -match '^flutter.sdk=' } | Select-Object -First 1
if (-not $copilotLine) { throw 'Existing flutter.sdk was not found. No SDK was downloaded.' }
$copilotSdk = $copilotLine.Substring(12).Replace('\\', '\').Replace('\:', ':')
$copilotFlutter = Join-Path $copilotSdk 'bin\flutter.bat'
if (-not (Test-Path -LiteralPath $copilotFlutter)) { throw 'Existing Flutter SDK was not found.' }
Push-Location (Join-Path $copilotProject 'apps\mobile')
try {
    & $copilotFlutter --no-version-check pub get --offline
    if ($LASTEXITCODE -ne 0) { throw 'Offline dependency resolution failed. Inspect the missing cached item.' }
    & $copilotFlutter --no-version-check analyze --no-pub
    if ($LASTEXITCODE -ne 0) { throw 'Flutter analysis failed. Keep the current installed phone app.' }
    & $copilotFlutter --no-version-check test --no-pub
    if ($LASTEXITCODE -ne 0) { throw 'Flutter tests failed. Keep the current installed phone app.' }
} finally { Pop-Location }
Write-Host 'Client checks passed locally. CHR and physical phone acceptance still apply.'
