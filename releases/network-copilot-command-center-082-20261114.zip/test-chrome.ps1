param([string]$ProjectRoot = 'D:\NetWork-Ai')
$ErrorActionPreference = 'Stop'
$copilotProject = (Resolve-Path -LiteralPath $ProjectRoot).Path
& (Join-Path $PSScriptRoot 'verify-client.ps1') -ProjectRoot $copilotProject
if ($LASTEXITCODE -ne 0) { throw 'Client checks failed. Chrome was not started.' }
$copilotProperties = Join-Path $copilotProject 'apps\mobile\android\local.properties'
$copilotLine = Get-Content -LiteralPath $copilotProperties | Where-Object { $_ -match '^flutter.sdk=' } | Select-Object -First 1
if (-not $copilotLine) { throw 'Existing flutter.sdk was not found. No SDK was downloaded.' }
$copilotSdk = $copilotLine.Substring(12).Replace('\\', '\').Replace('\:', ':')
$copilotFlutter = Join-Path $copilotSdk 'bin\flutter.bat'
if (-not (Test-Path -LiteralPath $copilotFlutter)) { throw 'Existing Flutter SDK was not found.' }
Write-Host 'Keep the Node server running on https://127.0.0.1:3443 in its separate window.'
Write-Host 'When Flutter is ready, open http://127.0.0.1:52100 in Chrome and use your existing account and MFA.'
Push-Location (Join-Path $copilotProject 'apps\mobile')
try {
    & $copilotFlutter --suppress-analytics --no-version-check run -d web-server --no-pub --no-web-resources-cdn --web-hostname 127.0.0.1 --web-port 52100
    if ($LASTEXITCODE -ne 0) { throw 'Web launch failed. Send the reported Flutter error.' }
} finally { Pop-Location }
