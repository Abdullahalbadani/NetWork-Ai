'use strict';
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),zlib=require('node:zlib');
const expectedPayload='824a4ce8d4d1a03eb2fd8616f2c19bc27f24c2eceb1790c4c7e06f074f475c1c',expectedRunner='19575e781d2d38104b445d1b6ceacb0e98a66fe9067f377f3d238639e2d64b30';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
try{
 if(Number(process.versions.node.split('.')[0])<24)throw Error('Node 24 or newer is required');
 if(process.argv.length!==3)throw Error('Usage: node install.cjs "D:\\NetWork-Ai"');
 const root=path.resolve(process.argv[2]);
 if(!fs.existsSync(root)||fs.lstatSync(root).isSymbolicLink()||!fs.statSync(root).isDirectory())throw Error('EXISTING_PROJECT_REQUIRED');
 const runnerPath=path.join(__dirname,'apply-foundation-update.cjs'),payloadPath=path.join(__dirname,'tests-update.ncp');
 for(const[file,hash]of[[runnerPath,expectedRunner],[payloadPath,expectedPayload]]){const s=fs.lstatSync(file);if(!s.isFile()||s.isSymbolicLink()||s.size>1024*1024||sha(fs.readFileSync(file))!==hash)throw Error('DELIVERY_INTEGRITY_FAILED');}
 const runner=require(runnerPath);
 const marker=p=>{const f=runner.safePath(root,p),s=fs.statSync(f);if(!s.isFile()||s.size>1024*1024)throw Error('INVALID_PROJECT_MARKER');return fs.readFileSync(f,'utf8').replace(/^\uFEFF/,'');};
 const metadata=JSON.parse(marker('package.json')),runtime=JSON.parse(marker('runtime/v06/package.json')),pubspec=marker('apps/mobile/pubspec.yaml');
 if(metadata.name!=='network-copilot'||runtime.name!=='network-copilot-runtime'||runtime.version!=='0.8.2'||!/^name:\s*network_copilot\s*$/m.test(pubspec)||!/^version:\s*0\.8\.2\+10\s*$/m.test(pubspec))throw Error('INSTALLED_082_SOURCE_REQUIRED');
 const bytes=fs.readFileSync(payloadPath),pkg=JSON.parse(zlib.brotliDecompressSync(bytes,{maxOutputLength:1024*1024}));
 if(pkg.version!=='command-v082'||pkg.patchVersion!=='command-client-tests-r1-20261114'||!Array.isArray(pkg.files)||pkg.files.length!==1||pkg.files[0].path!=='apps/mobile/test/command_test.dart')throw Error('TEST_PATCH_SCOPE_REFUSED');
 const lockPath=path.join(root,'.copilot-integration.lock');let lock,temporary;
 try{lock=fs.openSync(lockPath,'wx',0o600);temporary=fs.mkdtempSync(path.join(os.tmpdir(),'copilot-command-tests-r1-'));const hex=path.join(temporary,'payload.hex');fs.writeFileSync(hex,bytes.toString('hex'),{flag:'wx',mode:0o600});const result=runner.apply(root,hex,expectedPayload,()=>{});if(result.changed){console.log('Command test harness R1 installed. Files: '+result.changed);console.log('Code backup: '+result.backup);}else console.log('Command test harness R1 is already installed.');}
 finally{if(temporary)fs.rmSync(temporary,{recursive:true,force:true});if(lock!==undefined){fs.closeSync(lock);fs.unlinkSync(lockPath);}}
 console.log('One Flutter test file updated. Application source, runtime, schema 5, accounts, MFA, private settings, signing and caches preserved. No migration, dependency download or RouterOS write. Rerun test-chrome.ps1.');
}catch(e){console.error('Test fix stopped: '+(e.code==='EEXIST'?'INSTALL_LOCK_EXISTS: inspect the existing installer lock before retrying':e.message));process.exitCode=1;}
