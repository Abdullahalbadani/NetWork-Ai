'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const runnerPath=path.join(__dirname,'apply-foundation-update.cjs');if(crypto.createHash('sha256').update(fs.readFileSync(runnerPath)).digest('hex')!=='19575e781d2d38104b445d1b6ceacb0e98a66fe9067f377f3d238639e2d64b30')throw Error('RUNNER_HASH_MISMATCH');const {safePath,allowedPath}=require(runnerPath);
const sha=value=>crypto.createHash('sha256').update(value).digest('hex');
function rollback(rootArg,backupArg){
 const root=path.resolve(rootArg),backup=path.resolve(backupArg);
 const relative=path.relative(root,backup).replaceAll('\\','/');
 if(!/^\.copilot-update-backups\/(?:foundation-v06|health-v07|operations-v08|emergency-v081|command-v082)-/.test(relative)||safePath(root,relative)!==backup)throw Error('Choose the exact update backup inside this project');
 const manifestPath=safePath(root,relative+'/update.json');
 if(fs.statSync(manifestPath).size>1024*1024)throw Error('Invalid backup manifest');
 const manifest=JSON.parse(fs.readFileSync(manifestPath,'utf8'));
 if(!['foundation-v06','health-v07','operations-v08','emergency-v081','command-v082'].includes(manifest.version)||!Array.isArray(manifest.files)||manifest.files.length>2500)throw Error('Invalid backup version');
 if(manifest.version!=='command-v082'||manifest.files.length!==1||manifest.files[0].path!=='apps/mobile/test/command_test.dart'||manifest.files[0].after!=='833a5891f949abec6090a4bbdb9f1d9108ecd16b9305bd790453307d84f0e035')throw Error('Choose the exact command test harness R1 backup printed by this installer');
 const plan=[],seen=new Set();
 for(const row of manifest.files){
  if(!row||!allowedPath(row.path)||seen.has(row.path)||typeof row.existed!=='boolean'||!/^[a-f0-9]{64}$/.test(row.after)||row.existed&&!/^[a-f0-9]{64}$/.test(row.before)||!row.existed&&row.before!==null)throw Error('Invalid rollback scope');seen.add(row.path);
  const target=safePath(root,row.path),saved=safePath(root,relative+'/'+row.path);
  for(const file of [target,...(row.existed?[saved]:[])])if(fs.existsSync(file)&&(!fs.statSync(file).isFile()||fs.statSync(file).size>16*1024*1024))throw Error('Invalid rollback file');
  const current=fs.existsSync(target)?fs.readFileSync(target):null;
  if(row.existed && current && sha(current)===row.before)continue;
  if(!row.existed && current===null)continue;
  if(!current||sha(current)!==row.after)throw Error('File changed after update; preserved: '+row.path);
  const previous=row.existed?fs.readFileSync(saved):null;
  if(previous&&sha(previous)!==row.before)throw Error('Backup hash mismatch');
  plan.push({target,previous,current});
 }
 const changed=[],staged=[],lockPath=path.join(root,'.copilot-integration.lock');let lock;
 try{
  lock=fs.openSync(lockPath,'wx',0o600);
  // Stage original bytes before changing any destination; backups stay intact.
  for(const row of plan)if(row.previous){row.temporary=row.target+'.rollback-'+crypto.randomUUID()+'.tmp';staged.push(row.temporary);fs.writeFileSync(row.temporary,row.previous,{flag:'wx',mode:row.target.endsWith('/gradlew')?0o700:0o600});}
  for(const row of plan){const current=fs.existsSync(row.target)?fs.readFileSync(row.target):null;if(!current||!row.current||!current.equals(row.current))throw Error('File changed during rollback');if(row.previous)fs.renameSync(row.temporary,row.target);else fs.unlinkSync(row.target);changed.push(row);}
 }catch(error){
  for(const row of changed.reverse()){const value=fs.existsSync(row.target)?fs.readFileSync(row.target):null;if((row.previous&&value&&sha(value)===sha(row.previous))||(!row.previous&&value===null))fs.writeFileSync(row.target,row.current);}
  throw error;
 }finally{for(const file of staged)if(fs.existsSync(file))fs.unlinkSync(file);if(lock!==undefined){fs.closeSync(lock);fs.unlinkSync(lockPath);}}
 console.log('Code update rolled back. The foundation database and protected configuration were preserved.');
}
if(require.main===module){try{rollback(...process.argv.slice(2));}catch(e){console.error('Rollback stopped: '+e.message);process.exitCode=1;}}
module.exports={rollback};
