# Read-only guard for this known CHR lab.
{
    :local board [/system resource get board-name]
    :if (!($board ~ "CHR")) do={ :error "CHR_LAB_REQUIRED" }
    :local ros [/system resource get version]
    :if ([:pick $ros 0 2] != "7.") do={ :error "ROUTEROS7_REQUIRED" }
    :local hs [/ip hotspot find where name="hotspot1"]
    :if ([:len $hs] != 1) do={ :error "HOTSPOT1_REQUIRED" }
    :if ([/ip hotspot get $hs interface] != "ether3") do={ :error "HOTSPOT_INTERFACE_CHANGED" }
    :if ([/ip hotspot get $hs disabled] = true) do={ :error "HOTSPOT_DISABLED" }
    :if ([:len [/ip address find where address="192.168.56.10/24" and interface="ether2" and disabled=no]] != 1) do={ :error "MANAGEMENT_BINDING_CHANGED" }
    :local httpsService [/ip service find where name="www-ssl" and dynamic=no]
    :if ([:len $httpsService] != 1) do={ :error "STATIC_HTTPS_SERVICE_REQUIRED" }
    :if ([/ip service get $httpsService port] != 8443) do={ :error "HTTPS_PORT_CHANGED" }
    :put "NCP_LAB_PREFLIGHT_OK"
    :put ("TOTAL_HOTSPOT_USERS=" . [:len [/ip hotspot user find]])
    :put ("ACTIVE_SESSIONS=" . [:len [/ip hotspot active find]])
}
