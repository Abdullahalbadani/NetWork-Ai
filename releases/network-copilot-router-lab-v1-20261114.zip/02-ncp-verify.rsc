# Read-only verification. Never prints passwords or original card names.
{
    :local board [/system resource get board-name]
    :if (!($board ~ "CHR")) do={ :error "CHR_LAB_REQUIRED" }
    :local ros [/system resource get version]
    :if ([:pick $ros 0 2] != "7.") do={ :error "ROUTEROS7_REQUIRED" }
    :local hs [/ip hotspot find where name="hotspot1"]
    :if ([:len $hs] != 1) do={ :error "HOTSPOT1_REQUIRED" }
    :if ([/ip hotspot get $hs interface] != "ether3") do={ :error "HOTSPOT_INTERFACE_CHANGED" }
    :if ([/ip hotspot get $hs disabled] = true) do={ :error "HOTSPOT_DISABLED" }
    :if ([:len [/ip address find where address="192.168.56.10/24" and interface="ether2" and disabled=no]] != 1) do={ :error "MANAGEMENT_BINDING_CHANGED" }
    :local httpsService [/ip service find where name="www-ssl" and dynamic=no]
    :if ([:len $httpsService] != 1) do={ :error "STATIC_HTTPS_SERVICE_REQUIRED" }
    :if ([/ip service get $httpsService port] != 8443) do={ :error "HTTPS_PORT_CHANGED" }
    {
        :local item [/ip hotspot user profile find where name="ncp-lab-main-v1"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_PROFILE" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user profile get $item on-logout] != "# NCP-LAB-V1-20261114") || ([/ip hotspot user profile get $item on-login] != "") || ([/ip hotspot user profile get $item shared-users] != 1) || ([/ip hotspot user profile get $item rate-limit] != "2M/2M") || ([/ip hotspot user profile get $item add-mac-cookie] != false) || ([/ip hotspot user profile get $item transparent-proxy] != false)) do={ :error "UNKNOWN_OR_CHANGED_PROFILE" }
        }
    }
    {
        :local item [/ip hotspot user profile find where name="ncp-lab-shared-v1"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_PROFILE" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user profile get $item on-logout] != "# NCP-LAB-V1-20261114") || ([/ip hotspot user profile get $item on-login] != "") || ([/ip hotspot user profile get $item shared-users] != 2) || ([/ip hotspot user profile get $item rate-limit] != "2M/2M") || ([/ip hotspot user profile get $item add-mac-cookie] != false) || ([/ip hotspot user profile get $item transparent-proxy] != false)) do={ :error "UNKNOWN_OR_CHANGED_PROFILE" }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-500-01"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-main-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 16777216) || ([/ip hotspot user get $item limit-uptime] != 60m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-500-02"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-main-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 16777216) || ([/ip hotspot user get $item limit-uptime] != 60m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-500-03"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-main-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 16777216) || ([/ip hotspot user get $item limit-uptime] != 60m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-1000-01"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-main-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 33554432) || ([/ip hotspot user get $item limit-uptime] != 120m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-1000-02"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-main-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 33554432) || ([/ip hotspot user get $item limit-uptime] != 120m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-free-01"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-main-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 8388608) || ([/ip hotspot user get $item limit-uptime] != 30m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-unknown-01"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-main-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 12582912) || ([/ip hotspot user get $item limit-uptime] != 45m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-disabled-01"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-main-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 16777216) || ([/ip hotspot user get $item limit-uptime] != 60m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-short-01"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-main-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 2097152) || ([/ip hotspot user get $item limit-uptime] != 2m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-shared-01"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_USER" }
        :if ([:len $item] = 1) do={
            :if (([/ip hotspot user get $item comment] != "NCP-LAB-V1-20261114") || ([/ip hotspot user get $item profile] != "ncp-lab-shared-v1") || ([/ip hotspot user get $item server] != "hotspot1") || ([/ip hotspot user get $item limit-bytes-total] != 16777216) || ([/ip hotspot user get $item limit-uptime] != 60m)) do={ :error "UNKNOWN_OR_CHANGED_USER" }
        }
    }
    {
        :local item [/interface find where name="ncp-lab-link-v1"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_LAB_INTERFACE" }
        :if ([:len $item] = 1) do={
            :if ([/interface get $item type] != "vlan") do={ :error "LAB_INTERFACE_NAME_COLLISION" }
            :if (([/interface vlan get $item comment] != "NCP-LAB-V1-20261114") || ([/interface vlan get $item interface] != "ether3") || ([/interface vlan get $item vlan-id] != 4093)) do={ :error "UNKNOWN_OR_CHANGED_LAB_VLAN" }
        }
    }
    :local present 0
    {
        :local item [/ip hotspot user find where name="ncp-lab-500-01"]
        :if ([:len $item] != 1) do={ :error "LAB_CARD_MISSING" }
        :set present ($present + 1)
        :put ("ncp-lab-500-01 profile=" . [/ip hotspot user get $item profile] . " disabled=" . [/ip hotspot user get $item disabled] . " uptime=" . [/ip hotspot user get $item uptime])
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-500-02"]
        :if ([:len $item] != 1) do={ :error "LAB_CARD_MISSING" }
        :set present ($present + 1)
        :put ("ncp-lab-500-02 profile=" . [/ip hotspot user get $item profile] . " disabled=" . [/ip hotspot user get $item disabled] . " uptime=" . [/ip hotspot user get $item uptime])
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-500-03"]
        :if ([:len $item] != 1) do={ :error "LAB_CARD_MISSING" }
        :set present ($present + 1)
        :put ("ncp-lab-500-03 profile=" . [/ip hotspot user get $item profile] . " disabled=" . [/ip hotspot user get $item disabled] . " uptime=" . [/ip hotspot user get $item uptime])
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-1000-01"]
        :if ([:len $item] != 1) do={ :error "LAB_CARD_MISSING" }
        :set present ($present + 1)
        :put ("ncp-lab-1000-01 profile=" . [/ip hotspot user get $item profile] . " disabled=" . [/ip hotspot user get $item disabled] . " uptime=" . [/ip hotspot user get $item uptime])
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-1000-02"]
        :if ([:len $item] != 1) do={ :error "LAB_CARD_MISSING" }
        :set present ($present + 1)
        :put ("ncp-lab-1000-02 profile=" . [/ip hotspot user get $item profile] . " disabled=" . [/ip hotspot user get $item disabled] . " uptime=" . [/ip hotspot user get $item uptime])
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-free-01"]
        :if ([:len $item] != 1) do={ :error "LAB_CARD_MISSING" }
        :set present ($present + 1)
        :put ("ncp-lab-free-01 profile=" . [/ip hotspot user get $item profile] . " disabled=" . [/ip hotspot user get $item disabled] . " uptime=" . [/ip hotspot user get $item uptime])
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-unknown-01"]
        :if ([:len $item] != 1) do={ :error "LAB_CARD_MISSING" }
        :set present ($present + 1)
        :put ("ncp-lab-unknown-01 profile=" . [/ip hotspot user get $item profile] . " disabled=" . [/ip hotspot user get $item disabled] . " uptime=" . [/ip hotspot user get $item uptime])
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-disabled-01"]
        :if ([:len $item] != 1) do={ :error "LAB_CARD_MISSING" }
        :set present ($present + 1)
        :put ("ncp-lab-disabled-01 profile=" . [/ip hotspot user get $item profile] . " disabled=" . [/ip hotspot user get $item disabled] . " uptime=" . [/ip hotspot user get $item uptime])
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-short-01"]
        :if ([:len $item] != 1) do={ :error "LAB_CARD_MISSING" }
        :set present ($present + 1)
        :put ("ncp-lab-short-01 profile=" . [/ip hotspot user get $item profile] . " disabled=" . [/ip hotspot user get $item disabled] . " uptime=" . [/ip hotspot user get $item uptime])
    }
    {
        :local item [/ip hotspot user find where name="ncp-lab-shared-01"]
        :if ([:len $item] != 1) do={ :error "LAB_CARD_MISSING" }
        :set present ($present + 1)
        :put ("ncp-lab-shared-01 profile=" . [/ip hotspot user get $item profile] . " disabled=" . [/ip hotspot user get $item disabled] . " uptime=" . [/ip hotspot user get $item uptime])
    }
    :if ([:len [/interface vlan find where name="ncp-lab-link-v1"]] != 1) do={ :error "LAB_LINK_MISSING" }
    :put ("LAB_LINK_DISABLED=" . [/interface vlan get [/interface vlan find where name="ncp-lab-link-v1"] disabled])
    :put ("LAB_USERS=" . $present)
    :put ("TOTAL_HOTSPOT_USERS=" . [:len [/ip hotspot user find]])
    :put ("ACTIVE_SESSIONS=" . [:len [/ip hotspot active find]])
}
