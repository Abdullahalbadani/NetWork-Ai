# Run only when this ONE isolated fault is the agreed test.
{
    :local board [/system resource get board-name]
    :if (!($board ~ "CHR")) do={ :error "CHR_LAB_REQUIRED" }
    :local ros [/system resource get version]
    :if ([:pick $ros 0 2] != "7.") do={ :error "ROUTEROS7_REQUIRED" }
    :local hs [/ip hotspot find where name="hotspot1"]
    :if ([:len $hs] != 1) do={ :error "HOTSPOT1_REQUIRED" }
    :if ([/ip hotspot get $hs interface] != "ether3") do={ :error "HOTSPOT_INTERFACE_CHANGED" }
    :if ([/ip hotspot get $hs disabled] = true) do={ :error "HOTSPOT_DISABLED" }
    :if ([:len [/ip address find where address="192.168.56.10/24" and interface="ether2" and disabled=no]] != 1) do={ :error "MANAGEMENT_BINDING_CHANGED" }
    :local httpsService [/ip service find where name="www-ssl" and dynamic=no]
    :if ([:len $httpsService] != 1) do={ :error "STATIC_HTTPS_SERVICE_REQUIRED" }
    :if ([/ip service get $httpsService port] != 8443) do={ :error "HTTPS_PORT_CHANGED" }
    {
        :local item [/interface find where name="ncp-lab-link-v1"]
        :if ([:len $item] > 1) do={ :error "DUPLICATE_LAB_INTERFACE" }
        :if ([:len $item] = 1) do={
            :if ([/interface get $item type] != "vlan") do={ :error "LAB_INTERFACE_NAME_COLLISION" }
            :if (([/interface vlan get $item comment] != "NCP-LAB-V1-20261114") || ([/interface vlan get $item interface] != "ether3") || ([/interface vlan get $item vlan-id] != 4093)) do={ :error "UNKNOWN_OR_CHANGED_LAB_VLAN" }
        }
    }
    :if ([:len [/interface find where name="ncp-lab-link-v1"]] = 1) do={
        :if ([:len [/ip address find where interface="ncp-lab-link-v1"]] > 0) do={ :error "LAB_VLAN_HAS_IP_STOP" }
        :if ([:len [/ipv6 address find where interface="ncp-lab-link-v1" and dynamic=no]] > 0) do={ :error "LAB_VLAN_HAS_STATIC_IPV6_STOP" }
        :if ([:len [/interface bridge port find where interface="ncp-lab-link-v1"]] > 0) do={ :error "LAB_VLAN_ATTACHED_TO_BRIDGE_STOP" }
        :if ([:len [/ip dhcp-server find where interface="ncp-lab-link-v1"]] > 0) do={ :error "LAB_VLAN_HAS_DHCP_SERVER_STOP" }
        :if ([:len [/ip dhcp-client find where interface="ncp-lab-link-v1"]] > 0) do={ :error "LAB_VLAN_HAS_DHCP_CLIENT_STOP" }
        :if ([:len [/ip hotspot find where interface="ncp-lab-link-v1"]] > 0) do={ :error "LAB_VLAN_HAS_HOTSPOT_STOP" }
        :if ([:len [/interface vlan find where interface="ncp-lab-link-v1"]] > 0) do={ :error "LAB_VLAN_HAS_CHILD_STOP" }
    }
    :if ([:len [/interface vlan find where name="ncp-lab-link-v1"]] != 1) do={ :error "LAB_LINK_MISSING" }
    /interface vlan set [/interface vlan find where name="ncp-lab-link-v1"] disabled=no
    :put "NCP_LAB_LINK_UP"
}
