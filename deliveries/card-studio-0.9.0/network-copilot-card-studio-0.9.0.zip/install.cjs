'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),os=require('node:os'),net=require('node:net'),zlib=require('node:zlib'),child=require('node:child_process');
const payloadHash='984537ebce897db8002db80a3df7ec822e6e08cfc89ef18eab2591bd92de6b46',runnerHash='0aa4d9799c1e374947bf6f4dcb1eddf74143a06e9d02c36b9e7e56005e9c6ee6',compatHash='64b50bc3413fa6c9e480489c8b6de8497e97befa8272563d926d27e301bc92a0',patch='card-studio-090-20261119';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),canonical=b=>Buffer.from(b.toString('utf8').replace(/^\uFEFF/,'').replace(/\r\n/g,'\n'));
async function serverStopped(){const active=await new Promise(resolve=>{const s=net.connect({host:'127.0.0.1',port:3443});let done=false;const end=v=>{if(done)return;done=true;s.destroy();resolve(v);};s.setTimeout(1000);s.once('connect',()=>end(true));s.once('error',e=>end(e.code!=='ECONNREFUSED'));s.once('timeout',()=>end(true));});if(active)throw Error('SERVER_RUNNING: stop server 3443 before applying this update.');}
function databaseReady(root){
 const source=`import{pathToFileURL}from'node:url';import{resolve}from'node:path';const root=process.argv[1];try{const{loadFoundationConfig}=await import(pathToFileURL(resolve(root,'runtime/v06/dist/foundation/config.js')));const{createPool}=await import(pathToFileURL(resolve(root,'runtime/v06/dist/foundation/database.js')));const c=await loadFoundationConfig(process.env.COPILOT_FOUNDATION_CONFIG??resolve(root,'../network-copilot-private/foundation.private.json'),root);const db=createPool(c.database);try{const v=Number((await db.query('SELECT max(version) AS version FROM copilot.schema_version')).rows[0]?.version);if(v!==5&&v!==6)throw Error();const role=(await db.query("SELECT r.rolsuper,r.rolbypassrls,r.rolcreaterole,r.rolcreatedb,EXISTS(SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname IN ('copilot','copilot_auth') AND c.relowner=r.oid) AS owns_tables FROM pg_roles r WHERE r.rolname=current_user")).rows[0];if(!role||role.rolsuper||role.rolbypassrls||role.rolcreaterole||role.rolcreatedb||role.owns_tables)throw Error();console.log('Database preflight: schema '+v+' is compatible.');}finally{await db.end();}}catch{console.error('Database preflight failed. Check private configuration and database readiness. No code files were written.');process.exitCode=1;}`;
 const r=child.spawnSync(process.execPath,['--env-file-if-exists=.env','--input-type=module','-e',source,root],{cwd:root,stdio:'inherit',windowsHide:true,timeout:20000});if(r.error||r.status!==0)throw Error('DATABASE_PREFLIGHT_FAILED: no code files were written.');
}
async function main(){
 const args=process.argv.slice(2),check=args.includes('--check'),codeOnly=args.includes('--code-only'),pos=args.filter(a=>!['--check','--code-only'].includes(a));
 if(pos.length!==1||check&&codeOnly||args.some(a=>a.startsWith('--')&&!['--check','--code-only'].includes(a)))throw Error('Usage: node install.cjs "D:\\NetWork-Ai" [--check | --code-only]');
 if(Number(process.versions.node.split('.')[0])<24)throw Error('Node 24 or newer is required.');
 const root=path.resolve(pos[0]);if(!fs.existsSync(root)||fs.lstatSync(root).isSymbolicLink()||!fs.statSync(root).isDirectory())throw Error('EXISTING_PROJECT_REQUIRED');
 const payloadPath=path.join(__dirname,'studio-update.ncp'),runnerPath=path.join(__dirname,'apply-foundation-update.cjs'),compatPath=path.join(__dirname,'compatibility.json');
 for(const[file,hash]of[[payloadPath,payloadHash],[runnerPath,runnerHash],[compatPath,compatHash]]){const stat=fs.lstatSync(file);if(!stat.isFile()||stat.isSymbolicLink()||stat.size>32*1024*1024||sha(fs.readFileSync(file))!==hash)throw Error('DELIVERY_INTEGRITY_FAILED: '+path.basename(file));}
 const runner=require(runnerPath),compat=JSON.parse(fs.readFileSync(compatPath,'utf8'));
 const marker=p=>{const f=runner.safePath(root,p),s=fs.statSync(f);if(!s.isFile()||s.size>1024*1024)throw Error('INVALID_PROJECT_MARKER');return fs.readFileSync(f,'utf8').replace(/^\uFEFF/,'');};
 const metadata=JSON.parse(marker('package.json')),runtime=JSON.parse(marker('runtime/v06/package.json')),pubspec=marker('apps/mobile/pubspec.yaml');
 if(metadata.name!=='network-copilot'||runtime.name!=='network-copilot-runtime'||!['0.8.2','0.9.0'].includes(runtime.version)||!/^name:\s*network_copilot\s*$/m.test(pubspec)||!/^version:\s*(?:0\.8\.2\+10|0\.9\.0\+11)\s*$/m.test(pubspec))throw Error('CONFIRMED_082_SCHEMA5_BASELINE_REQUIRED');
 if(compat.patch!==patch||!Array.isArray(compat.files)||compat.files.length>2500)throw Error('INVALID_COMPATIBILITY_MANIFEST');
 for(const item of compat.files){
  if(!runner.allowedPath(item.path))throw Error('INVALID_COMPATIBILITY_PATH');const file=runner.safePath(root,item.path);let bytes=null;
  if(fs.existsSync(file)){const stat=fs.lstatSync(file);if(!stat.isFile()||stat.size>16*1024*1024)throw Error('INVALID_BASELINE_FILE: '+item.path);bytes=fs.readFileSync(file);}
  const hash=bytes?sha(item.binary?bytes:canonical(bytes)):null;let known=Array.isArray(item.hashes)&&item.hashes.includes(hash);
  if(!known&&bytes&&item.path.endsWith('.dart')&&Array.isArray(item.sourceHashes)){try{known=item.sourceHashes.includes(runner.sourceHash(bytes));}catch{}}
  if(!known)throw Error('UNKNOWN_LOCAL_EDIT: '+item.path+'; no files were written.');
 }
 const bytes=fs.readFileSync(payloadPath),pkg=JSON.parse(zlib.brotliDecompressSync(bytes,{maxOutputLength:64*1024*1024}));
 if(pkg.version!=='studio-v090'||pkg.patchVersion!==patch||!Array.isArray(pkg.files)||pkg.files.length!==77)throw Error('INVALID_PAYLOAD');
 const seen=new Set();for(const f of pkg.files){if(!runner.allowedPath(f.path)||seen.has(f.path)||sha(Buffer.from(f.content,'base64'))!==f.after)throw Error('INVALID_PAYLOAD_ENTRY');seen.add(f.path);}
 if(check){console.log('Compatible with the confirmed 0.8.2/schema5 baseline or this installed 0.9.0 update. Read-only check: no files or database records were written.');return;}
 await serverStopped();const lockPath=path.join(root,'.copilot-integration.lock');let lock,temp;
 try{
  lock=fs.openSync(lockPath,'wx',0o600);fs.writeFileSync(lock,JSON.stringify({pid:process.pid,patch,startedAt:new Date().toISOString()}));
  if(!codeOnly)databaseReady(root);
  temp=fs.mkdtempSync(path.join(os.tmpdir(),'copilot-studio-'));const hex=path.join(temp,'payload.hex');fs.writeFileSync(hex,bytes.toString('hex'),{flag:'wx',mode:0o600});
  const result=runner.apply(root,hex,payloadHash,()=>{});
  if(result.changed){console.log('Card studio code installed. Files: '+result.changed);console.log('Code backup: '+result.backup);}else console.log('Card studio code is already installed.');
  console.log('Existing package.json/package-lock.json, private settings, signing, startup and caches were preserved. No npm install.');
  if(codeOnly){console.log('CODE ONLY: database untouched. Before starting the updated server, run runtime/v06/scripts/upgrade-studio-foundation.mjs.');return;}
  const migration=child.spawnSync(process.execPath,['--env-file-if-exists=.env',path.join(root,'runtime/v06/scripts/upgrade-studio-foundation.mjs')],{cwd:root,stdio:'inherit',windowsHide:true,timeout:120000});
  if(migration.error||migration.status!==0){console.error('DATABASE UPGRADE INCOMPLETE. Keep the server stopped. Preserve the code and encrypted backups. Correct readiness and rerun. Code was not automatically rolled back because schema6 may already be committed.');process.exitCode=1;return;}
  console.log('Ready: runtime/v06 version0.9.0, schema6. Existing accounts, MFA, sessions and router secrets preserved. No router command was executed. Verify the client before rebuilding the phone with its existing local signing.');
 }finally{if(temp)fs.rmSync(temp,{recursive:true,force:true});if(lock!==undefined){fs.closeSync(lock);fs.unlinkSync(lockPath);}}
}
main().catch(e=>{console.error('Update stopped: '+(e.code==='EEXIST'?'INSTALL_LOCK_EXISTS: inspect the existing installer process and lock before recovery.':e.message));process.exitCode=1;});
