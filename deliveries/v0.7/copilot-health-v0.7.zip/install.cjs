'use strict';
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const zlib = require('node:zlib');
const net = require('node:net');
const Module = require('node:module');

const expected = '9b63923b061adecc9ffb2200e448d7a1291047e61fa20c7fb10644687e398c6f';
function stopped(port) {
  return new Promise((resolve, reject) => {
    const socket = net.connect({host: '127.0.0.1', port});
    const fail = () => { socket.destroy(); reject(Error('STOP_APP_FIRST: stop Node/Flutter on port ' + port + ' with Ctrl+C; keep Docker running.')); };
    socket.setTimeout(1000, fail);
    socket.once('connect', fail);
    socket.once('error', error => {
      socket.destroy();
      if (error.code === 'ECONNREFUSED') resolve();
      else reject(Error('PORT_CHECK_FAILED: ' + port));
    });
  });
}
async function main() {
  const root = process.argv[2];
  if (!root) throw Error('Supply the existing project folder, for example D:\\NetWork-Ai');
  const payload = path.join(__dirname, 'update.ncp');
  const stat = fs.lstatSync(payload);
  if (!stat.isFile() || stat.size > 16 * 1024 * 1024) throw Error('INVALID_PAYLOAD');
  const bytes = fs.readFileSync(payload);
  if (crypto.createHash('sha256').update(bytes).digest('hex') !== expected) throw Error('PAYLOAD_HASH_MISMATCH');
  const pkg = JSON.parse(zlib.brotliDecompressSync(bytes, {maxOutputLength: 64 * 1024 * 1024}));
  if (pkg.version !== 'health-v07' || typeof pkg.runner !== 'string') throw Error('INVALID_PACKAGE');
  await Promise.all([stopped(3443), stopped(52100)]);
  const filename = path.join(path.resolve(root), '.copilot-verified-update.cjs');
  const runner = new Module(filename);
  runner.filename = filename;
  runner.paths = Module._nodeModulePaths(path.dirname(filename));
  runner._compile(pkg.runner, filename);
  const temporary = fs.mkdtempSync(path.join(os.tmpdir(), 'copilot-v07-update-'));
  try {
    const hexFile = path.join(temporary, 'update.hex.txt');
    fs.writeFileSync(hexFile, bytes.toString('hex'), {flag: 'wx', mode: 0o600});
    runner.exports.apply(root, hexFile, expected);
    console.log('Next: cd to your project and run node .\\runtime\\v06\\scripts\\upgrade-health-foundation.mjs');
  } finally {
    fs.rmSync(temporary, {recursive: true, force: true});
  }
}
main().catch(error => {
  console.error('Update stopped: ' + error.message);
  process.exitCode = 1;
});
