'use strict';
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const expectedPayload = 'a570572b22a8865a7b45464020e0d4ae9c9c9c54fcbb81e5dd0a46721c14edc6';
const expectedRunner = '5200eeae9632710b9a36177fcd5db5d387f91cc8e2f9ab22dd9f1ffca9c0e5e3';
const sha = value => crypto.createHash('sha256').update(value).digest('hex');

try {
  if (process.argv.length !== 3) throw Error('Supply the existing project folder: node install.cjs "D:\\NetWork-Ai"');
  const root = path.resolve(process.argv[2]);
  for (const relative of ['package.json', 'apps/mobile/pubspec.yaml']) {
    if (!fs.statSync(path.join(root, relative)).isFile()) throw Error('EXISTING_PROJECT_REQUIRED');
  }
  const payloadPath = path.join(__dirname, 'startup-update.ncp');
  const runnerPath = path.join(__dirname, 'apply-foundation-update.cjs');
  for (const file of [payloadPath, runnerPath]) {
    const stat = fs.lstatSync(file);
    if (!stat.isFile() || stat.size > 1024 * 1024) throw Error('INVALID_DELIVERY_FILE');
  }
  const bytes = fs.readFileSync(payloadPath);
  if (sha(bytes) !== expectedPayload) throw Error('PAYLOAD_HASH_MISMATCH');
  if (sha(fs.readFileSync(runnerPath)) !== expectedRunner) throw Error('RUNNER_HASH_MISMATCH');
  const runner = require(runnerPath);
  const temporary = fs.mkdtempSync(path.join(os.tmpdir(), 'copilot-startup-fix-'));
  try {
    const hex = path.join(temporary, 'update.hex.txt');
    fs.writeFileSync(hex, bytes.toString('hex'), {flag: 'wx', mode: 0o600});
    runner.apply(root, hex, expectedPayload);
  } finally {
    fs.rmSync(temporary, {recursive: true, force: true});
  }
  console.log('Startup fix ready. Build the phone update with build-phone.ps1 using the existing Gradle 9.3.1 cache. No database migration is needed.');
} catch (error) {
  console.error('Startup update stopped: ' + error.message);
  process.exitCode = 1;
}
