'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const runnerPath=path.join(__dirname,'apply-foundation-update.cjs');
if(!fs.lstatSync(runnerPath).isFile()||crypto.createHash('sha256').update(fs.readFileSync(runnerPath)).digest('hex')!=='5200eeae9632710b9a36177fcd5db5d387f91cc8e2f9ab22dd9f1ffca9c0e5e3')throw Error('RUNNER_HASH_MISMATCH');
const {safePath}=require(runnerPath);
const sha=value=>crypto.createHash('sha256').update(value).digest('hex');
function rollback(rootArg,backupArg){
 const root=path.resolve(rootArg),backup=path.resolve(backupArg);
 const relative=path.relative(root,backup).replaceAll('\\','/');
 if(!/^\.copilot-update-backups\/(?:foundation-v06|health-v07)-/.test(relative)||safePath(root,relative)!==backup)throw Error('Choose the exact update backup inside this project');
 const manifestPath=safePath(root,relative+'/update.json');
 if(fs.statSync(manifestPath).size>1024*1024)throw Error('Invalid backup manifest');
 const manifest=JSON.parse(fs.readFileSync(manifestPath,'utf8'));
 if(!['foundation-v06','health-v07'].includes(manifest.version)||!Array.isArray(manifest.files)||manifest.files.length>2500)throw Error('Invalid backup version');
 const startupFiles=new Map([["apps/mobile/android/app/src/main/res/drawable/launch_background.xml","f7aa9fbdfc1b7b27af2ed6cc843597d2e994100e166e9d76eb9865aace4534ad"],["apps/mobile/android/app/src/main/res/drawable-v21/launch_background.xml","f7aa9fbdfc1b7b27af2ed6cc843597d2e994100e166e9d76eb9865aace4534ad"],["apps/mobile/android/app/src/main/res/values/styles.xml","ea0ea193b3c1187e987414400deea5fdb3f0071f0cf38731cca71d9f71f8b69f"],["apps/mobile/android/app/src/main/res/values-night/styles.xml","5fc2b36e3e8b7acbc34832f10ae95107b71859fc8a9df3143939d16d93b2bae3"],["README.md","e5d81a3eee34e2e6bd919865f966f80388ddaa4e2041675e7d7c38e0dffe18a3"],["START_HERE.md","1e4d5dba194df83b2f2d26cad7c23bae78fffe0e3d4a47c41fe22180b72d778c"],["docs/current-status.md","dd5b0a1cdcb0eee5138ab14644d51ea192a0205256721eb13cfd8f316584869a"]]);
 if(!manifest.files.length||manifest.version!=='health-v07'||manifest.files.some(row=>startupFiles.get(row.path)!==row.after))throw Error('Choose the exact backup printed by this startup update');
 const plan=[];
 for(const row of manifest.files){
  const target=safePath(root,row.path),saved=safePath(root,relative+'/'+row.path);
  const current=fs.existsSync(target)?fs.readFileSync(target):null;
  if(row.existed && current && sha(current)===row.before)continue;
  if(!row.existed && current===null)continue;
  if(!current||sha(current)!==row.after)throw Error('File changed after update; preserved: '+row.path);
  const previous=row.existed?fs.readFileSync(saved):null;
  if(previous&&sha(previous)!==row.before)throw Error('Backup hash mismatch');
  plan.push({target,previous});
 }
 for(const row of plan){if(row.previous)fs.writeFileSync(row.target,row.previous);else fs.unlinkSync(row.target);}
 console.log('Code update rolled back. The foundation database and protected configuration were preserved.');
}
if(require.main===module){try{rollback(...process.argv.slice(2));}catch(e){console.error('Rollback stopped: '+e.message);process.exitCode=1;}}
module.exports={rollback};
