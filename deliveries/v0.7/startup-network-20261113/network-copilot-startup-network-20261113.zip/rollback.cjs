'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const runnerPath=path.join(__dirname,'apply-foundation-update.cjs');
if(!fs.lstatSync(runnerPath).isFile()||crypto.createHash('sha256').update(fs.readFileSync(runnerPath)).digest('hex')!=='5200eeae9632710b9a36177fcd5db5d387f91cc8e2f9ab22dd9f1ffca9c0e5e3')throw Error('RUNNER_HASH_MISMATCH');
const {safePath}=require(runnerPath);
const sha=value=>crypto.createHash('sha256').update(value).digest('hex');
function rollback(rootArg,backupArg){
 const root=path.resolve(rootArg),backup=path.resolve(backupArg);
 const relative=path.relative(root,backup).replaceAll('\\','/');
 if(!/^\.copilot-update-backups\/(?:foundation-v06|health-v07)-/.test(relative)||safePath(root,relative)!==backup)throw Error('Choose the exact update backup inside this project');
 const manifestPath=safePath(root,relative+'/update.json');
 if(fs.statSync(manifestPath).size>1024*1024)throw Error('Invalid backup manifest');
 const manifest=JSON.parse(fs.readFileSync(manifestPath,'utf8'));
 if(!['foundation-v06','health-v07'].includes(manifest.version)||!Array.isArray(manifest.files)||manifest.files.length>2500)throw Error('Invalid backup version');
 const startupFiles=new Map([["apps/mobile/android/app/src/main/res/drawable/launch_background.xml","a0e8bc7d095f01873137d87288a9ec3c825ae5c580b322abc316b3a53959d7d5"],["apps/mobile/android/app/src/main/res/drawable-v21/launch_background.xml","a0e8bc7d095f01873137d87288a9ec3c825ae5c580b322abc316b3a53959d7d5"],["apps/mobile/android/app/src/main/res/values/styles.xml","6e346dc5807e06cb23a4ca9fb48a8d04ffceb83b2b377e77290f753411e78936"],["apps/mobile/android/app/src/main/res/values-night/styles.xml","787498a447b9d4eef6d86c7168177ec06acedc367fa9b06de22e317dc360b446"],["apps/mobile/android/app/src/main/res/drawable/startup_network_mesh.xml","5da41ac05270a977622cf81f39c651f263d2395e9ff163aaccb4e837803f5a06"],["apps/mobile/android/app/src/main/res/drawable-land/startup_network_mesh.xml","0080e3273dc905ee9c564e663204205098c0589cca8907c0d55003e0fd7be120"],["apps/mobile/android/app/src/main/res/drawable/startup_network_rings.xml","f21027e9102cd200a4cf933ce34328b3e6a085eb35b0e046b8cf4ad8d3ac91cf"],["apps/mobile/android/app/src/main/res/drawable/startup_caption.xml","1f5285f372be6f22bdb56ef299cce56f9edf37b9a5dee33af6cff22d69f9eb24"],["docs/current-status.md","5d8bee6e55962ccb6ee78ac400cea9d622f293736c30c3efa6b4a307db52442e"]]);
 if(!manifest.files.length||manifest.version!=='health-v07'||manifest.files.some(row=>startupFiles.get(row.path)!==row.after))throw Error('Choose the exact backup printed by the 13 November network prelude update');
 const plan=[];
 for(const row of manifest.files){
  const target=safePath(root,row.path),saved=safePath(root,relative+'/'+row.path);
  const current=fs.existsSync(target)?fs.readFileSync(target):null;
  if(row.existed && current && sha(current)===row.before)continue;
  if(!row.existed && current===null)continue;
  if(!current||sha(current)!==row.after)throw Error('File changed after update; preserved: '+row.path);
  const previous=row.existed?fs.readFileSync(saved):null;
  if(previous&&sha(previous)!==row.before)throw Error('Backup hash mismatch');
  plan.push({target,previous});
 }
 for(const row of plan){if(row.previous)fs.writeFileSync(row.target,row.previous);else fs.unlinkSync(row.target);}
 console.log('Code update rolled back. The foundation database and protected configuration were preserved.');
}
if(require.main===module){try{rollback(...process.argv.slice(2));}catch(e){console.error('Rollback stopped: '+e.message);process.exitCode=1;}}
module.exports={rollback};
