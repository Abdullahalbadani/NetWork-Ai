param([string]$ProjectRoot = 'D:\NetWork-Ai')
$ErrorActionPreference = 'Stop'
$copilotProject = (Resolve-Path -LiteralPath $ProjectRoot).Path
$copilotGradleHome = if ($env:GRADLE_USER_HOME) {
    $env:GRADLE_USER_HOME
} else {
    Join-Path $env:USERPROFILE '.gradle'
}
$copilotGradleCache = Join-Path $copilotGradleHome 'wrapper\dists\gradle-9.3.1-all'
if (-not (Test-Path -LiteralPath $copilotGradleCache)) {
    throw 'Gradle 9.3.1 is missing from the expected cache. Stopped without downloading another version.'
}
$copilotGradle = Get-ChildItem -LiteralPath $copilotGradleCache -Filter 'gradle.bat' -File -Recurse | Select-Object -First 1
if ($null -eq $copilotGradle) { throw 'Cached Gradle 9.3.1 executable was not found.' }
$copilotAdb = if ($env:ANDROID_HOME -and (Test-Path -LiteralPath (Join-Path $env:ANDROID_HOME 'platform-tools\adb.exe'))) {
    Join-Path $env:ANDROID_HOME 'platform-tools\adb.exe'
} elseif ($env:LOCALAPPDATA -and (Test-Path -LiteralPath (Join-Path $env:LOCALAPPDATA 'Android\Sdk\platform-tools\adb.exe'))) {
    Join-Path $env:LOCALAPPDATA 'Android\Sdk\platform-tools\adb.exe'
} else {
    $copilotAdbCommand = Get-Command adb -ErrorAction SilentlyContinue
    if ($null -eq $copilotAdbCommand) { throw 'Existing adb was not found. Stopped without downloading tools.' }
    $copilotAdbCommand.Source
}
& $copilotAdb -d get-state
if ($LASTEXITCODE -ne 0) { throw 'Connect and authorize one USB Android phone, then retry.' }
$copilotGradleArgs = @(
    '--offline', '--console=plain', '--no-daemon',
    '-Ptarget-platform=android-arm64',
    '-Pandroid.builder.sdkDownload=false',
    '-Dorg.gradle.java.installations.auto-download=false',
    '-PcopilotVersionName=0.7.0', '-PcopilotVersionCode=7',
    '--project-dir', (Join-Path $copilotProject 'apps\mobile\android'), 'assembleDebug'
)
& $copilotGradle.FullName @copilotGradleArgs
if ($LASTEXITCODE -ne 0) { throw 'Offline build failed. The phone was not updated; inspect the missing item before downloading anything.' }
$copilotApk = Join-Path $copilotProject 'apps\mobile\build\app\outputs\flutter-apk\app-debug.apk'
if (-not (Test-Path -LiteralPath $copilotApk)) { throw 'Expected APK was not found. The phone was not updated.' }
& $copilotAdb -d install -r $copilotApk
if ($LASTEXITCODE -ne 0) { throw 'Phone update failed. Keep the installed app and its data; inspect the result.' }
& (Join-Path $PSScriptRoot 'connect-phone.ps1') -AdbPath $copilotAdb
& $copilotAdb -d shell am force-stop app.networkcopilot.mobile
if ($LASTEXITCODE -ne 0) { throw 'Could not prepare a cold app launch.' }
& $copilotAdb -d shell am start -W -n app.networkcopilot.mobile/.MainActivity
if ($LASTEXITCODE -ne 0) { throw 'Could not launch the updated app.' }
Write-Host 'Update installed with -r. Check the network prelude from the first window, one Flutter identity, and the existing session and health scan.'
