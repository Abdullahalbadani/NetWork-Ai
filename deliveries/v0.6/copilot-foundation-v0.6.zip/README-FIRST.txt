NETWORK COPILOT 0.6 UPDATE

1. Verify the downloaded ZIP SHA256 using the value in the chat before extracting.
2. Stop the Flutter process and your old Node server.
3. Extract this ZIP into a new folder, for example D:\copilot-update-v06.
4. In PowerShell run:

node "D:\copilot-update-v06\install.cjs" "D:\NetWork-Ai"

This updates your existing project. It checks the embedded package hash,
refuses unknown local edits and saves a code backup. It does not start servers.
Keep the printed backup path. A second run preserves the installed update.

After success, open this file for Docker, accounts, certificates and Flutter:
D:\NetWork-Ai\docs\foundation-windows.md

Keep your .env, private configuration, passwords and recovery codes private.
Do not publish or paste those files into a chat.

The update.ncp file is compressed data; do not edit it or run it directly.
The complete frozen packet SHA256 is:
d1990b0b219d3bf25e95e027585d8aa7d146c07de483415d08638a34c49c0a4f
