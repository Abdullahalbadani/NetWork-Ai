'use strict';
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const zlib = require('node:zlib');
const Module = require('node:module');

const expected = 'd1990b0b219d3bf25e95e027585d8aa7d146c07de483415d08638a34c49c0a4f';
let temporary;
try {
  const root = process.argv[2];
  if (!root) throw Error('Supply the existing project folder, for example D:\\NetWork-Ai');
  const payload = path.join(__dirname, 'update.ncp');
  if (!fs.statSync(payload).isFile() || fs.statSync(payload).size > 16 * 1024 * 1024) {
    throw Error('INVALID_PAYLOAD');
  }
  const bytes = fs.readFileSync(payload);
  if (crypto.createHash('sha256').update(bytes).digest('hex') !== expected) {
    throw Error('PAYLOAD_HASH_MISMATCH');
  }
  const pkg = JSON.parse(zlib.brotliDecompressSync(bytes, { maxOutputLength: 64 * 1024 * 1024 }));
  if (pkg.version !== 'foundation-v06' || typeof pkg.runner !== 'string') {
    throw Error('INVALID_PACKAGE');
  }
  const filename = path.join(path.resolve(root), '.copilot-verified-update.cjs');
  const runner = new Module(filename);
  runner.filename = filename;
  runner.paths = Module._nodeModulePaths(path.dirname(filename));
  runner._compile(pkg.runner, filename);
  temporary = fs.mkdtempSync(path.join(os.tmpdir(), 'copilot-v06-update-'));
  const hexFile = path.join(temporary, 'update.hex.txt');
  fs.writeFileSync(hexFile, bytes.toString('hex'), { flag: 'wx', mode: 0o600 });
  runner.exports.apply(root, hexFile, expected);
} catch (error) {
  console.error('Update stopped: ' + error.message);
  process.exitCode = 1;
} finally {
  if (temporary) fs.rmSync(temporary, { recursive: true, force: true });
}
