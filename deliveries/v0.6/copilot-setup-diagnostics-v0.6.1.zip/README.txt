Network Copilot setup diagnostics 0.6.1

Apply to the installed 0.6 project:
node "D:\copilot-setup-diagnostics-v061\install.cjs" "D:\NetWork-Ai"

This patch adds bounded setup-stage, error-code and exit-code reporting.
It uses numeric Windows token and SYSTEM SIDs for private-directory grants.
The actual Windows setup failure remains to be identified by the next run.
The patch does not modify .env, private settings, pending setup or Docker containers.
It checks the old files and backs them up; unknown edits stop before writing.

After applying, retry the normal owner setup with the same email/password.
Send only the success text or Setup diagnostic line. Keep passwords and private files private.
