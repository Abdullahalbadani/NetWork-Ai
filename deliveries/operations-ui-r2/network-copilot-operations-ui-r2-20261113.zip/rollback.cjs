'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const runnerPath=path.join(__dirname,'apply-foundation-update.cjs');if(crypto.createHash('sha256').update(fs.readFileSync(runnerPath)).digest('hex')!=='575c682830d25be6be674fa571551e48c5a49e058b87356dcfd9e17dd852495f')throw Error('RUNNER_HASH_MISMATCH');const {safePath}=require(runnerPath);
const sha=value=>crypto.createHash('sha256').update(value).digest('hex');
function rollback(rootArg,backupArg){
 const root=path.resolve(rootArg),backup=path.resolve(backupArg);
 const relative=path.relative(root,backup).replaceAll('\\','/');
 if(!/^\.copilot-update-backups\/(?:foundation-v06|health-v07|operations-v08)-/.test(relative)||safePath(root,relative)!==backup)throw Error('Choose the exact update backup inside this project');
 const manifestPath=safePath(root,relative+'/update.json');
 if(fs.statSync(manifestPath).size>1024*1024)throw Error('Invalid backup manifest');
 const manifest=JSON.parse(fs.readFileSync(manifestPath,'utf8'));
 if(!['foundation-v06','health-v07','operations-v08'].includes(manifest.version)||!Array.isArray(manifest.files)||manifest.files.length>2500)throw Error('Invalid backup version');
 const expectedFiles=new Map([["apps/mobile/lib/operations_screen.dart","c27b54bd742c8ea1d094377cc16566acb961dd5c2f710a97a02e17a9cf62b6ab"],["apps/mobile/test/operations_test.dart","cfe8f5b1a88ffaba63c203452d2c6ef92731a9b186e55064663a10253ce83d82"]]);if(manifest.version!=='operations-v08'||!manifest.files.length||manifest.files.some(f=>expectedFiles.get(f.path)!==f.after))throw Error('Use the exact code backup printed by the UI R2 installer');
 const plan=[];
 for(const row of manifest.files){
  const target=safePath(root,row.path),saved=safePath(root,relative+'/'+row.path);
  const current=fs.existsSync(target)?fs.readFileSync(target):null;
  if(row.existed && current && sha(current)===row.before)continue;
  if(!row.existed && current===null)continue;
  if(!current||sha(current)!==row.after)throw Error('File changed after update; preserved: '+row.path);
  const previous=row.existed?fs.readFileSync(saved):null;
  if(previous&&sha(previous)!==row.before)throw Error('Backup hash mismatch');
  plan.push({target,previous});
 }
 for(const row of plan){if(row.previous)fs.writeFileSync(row.target,row.previous);else fs.unlinkSync(row.target);}
 console.log('Code update rolled back. The foundation database and protected configuration were preserved.');
}
if(require.main===module){try{rollback(...process.argv.slice(2));}catch(e){console.error('Rollback stopped: '+e.message);process.exitCode=1;}}
module.exports={rollback};
