'use strict';
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),zlib=require('node:zlib');
const expectedPayload='d62ea5b9e2852eea5811da3e89179eb42985ef3fe8a60d45db16b4df817bac9e',expectedRunner='575c682830d25be6be674fa571551e48c5a49e058b87356dcfd9e17dd852495f';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
try{
 if(Number(process.versions.node.split('.')[0])<24)throw Error('Node 24 or newer is required');
 if(process.argv.length!==3)throw Error('Usage: node install.cjs "D:\\NetWork-Ai"');
 const root=path.resolve(process.argv[2]);
 if(!fs.existsSync(root)||fs.lstatSync(root).isSymbolicLink()||!fs.statSync(root).isDirectory())throw Error('EXISTING_PROJECT_REQUIRED');
 const runnerPath=path.join(__dirname,'apply-foundation-update.cjs'),payloadPath=path.join(__dirname,'ui-update.ncp');
 for(const [file,hash]of [[runnerPath,expectedRunner],[payloadPath,expectedPayload]]){const s=fs.lstatSync(file);if(!s.isFile()||s.isSymbolicLink()||s.size>1024*1024||sha(fs.readFileSync(file))!==hash)throw Error('DELIVERY_INTEGRITY_FAILED');}
 const runner=require(runnerPath);let project,runtime;
 try{project=JSON.parse(fs.readFileSync(runner.safePath(root,'package.json'),'utf8').replace(/^\uFEFF/,''));runtime=JSON.parse(fs.readFileSync(runner.safePath(root,'runtime/v06/package.json'),'utf8').replace(/^\uFEFF/,''));}catch{throw Error('INVALID_PROJECT_MARKERS');}
 const pubspec=fs.readFileSync(runner.safePath(root,'apps/mobile/pubspec.yaml'),'utf8').replace(/^\uFEFF/,'');
 if(project.name!=='network-copilot'||runtime.name!=='network-copilot-runtime'||runtime.version!=='0.8.0'||!/^name:\s*network_copilot\s*$/m.test(pubspec)||!/^version:\s*0\.8\.0\+8\s*$/m.test(pubspec))throw Error('INSTALLED_080_SOURCE_REQUIRED');
 const bytes=fs.readFileSync(payloadPath),pkg=JSON.parse(zlib.brotliDecompressSync(bytes,{maxOutputLength:1024*1024}));
 const allowed=new Set(["apps/mobile/lib/operations_screen.dart","apps/mobile/test/operations_test.dart"]);
 if(pkg.version!=='operations-v08'||pkg.patchVersion!=='operations-ui-r2-20261113'||pkg.files.length!==2||pkg.files.some(f=>!allowed.delete(f.path))||allowed.size)throw Error('UI_PATCH_SCOPE_REFUSED');
 const temporary=fs.mkdtempSync(path.join(os.tmpdir(),'copilot-ui-r2-'));
 const lockPath=path.join(root,'.copilot-integration.lock');let lock;
 try{lock=fs.openSync(lockPath,'wx',0o600);const hex=path.join(temporary,'payload.hex');fs.writeFileSync(hex,bytes.toString('hex'),{flag:'wx',mode:0o600});const r=runner.apply(root,hex,expectedPayload,()=>{});if(r.changed){console.log('Operations UI R2 installed. Files: '+r.changed);console.log('Code backup: '+r.backup);}else console.log('Operations UI R2 is already installed.');}
 finally{fs.rmSync(temporary,{recursive:true,force:true});if(lock!==undefined){fs.closeSync(lock);fs.unlinkSync(lockPath);}}
 console.log('No database migration, account reset, signing change, dependency download or RouterOS write. Rerun verify-client.ps1 before building the phone update.');
}catch(e){console.error('UI patch stopped: '+(e.code==='EEXIST'?'INSTALL_LOCK_EXISTS: inspect the active installer before retrying':e.message));process.exitCode=1;}
