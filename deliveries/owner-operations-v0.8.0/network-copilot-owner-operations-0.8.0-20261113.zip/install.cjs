'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),os=require('node:os'),net=require('node:net'),zlib=require('node:zlib'),child=require('node:child_process');
const expectedPayload='d7dfda84619bb21616634fc9f5d7f661735af7999b37cc5e34a29f987e4aea6f',expectedRunner='575c682830d25be6be674fa571551e48c5a49e058b87356dcfd9e17dd852495f',expectedCompatibility='4e3abace656e7662b163b95022ec7bcba55d2da14f0bf0b2cdbd0c283f711525';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const canonical=b=>Buffer.from(b.toString('utf8').replace(/^\uFEFF/,'').replace(/\r\n/g,'\n'));
async function stopped(){
 const listening=await new Promise(resolve=>{const s=net.connect({host:'127.0.0.1',port:3443});s.setTimeout(1000);s.once('connect',()=>{s.destroy();resolve(true);});s.once('error',()=>resolve(false));s.once('timeout',()=>{s.destroy();resolve(true);});});
 if(listening)throw Error('SERVER_RUNNING: stop the server on 3443 before applying this update.');
}
async function main(){
 const args=process.argv.slice(2),codeOnly=args.includes('--code-only'),pos=args.filter(a=>a!=='--code-only');
 if(pos.length!==1||args.some(a=>a.startsWith('--')&&a!=='--code-only'))throw Error('Usage: node install.cjs "D:\\NetWork-Ai" [--code-only]');
 if(Number(process.versions.node.split('.')[0])<24)throw Error('Node 24 or newer is required.');
 const root=path.resolve(pos[0]);
 if(!fs.existsSync(root)||fs.lstatSync(root).isSymbolicLink())throw Error('EXISTING_PROJECT_REQUIRED');
 const metadata=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
 const runtime=JSON.parse(fs.readFileSync(path.join(root,'runtime/v06/package.json'),'utf8'));
 if(metadata.name!=='network-copilot'||!['0.7.0','0.8.0'].includes(runtime.version))throw Error('NETWORK_COPILOT_BASELINE_REQUIRED');
 const payloadPath=path.join(__dirname,'operations-update.ncp'),runnerPath=path.join(__dirname,'apply-foundation-update.cjs'),compatPath=path.join(__dirname,'compatibility.json');
 for(const [file,hash]of [[payloadPath,expectedPayload],[runnerPath,expectedRunner],[compatPath,expectedCompatibility]]){
  const s=fs.lstatSync(file);if(!s.isFile()||s.isSymbolicLink()||s.size>32*1024*1024||sha(fs.readFileSync(file))!==hash)throw Error('DELIVERY_INTEGRITY_FAILED: '+path.basename(file));
 }
 const runner=require(runnerPath),compat=JSON.parse(fs.readFileSync(compatPath,'utf8'));
 for(const item of compat.files){
  const target=runner.safePath(root,item.path);let bytes=null;
  if(fs.existsSync(target)){const s=fs.lstatSync(target);if(!s.isFile()||s.size>16*1024*1024)throw Error('INVALID_BASELINE_FILE: '+item.path);bytes=fs.readFileSync(target);}
  const hash=bytes?sha(item.binary?bytes:canonical(bytes)):null;
  let known=item.hashes.includes(hash);
  if(!known&&bytes&&item.path.endsWith('.dart')&&item.sourceHashes){try{known=item.sourceHashes.includes(runner.sourceHash(bytes));}catch{}}
  if(!known)throw Error('UNKNOWN_LOCAL_EDIT: '+item.path+'; no files were written.');
 }
 await stopped();
 // Pure preflight: validate every payload entry and current bytes before creating the install lock or backup.
 const compressed=fs.readFileSync(payloadPath),pkg=JSON.parse(zlib.brotliDecompressSync(compressed,{maxOutputLength:64*1024*1024}));
 for(const item of pkg.files){
  if(!runner.allowedPath(item.path)||sha(Buffer.from(item.content,'base64'))!==item.after)throw Error('INVALID_PAYLOAD_ENTRY');
 }
 const lockPath=path.join(root,'.copilot-integration.lock');let lock,temporary,result;
 try{
  lock=fs.openSync(lockPath,'wx',0o600);temporary=fs.mkdtempSync(path.join(os.tmpdir(),'copilot-operations-'));
  const hex=path.join(temporary,'payload.hex');fs.writeFileSync(hex,compressed.toString('hex'),{flag:'wx',mode:0o600});
  result=runner.apply(root,hex,expectedPayload,()=>{});
  if(result.changed){console.log('Operations code installed. Files: '+result.changed);console.log('Code backup: '+result.backup);}
  else console.log('Operations code is already installed.');
  if(codeOnly){console.log('CODE ONLY: database was not touched. Run runtime/v06/scripts/upgrade-operations-foundation.mjs before starting the updated server.');return;}
  const migration=child.spawnSync(process.execPath,['--env-file-if-exists=.env',path.join(root,'runtime/v06/scripts/upgrade-operations-foundation.mjs')],{cwd:root,stdio:'inherit',windowsHide:true});
  if(migration.error||migration.status!==0){console.error('DATABASE UPGRADE INCOMPLETE. Keep the server stopped. Preserve the code backup and encrypted backup. Rerun this installer after correcting the reported readiness issue; it is safe to retry. Code was not automatically rolled back because schema 3 might already be committed.');process.exitCode=1;return;}
  console.log('Update ready: runtime/v06, version 0.8.0, schema 3. Accounts, MFA, private settings, signing and existing caches preserved. No RouterOS command was executed.');
 }finally{
  if(temporary)fs.rmSync(temporary,{recursive:true,force:true});
  if(lock!==undefined){fs.closeSync(lock);fs.unlinkSync(lockPath);}
 }
}
main().catch(e=>{console.error('Update stopped: '+(e.code==='EEXIST'?'INSTALL_LOCK_EXISTS: another installer may be active. Inspect .copilot-integration.lock before recovery.':e.message));process.exitCode=1;});
